# KittyRec

a 2018 RecRoom server reimplmentation built for the june 7th 2018 build. the goal is full API support for everything that was in the game at that point and add new stuff that was never in the orignal.

live at **kittyrec.tabbycluster.net**

---


## whats implemented

- **auth** — login, cached login, account creation, platform linking, daily login bonus, token refresh
- **profiles** — xp, levels, display names, avatar/outfit, swatches, item ownership
- **multiplayer** — game sessions, matchmaking, session joining, rec royale, reporting join results
- **store** — storefronts, token purchases, elite items, pinned featured items, store reroll
- **gifts** — gift drops, gift box opening, sending gifts between players, daily token rewards
- **relationships** — friends, blocking, following, player search
- **chat** — direct messages, chat thread
- **Progression** — box caps, drops, chances, etc
- **avatar** — outfit saving, wardrobe, item equipping, color swatches
- **downloads** — chunked build uploads, public download page, auto extracts to compiled/
- **websocket** — real time presence, session events, gift notifs, profile updates
- **admin panel** — player managment, bans, gifts, live sessions, store, weekly challenege scheduler

---

## stack

- Python + Flask
- SQLite
- WebSockets (flask-sock)
- port 8080

---

## running

```bash
pip install -r requirements.txt
python app.py
```

---

## "anticheat"

serverside anticheat (if you can even call it that) handles cascade bans accross linked accounts, IP bans, dual login detection, and banned room joins. linked acounts get caught on login even if they made a new account.

---

## notes

- built against the june 7 2018 game client, field names and response formats are **reverse engineered from the compiled game code** (sometimes)
- database auto creates on first run

---

## Credits

- MyaWired - Leading the project, Hosting the server, working on backends
- EggRecRoom - Build Mods
- WeeBoi - Build Mods
- Claude Code - fixing alot of stuff also breaking alot of stuff

god bless all the kind souls who made this project real (not claude tho... claude is a clanker..)
