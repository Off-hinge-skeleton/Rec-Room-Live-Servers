
import threading

from .state import db

current_jti: dict[int, str] = {}
jti_lock = threading.Lock()

_saved = db.get_latest_jtis()
if _saved:
    current_jti.update(_saved)
