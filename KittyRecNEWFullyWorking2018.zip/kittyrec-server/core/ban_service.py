
from .state import db, ws_registry, session_mgr
from .ws_helpers import push_presence


def kick_player(player_id: int) -> bool:
    ws_registry.send(player_id, {"Id": 20, "Msg": {}})
    closed = ws_registry.close_and_unregister(player_id)
    session_mgr.leave_session(player_id)
    push_presence(player_id, None, online=False)
    return closed


def cascade_ban(primary_id: int, reason: str, duration_h: int, admin_name: str) -> None:
    from .ban_tracker import record_ban_group
    primary = db.get_profile(primary_id)
    primary_name = primary.get("Username", str(primary_id)) if primary else str(primary_id)
    if not db.is_banned(primary_id):
        db.ban_player(primary_id, reason=reason, duration_hours=duration_h, admin_name=admin_name)
    associated = db.get_associated_accounts_with_evidence(primary_id)
    print(f"[Ban] {primary_name} ({primary_id}): found {len(associated)} linked account(s): {list(associated.keys())}")
    for pid, evidence in associated.items():
        p = db.get_profile(pid)
        pname = p.get("Username", str(pid)) if p else str(pid)
        print(f"[Ban]   → pid={pid} ({pname}) via IPs={evidence['shared_ips']} platforms={evidence['shared_platform_ids']}")
        if not db.is_banned(pid):
            db.ban_player(pid, reason=f"Banned by association with {primary_name}: {reason}", duration_hours=duration_h, admin_name=admin_name)
    record_ban_group(primary_id, primary_name, associated, reason)
    kick_player(primary_id)
    for pid in associated:
        kick_player(pid)


def cascade_unban(primary_id: int, admin_name: str) -> None:
    db.unban_player(primary_id, admin_name=admin_name)
    print(f"[Ban] Unban: pid={primary_id} (cascade handled by unban_player)")


def cascade_kick_linked(primary_id: int) -> None:
    from .ban_tracker import record_ban_group
    primary = db.get_profile(primary_id)
    primary_name = primary.get("Username", str(primary_id)) if primary else str(primary_id)
    reason = f"Banned by association with {primary_name}"
    associated = db.get_associated_accounts_with_evidence(primary_id)
    for linked_id, evidence in associated.items():
        if db.is_banned(linked_id):
            continue
        db.ban_player(linked_id, reason=reason, duration_hours=0, admin_name="AntiCheat")
        kick_player(linked_id)
        print(f"[AntiCheat] Cascade ban+kick: player {linked_id} ← {primary_name} ({primary_id}) via IPs={evidence['shared_ips']} platforms={evidence['shared_platform_ids']}")
    if associated:
        record_ban_group(primary_id, primary_name, associated, reason)
