import json
import os
from datetime import datetime, timezone

_TRACKING_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "tracking", "moderation")


def _path(primary_id: int) -> str:
    return os.path.join(_TRACKING_DIR, f"{primary_id}.json")


def record_ban_group(primary_id: int, primary_name: str, associated: dict, reason: str) -> None:
    data = {
        "primary_id": primary_id,
        "primary_name": primary_name,
        "reason": reason,
        "banned_at": datetime.now(timezone.utc).isoformat(),
        "associated_ids": [int(i) for i in associated if int(i) != primary_id],
        "links": {
            str(pid): ev for pid, ev in associated.items() if int(pid) != primary_id
        },
    }
    with open(_path(primary_id), "w") as f:
        json.dump(data, f, indent=2)


def get_ban_group(primary_id: int) -> dict | None:
    p = _path(primary_id)
    if not os.path.exists(p):
        return None
    try:
        with open(p) as f:
            return json.load(f)
    except Exception:
        return None


def clear_ban_group(primary_id: int) -> None:
    p = _path(primary_id)
    if os.path.exists(p):
        os.remove(p)


def find_group_for_member(member_id: int) -> dict | None:
    try:
        for fname in os.listdir(_TRACKING_DIR):
            if not fname.endswith(".json"):
                continue
            fpath = os.path.join(_TRACKING_DIR, fname)
            try:
                with open(fpath) as f:
                    data = json.load(f)
                if data.get("primary_id") == member_id:
                    return data
                if member_id in data.get("associated_ids", []):
                    return data
            except Exception:
                continue
    except Exception:
        pass
    return None
