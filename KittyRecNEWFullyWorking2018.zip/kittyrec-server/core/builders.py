
import datetime
import re
import time

from flask import request as _flask_request

from .constants import KNOWN_ACTIVITIES


def now_iso() -> str:
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def get_request_data() -> dict:
    j = _flask_request.get_json(force=True, silent=True)
    if j and isinstance(j, dict):
        return j
    return _flask_request.values.to_dict()

_USERNAME_RE = re.compile(r"[^\w\-]")

def sanitize_username(name: str, max_len: int = 32) -> str:
    name = name.strip()
    name = _USERNAME_RE.sub("", name)
    return name[:max_len]

def now_ticks() -> int:
    return int(time.time() * 10_000_000) + 621355968000000000

def activity_info(guid: str) -> tuple[str, str, bool]:
    return KNOWN_ACTIVITIES.get(guid, ("Custom Room", "custom", False))

def make_player_reputation(reputation: int = 0, player_id: int = 0, selected_cheer: int = 0) -> dict:
    from core.state import db as _db
    sub_count = _db.get_subscriber_count(player_id) if player_id else 0
    subd_count = len(_db.get_subscriptions(player_id)) if player_id else 0
    return {
        "Noteriety": min(1.0, reputation / 100.0),
        "CheerGeneral": reputation,
        "CheerHelpful": 0,
        "CheerGreatHost": 0,
        "CheerSportsman": 0,
        "CheerCreative": 0,
        "CheerCredit": 0,
        "SubscriberCount": sub_count,
        "SubscribedCount": subd_count,
        "SelectedCheer": selected_cheer,
    }

_PLATFORM_NAMES = {"steam": 0, "oculus": 1, "ps4": 2, "microsoft": 3}

def _platform_int(raw) -> int:
    if raw is None:
        return 0
    try:
        return int(raw)
    except (ValueError, TypeError):
        return _PLATFORM_NAMES.get(str(raw).lower(), 0)

def _platform_id_str(db_profile: dict) -> str:
    pid_str = str(db_profile.get("platform_id") or db_profile.get("PlatformId") or "")
    try:
        val = int(pid_str)
        if val > 0:
            return pid_str
    except (ValueError, TypeError):
        pass
    return "0"

def make_profile_from_db(db_profile: dict) -> dict:
    from core.constants import xp_for_client
    cumulative_xp = db_profile.get("XP", 0)
    level = db_profile.get("Level", 1)
    return {
        "Id": int(db_profile["Id"]),
        "Username": db_profile["Username"],
        "DisplayName": db_profile["DisplayName"],
        "Bio": db_profile.get("Bio", ""),
        "XP": xp_for_client(cumulative_xp, level),
        "Level": level,

        "RegistrationStatus": db_profile.get("RegistrationStatus", 2),
        "Developer": bool(db_profile.get("Developer", False)),
        "CanReceiveInvites": True,
        "ProfileImageName": db_profile.get("ProfileImageName", ""),
        "JuniorProfile": False,
        "ForceJuniorImages": False,
        "PendingJunior": False,
        "HasBirthday": True,
        "AvoidJuniors": False,
        "IsJunior": False,
        "NumFollowers": 0,
        "NumFollowing": 0,
        "PlayerReputation": make_player_reputation(int(db_profile.get("Reputation", 0)), int(db_profile["Id"]), int(db_profile.get("SelectedCheer", 0))),
        "PlatformId": {
            "Platform": _platform_int(db_profile.get("platform") or db_profile.get("Platform")),
            "PlatformId": _platform_id_str(db_profile),
        },
    }

def make_login_response(profile: dict, token: str) -> dict:
    return {
        "Error": "",
        "Player": profile,
        "Token": token,
        "FirstLoginOfTheDay": False,
        "AnalyticsSessionId": 1,
        "CanUseScreenMode": True,
    }
