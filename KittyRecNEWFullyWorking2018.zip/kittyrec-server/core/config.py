import os
import yaml

_config_path = os.path.join(os.path.dirname(__file__), "..", "data", "config.yaml")

with open(_config_path, "r") as _f:
    _cfg = yaml.safe_load(_f)


def get(section, key, default=None):
    return _cfg.get(section, {}).get(key, default)


server = _cfg.get("server", {})
auth = _cfg.get("auth", {})
seed_account = _cfg.get("seed_account", {})
discord = _cfg.get("discord", {})
sdk = _cfg.get("sdk", {})
base_url: str = server.get("base_url", "")
