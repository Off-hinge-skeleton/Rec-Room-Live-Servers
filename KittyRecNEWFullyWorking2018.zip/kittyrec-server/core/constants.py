import enum

DORM_ROOM_GUID = "76d98498-60a1-430c-ab76-b54a29b7a163"

XP_THRESHOLDS = [
    0, 300, 750, 1_500, 2_600, 4_100, 6_200, 9_000, 12_800, 17_800,
    24_300, 32_500, 43_000, 56_000, 72_000, 91_500, 115_000, 143_000,
    176_500, 216_000, 263_000, 318_500, 384_000, 460_000, 549_000,
    653_000, 774_000, 915_000, 1_079_000, 1_270_000,
]

def xp_to_level(xp: int) -> int:
    from bisect import bisect_right
    idx = bisect_right(XP_THRESHOLDS, xp) - 1
    return max(1, min(30, idx + 1))

def xp_for_client(cumulative_xp: int, level: int) -> int:
    idx = max(0, min(level - 1, len(XP_THRESHOLDS) - 1))
    return max(0, cumulative_xp - XP_THRESHOLDS[idx])

def xp_to_next_level(cumulative_xp: int, level: int) -> int:
    if level >= 30:
        return 1
    idx = min(level, len(XP_THRESHOLDS) - 1)
    return max(1, XP_THRESHOLDS[idx] - cumulative_xp)

LEVEL_PROGRESSION_MAPS = [
    {"Level": 0, "RequiredXp": 1,      "GiftDropId": None},
    {"Level": 1, "RequiredXp": 1,      "GiftDropId": 3288},
    {"Level": 2, "RequiredXp": 300,    "GiftDropId": 3293},
    {"Level": 3, "RequiredXp": 450,    "GiftDropId": 3288},
    {"Level": 4, "RequiredXp": 750,    "GiftDropId": 3293},
    {"Level": 5, "RequiredXp": 1100,   "GiftDropId": 3288},
    {"Level": 6, "RequiredXp": 1500,   "GiftDropId": 3293},
    {"Level": 7, "RequiredXp": 2100,   "GiftDropId": 3288},
    {"Level": 8, "RequiredXp": 2800,   "GiftDropId": 3293},
    {"Level": 9, "RequiredXp": 3800,   "GiftDropId": 3288},
    {"Level": 10, "RequiredXp": 5000,  "GiftDropId": 3293},
    {"Level": 11, "RequiredXp": 6500,  "GiftDropId": 3293},
    {"Level": 12, "RequiredXp": 8200,  "GiftDropId": 3293},
    {"Level": 13, "RequiredXp": 10500, "GiftDropId": 3293},
    {"Level": 14, "RequiredXp": 13000, "GiftDropId": 3293},
    {"Level": 15, "RequiredXp": 16000, "GiftDropId": 3293},
    {"Level": 16, "RequiredXp": 19500, "GiftDropId": 3293},
    {"Level": 17, "RequiredXp": 23500, "GiftDropId": 3293},
    {"Level": 18, "RequiredXp": 28000, "GiftDropId": 3293},
    {"Level": 19, "RequiredXp": 33500, "GiftDropId": 3293},
    {"Level": 20, "RequiredXp": 39500, "GiftDropId": 3293},
    {"Level": 21, "RequiredXp": 47000, "GiftDropId": 3293},
    {"Level": 22, "RequiredXp": 55500, "GiftDropId": 3292},
    {"Level": 23, "RequiredXp": 65500, "GiftDropId": 3293},
    {"Level": 24, "RequiredXp": 76000, "GiftDropId": 3292},
    {"Level": 25, "RequiredXp": 89000, "GiftDropId": 3293},
    {"Level": 26, "RequiredXp": 104000, "GiftDropId": 3292},
    {"Level": 27, "RequiredXp": 121000, "GiftDropId": 3293},
    {"Level": 28, "RequiredXp": 141000, "GiftDropId": 3292},
    {"Level": 29, "RequiredXp": 164000, "GiftDropId": 3293},
    {"Level": 30, "RequiredXp": 191000, "GiftDropId": 3292},
    {"Level": 31, "RequiredXp": 360, "GiftDropId": 3291},
    {"Level": 32, "RequiredXp": 360, "GiftDropId": 3292},
    {"Level": 33, "RequiredXp": 360, "GiftDropId": 3292},
    {"Level": 34, "RequiredXp": 360, "GiftDropId": 3292},
    {"Level": 35, "RequiredXp": 360, "GiftDropId": 3291},
    {"Level": 36, "RequiredXp": 360, "GiftDropId": 3292},
    {"Level": 37, "RequiredXp": 360, "GiftDropId": 3292},
    {"Level": 38, "RequiredXp": 360, "GiftDropId": 3292},
    {"Level": 39, "RequiredXp": 360, "GiftDropId": 3292},
    {"Level": 40, "RequiredXp": 360, "GiftDropId": 3291},
    {"Level": 41, "RequiredXp": 1080, "GiftDropId": 3291},
    {"Level": 42, "RequiredXp": 1080, "GiftDropId": 3291},
    {"Level": 43, "RequiredXp": 1080, "GiftDropId": 3291},
    {"Level": 44, "RequiredXp": 1080, "GiftDropId": 3291},
    {"Level": 45, "RequiredXp": 1080, "GiftDropId": 3291},
    {"Level": 46, "RequiredXp": 1080, "GiftDropId": 3291},
    {"Level": 47, "RequiredXp": 1080, "GiftDropId": 3291},
    {"Level": 48, "RequiredXp": 1080, "GiftDropId": 3291},
    {"Level": 49, "RequiredXp": 1080, "GiftDropId": 3291},
    {"Level": 50, "RequiredXp": 1080, "GiftDropId": 3290},
    {"Level": 51, "RequiredXp": 270, "GiftDropId": 33363},
    {"Level": 52, "RequiredXp": 270, "GiftDropId": 3292},
    {"Level": 53, "RequiredXp": 297, "GiftDropId": 33462},
    {"Level": 54, "RequiredXp": 297, "GiftDropId": 3291},
    {"Level": 55, "RequiredXp": 297, "GiftDropId": 18152},
    {"Level": 56, "RequiredXp": 356, "GiftDropId": 3292},
    {"Level": 57, "RequiredXp": 356, "GiftDropId": 33466},
    {"Level": 58, "RequiredXp": 356, "GiftDropId": 3291},
    {"Level": 59, "RequiredXp": 356, "GiftDropId": 3314},
    {"Level": 60, "RequiredXp": 356, "GiftDropId": 3290},
    {"Level": 61, "RequiredXp": 428, "GiftDropId": 3292},
    {"Level": 62, "RequiredXp": 428, "GiftDropId": 33338},
    {"Level": 63, "RequiredXp": 428, "GiftDropId": 3292},
    {"Level": 64, "RequiredXp": 428, "GiftDropId": 33463},
    {"Level": 65, "RequiredXp": 428, "GiftDropId": 4463},
    {"Level": 66, "RequiredXp": 428, "GiftDropId": 3291},
    {"Level": 67, "RequiredXp": 428, "GiftDropId": 3880},
    {"Level": 68, "RequiredXp": 428, "GiftDropId": 3292},
    {"Level": 69, "RequiredXp": 428, "GiftDropId": 33464},
    {"Level": 70, "RequiredXp": 428, "GiftDropId": 33329},
    {"Level": 71, "RequiredXp": 556, "GiftDropId": 3292},
    {"Level": 72, "RequiredXp": 556, "GiftDropId": 3025},
    {"Level": 73, "RequiredXp": 556, "GiftDropId": 3291},
    {"Level": 74, "RequiredXp": 556, "GiftDropId": 33305},
    {"Level": 75, "RequiredXp": 556, "GiftDropId": 33467},
    {"Level": 76, "RequiredXp": 556, "GiftDropId": 3292},
    {"Level": 77, "RequiredXp": 556, "GiftDropId": 33465},
    {"Level": 78, "RequiredXp": 556, "GiftDropId": 3291},
    {"Level": 79, "RequiredXp": 556, "GiftDropId": 33202},
    {"Level": 80, "RequiredXp": 556, "GiftDropId": 33051},
    {"Level": 81, "RequiredXp": 778, "GiftDropId": 3291},
    {"Level": 82, "RequiredXp": 778, "GiftDropId": 33335},
    {"Level": 83, "RequiredXp": 778, "GiftDropId": 3292},
    {"Level": 84, "RequiredXp": 778, "GiftDropId": 33281},
    {"Level": 85, "RequiredXp": 778, "GiftDropId": 33203},
    {"Level": 86, "RequiredXp": 778, "GiftDropId": 3291},
    {"Level": 87, "RequiredXp": 778, "GiftDropId": 33468},
]

DISABLE_QUEST_ROOMS = False

DISABLED_ACTIVITIES = {
    "949fa41f-4347-45c0-b7ac-489129174045": DISABLE_QUEST_ROOMS,
    "7e01cfe0-820a-406f-b1b3-0a5bf575235c": DISABLE_QUEST_ROOMS,
}

KNOWN_ACTIVITIES = {
    "76d98498-60a1-430c-ab76-b54a29b7a163": ("DormRoom",              "dormroom",     False),
    "cbad71af-0831-44d8-b8ef-69edafa841f6": ("RecCenter",             "reccenter",    False),
    "4078dfed-24bb-4db7-863f-578ba48d726b": ("Charades",              "charades",     False),
    "f6f7256c-e438-4299-b99e-d20bef8cf7e0": ("DiscGolf(Lake)",        "discgolflake", False),
    "d9378c9f-80bc-46fb-ad1e-1bed8a674f55": ("DiscGolf(Propulsion)",  "discgolfprop", False),
    "3d474b26-26f7-45e9-9a36-9b02847d5e6f": ("Dodgeball",            "dodgeball",    False),
    "a067557f-ca32-43e6-b6e5-daaec60b4f5a": ("TheLounge",            "lounge",       False),
    "d89f74fa-d51e-477a-a425-025a891dd499": ("Paddleball",           "paddleball",   False),
    "e122fe98-e7db-49e8-a1b1-105424b6e1f0": ("Paintball(River)",     "pbriver",      False),
    "a785267d-c579-42ea-be43-fec1992d1ca7": ("Paintball(Homestead)", "pbhomestead",  False),
    "ff4c6427-7079-4f59-b22a-69b089420827": ("Paintball(Quarry)",    "pbquarry",     False),
    "380d18b5-de9c-49f3-80f7-f4a95c1de161": ("Paintball(ClearCut)",  "pbclearcut",   False),
    "58763055-2dfb-4814-80b8-16fac5c85709": ("Paintball(Spillway)",  "pbspillway",   False),
    "91e16e35-f48f-4700-ab8a-a1b79e50e51b": ("GoldenTrophy",         "goldentrophy", False),
    "acc06e66-c2d0-4361-b0cd-46246a4c455c": ("RiseOfJumbotron",      "jumbotron",    False),
    "949fa41f-4347-45c0-b7ac-489129174045": ("CrimsonCauldron",      "crimson",      False),
    "7e01cfe0-820a-406f-b1b3-0a5bf575235c": ("IsleOfLostSkulls",    "skulls",       False),
    "6d5eea4b-f069-4ed0-9916-0e2f07df0d03": ("Soccer",              "soccer",       False),
    "239e676c-f12f-489f-bf3a-d4c383d692c3": ("LaserTag",            "lasertag",     False),
    "9932f88f-3929-43a0-a012-a40b5128e346": ("PerformanceHall",     "perfhall",     True),
    "f5fbd9c9-e853-4036-9d48-5f68e861af04": ("RoomCalibration",     "calibration",  False),
    "0a864c86-5a71-4e18-8041-8124e4dc9d98": ("ThePark",             "park",         True),
    "a75f7547-79eb-47c6-8986-6767abcb4f92": ("MakerRoom",           "makerroom",    True),
    "ca132ed0-22fe-49c8-8b76-1589ea7fcee7": ("RecCenterTest",       "reccentertest",False),
    "253fa009-6e65-4c90-91a1-7137a56a267f": ("RecRoyale(Walk)",     "royalewalk",   False),
    "b010171f-4875-4e89-baba-61e878cd41e1": ("RecRoyale(Teleport)", "royaletele",   False),
}

_SOCIAL_ACTIVITY_GUIDS = {
    "76d98498-60a1-430c-ab76-b54a29b7a163",
    "cbad71af-0831-44d8-b8ef-69edafa841f6",
    "a067557f-ca32-43e6-b6e5-daaec60b4f5a",
    "0a864c86-5a71-4e18-8041-8124e4dc9d98",
    "9932f88f-3929-43a0-a012-a40b5128e346",
    "f5fbd9c9-e853-4036-9d48-5f68e861af04",
    "ca132ed0-22fe-49c8-8b76-1589ea7fcee7",
    "a75f7547-79eb-47c6-8986-6767abcb4f92",
}

ACTIVITY_XP = {
    "4078dfed-24bb-4db7-863f-578ba48d726b": (50, 100),
    "f6f7256c-e438-4299-b99e-d20bef8cf7e0": (50, 100),
    "d9378c9f-80bc-46fb-ad1e-1bed8a674f55": (50, 100),
    "d89f74fa-d51e-477a-a425-025a891dd499": (50, 100),
    "3d474b26-26f7-45e9-9a36-9b02847d5e6f": (75, 150),
    "e122fe98-e7db-49e8-a1b1-105424b6e1f0": (75, 150),
    "a785267d-c579-42ea-be43-fec1992d1ca7": (75, 150),
    "ff4c6427-7079-4f59-b22a-69b089420827": (75, 150),
    "380d18b5-de9c-49f3-80f7-f4a95c1de161": (75, 150),
    "58763055-2dfb-4814-80b8-16fac5c85709": (75, 150),
    "6d5eea4b-f069-4ed0-9916-0e2f07df0d03": (75, 150),
    "239e676c-f12f-489f-bf3a-d4c383d692c3": (75, 150),
    "91e16e35-f48f-4700-ab8a-a1b79e50e51b": (75, 150),
    "7e01cfe0-820a-406f-b1b3-0a5bf575235c": (100, 200),
    "949fa41f-4347-45c0-b7ac-489129174045": (100, 200),
    "acc06e66-c2d0-4361-b0cd-46246a4c455c": (100, 200),
    "253fa009-6e65-4c90-91a1-7137a56a267f": (150, 300),
    "b010171f-4875-4e89-baba-61e878cd41e1": (150, 300),
}

def get_activity_base_xp(activity_guid):
    if not activity_guid or activity_guid in _SOCIAL_ACTIVITY_GUIDS:
        return (0, 0)
    return ACTIVITY_XP.get(activity_guid, (50, 150))

WEEKLY_CHALLENGES = [
    {"id": 1, "title": "Dodgeball Champion",    "activity_guid": "3d474b26-26f7-45e9-9a36-9b02847d5e6f", "activity_int": 5000,  "target": 3, "reward_xp": 4000, "reward_rarity": 20},
    {"id": 2, "title": "Skull Island Survivor", "activity_guid": "7e01cfe0-820a-406f-b1b3-0a5bf575235c", "activity_int": 9000,  "target": 3, "reward_xp": 4000, "reward_rarity": 20},
    {"id": 3, "title": "Soccer Star",           "activity_guid": "6d5eea4b-f069-4ed0-9916-0e2f07df0d03", "activity_int": 10000, "target": 3, "reward_xp": 4000, "reward_rarity": 20},
    {"id": 4, "title": "Crimson Cauldron Run",  "activity_guid": "949fa41f-4347-45c0-b7ac-489129174045", "activity_int": 9000,  "target": 3, "reward_xp": 5000, "reward_rarity": 30},
    {"id": 5, "title": "Jumbotron Jockey",      "activity_guid": "acc06e66-c2d0-4361-b0cd-46246a4c455c", "activity_int": 9000,  "target": 3, "reward_xp": 4000, "reward_rarity": 20},
    {"id": 6, "title": "Disc Golf Pro",         "activity_guid": "f6f7256c-e438-4299-b99e-d20bef8cf7e0", "activity_int": 4000,  "target": 5, "reward_xp": 4500, "reward_rarity": 20},
    {"id": 7, "title": "Rec Royale Veteran",    "activity_guid": "b010171f-4875-4e89-baba-61e878cd41e1", "activity_int": 18000, "target": 3, "reward_xp": 6000, "reward_rarity": 30},
    {"id": 8, "title": "Laser Tag Sharpshooter","activity_guid": "239e676c-f12f-489f-bf3a-d4c383d692c3", "activity_int": 15000, "target": 3, "reward_xp": 4000, "reward_rarity": 20},
]

def _obj(t, s, xp=200):
    return {"type": t, "score": s, "xp": xp, "descriptionOverride": None, "tooltipOverride": None}

DAILY_OBJECTIVE_SETS = [
    [_obj(1030, 1), _obj(1033, 10), _obj(2000, 1)],
    [_obj(601, 2),  _obj(32, 1),    _obj(6, 1)],
    [_obj(301, 2),  _obj(302, 2),   _obj(6, 1)],
    [_obj(701, 2),  _obj(702, 20),  _obj(32, 1)],
    [_obj(1010, 1), _obj(1013, 10), _obj(6, 1)],
    [_obj(500, 2),  _obj(502, 20),  _obj(2000, 1)],
    [_obj(1020, 1), _obj(1023, 10), _obj(32, 1)],
]

def get_current_weekly_challenge() -> dict:
    import time
    week = int(time.time()) // (7 * 86400)
    week_start = week * 7 * 86400
    try:
        from core.state import db
        override = db.get_weekly_schedule(week)
        if override:
            override["week"] = week
            override["start_time"] = week_start
            override["end_time"] = week_start + 7 * 86400
            return override
    except Exception:
        pass
    ch = WEEKLY_CHALLENGES[week % len(WEEKLY_CHALLENGES)].copy()
    ch["start_time"] = week_start
    ch["end_time"] = week_start + 7 * 86400
    ch["week"] = week
    return ch

def get_todays_objectives() -> list:
    import time
    day_wday = time.gmtime(time.time()).tm_wday
    day_dow = (day_wday + 1) % 7
    return DAILY_OBJECTIVE_SETS[day_dow]

MSG_GAME_INVITE = 0
MSG_PARTY_ACTIVITY_SWITCH = 3
MSG_FRIEND_INVITE = 4
MSG_FRIEND_STATUS_ONLINE = 20
MSG_TEXT = 30
MSG_FRIEND_REQUEST_ACCEPTED = 40

REL_NONE = 0
REL_SENT = 1
REL_RECEIVED = 2
REL_FRIEND = 3


BRANCHS = {
    "bff0c094-2d59-4f81-93dd-fc6f177ca584": "Prod",
    "fb4ce906-59c1-4ffd-af5e-6696dfad1be2": "Dev",
    "f94fa96b-7438-4323-825f-ff4dc4055db1": "BVT"
}

class specialGameMode(enum.Flag):
    None_ = 0
    MaxFiringRate = 1
    RandomEnemy = 2
    RandomLoot = 4
    BattleRoyaleLaserCannon = 8
    MainframeAssault = 16
    RandomLevels = 32
