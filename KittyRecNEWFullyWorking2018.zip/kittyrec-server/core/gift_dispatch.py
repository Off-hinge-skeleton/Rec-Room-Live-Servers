import datetime as _dt
from core.state import db


def dispatch_gift(
    pid: int,
    activity_guid: str | None,
    gift_context: int = 2,
    session_id: int | None = None,
) -> dict | None:
    from routes.avatar import _get_gift_gen_lock, _generate_gift_for_player_locked
    from routes.sessions import session_gift_count, session_gift_increment

    if activity_guid and session_gift_count(pid, activity_guid) > 0:
        return None

    date_str = _dt.date.today().isoformat()
    if not db.try_record_daily_gift(pid, date_str, activity_guid or "", max_count=20):
        return None

    with _get_gift_gen_lock(pid):
        gift = _generate_gift_for_player_locked(pid, activity_guid=activity_guid, gift_context=gift_context)

    if activity_guid:
        session_gift_increment(pid, activity_guid)

    return gift
