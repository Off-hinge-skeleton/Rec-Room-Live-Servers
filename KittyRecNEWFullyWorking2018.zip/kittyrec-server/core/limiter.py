
from flask import request as _req
from flask_limiter import Limiter


def _get_client_ip():
    cf_ip = _req.headers.get("Cf-Connecting-Ip", "").strip()
    if cf_ip:
        return cf_ip
    xff = _req.headers.get("X-Forwarded-For", "").strip()
    if xff:
        return xff.split(",")[0].strip()
    return _req.remote_addr or "127.0.0.1"


limiter = Limiter(
    _get_client_ip,
    default_limits=[],
    storage_uri="memory://",
)
