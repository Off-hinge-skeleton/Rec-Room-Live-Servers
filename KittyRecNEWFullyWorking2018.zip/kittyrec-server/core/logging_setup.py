import logging
import os
import sys
import threading
import traceback
import uuid
from logging.handlers import TimedRotatingFileHandler


_INSTANCE_ID = uuid.uuid4().hex[:8]


def _make_rotating_handler(path, fmt):
    h = TimedRotatingFileHandler(
        path, when="midnight", backupCount=3, encoding="utf-8", utc=True,
    )
    h.suffix = "%Y-%m-%d"
    h.setFormatter(logging.Formatter(fmt, datefmt="%Y-%m-%d %H:%M:%S"))
    return h


class _Tee:
    def __init__(self, stream, file_log, err_log, sec_log, level=logging.INFO):
        self._stream = stream
        self._file_log = file_log
        self._err_log = err_log
        self._sec_log = sec_log
        self._level = level
        self._buf = ""
        self._lock = threading.Lock()

    def _flush_line(self, line):
        if not line.strip():
            return
        self._file_log.log(self._level, line)
        if self._level >= logging.WARNING:
            self._err_log.log(self._level, line)
        if "[SECURITY]" in line:
            self._sec_log.log(logging.WARNING, line)

    def write(self, data):
        self._stream.write(data)
        try:
            with self._lock:
                self._buf += data
                while "\n" in self._buf:
                    line, self._buf = self._buf.split("\n", 1)
                    self._flush_line(line)
        except Exception:
            pass

    def flush(self):
        self._stream.flush()

    def fileno(self):
        return self._stream.fileno()

    def isatty(self):
        return False


def setup_logging(base_dir):
    log_dir = os.path.join(base_dir, "logs")
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, "server.log")
    err_path = os.path.join(log_dir, "errors.log")

    file_log = logging.getLogger("kittyrec.out")
    file_log.setLevel(logging.DEBUG)
    file_log.propagate = False
    file_log.addHandler(_make_rotating_handler(log_path, "%(asctime)s %(message)s"))

    err_log = logging.getLogger("kittyrec.err")
    err_log.setLevel(logging.WARNING)
    err_log.propagate = False
    err_log.addHandler(_make_rotating_handler(err_path, "%(asctime)s [%(levelname)s] %(message)s"))

    sec_log = logging.getLogger("kittyrec.sec")
    sec_log.setLevel(logging.WARNING)
    sec_log.propagate = False
    sec_log.addHandler(_make_rotating_handler(os.path.join(log_dir, "security.log"), "%(asctime)s %(message)s"))

    access_log = logging.getLogger("kittyrec.access")
    access_log.setLevel(logging.DEBUG)
    access_log.propagate = False
    access_log.addHandler(_make_rotating_handler(os.path.join(log_dir, "access.log"), "%(asctime)s %(message)s"))

    stdout_orig = sys.__stdout__
    stderr_orig = sys.__stderr__
    sys.stdout = _Tee(stdout_orig, file_log, err_log, sec_log, logging.INFO)
    sys.stderr = _Tee(stderr_orig, file_log, err_log, sec_log, logging.WARNING)

    orig_excepthook = threading.excepthook

    def _thread_excepthook(args):
        print(f"[THREAD ERROR] Uncaught exception in thread '{args.thread.name if args.thread else '?'}':")
        traceback.print_exception(args.exc_type, args.exc_value, args.exc_traceback)
        if orig_excepthook:
            orig_excepthook(args)

    threading.excepthook = _thread_excepthook

    logging.basicConfig(
        stream=stderr_orig,
        level=logging.WARNING,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    logging.getLogger("werkzeug").setLevel(logging.ERROR)

    return file_log, err_log, access_log, _INSTANCE_ID
