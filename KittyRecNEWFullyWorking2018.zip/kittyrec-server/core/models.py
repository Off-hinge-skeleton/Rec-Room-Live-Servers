
from flask_sqlalchemy import SQLAlchemy

sql_db = SQLAlchemy()


class Profile(sql_db.Model):
    __tablename__ = "profiles"
    id = sql_db.Column(sql_db.Integer, primary_key=True)
    platform = sql_db.Column(sql_db.String(50), nullable=False, default="")
    platform_id = sql_db.Column(sql_db.String(100), nullable=False, default="")
    username = sql_db.Column(sql_db.String(100), nullable=False)
    display_name = sql_db.Column(sql_db.String(100), nullable=False)
    xp = sql_db.Column(sql_db.Integer, default=0)
    level = sql_db.Column(sql_db.Integer, default=1)
    reputation = sql_db.Column(sql_db.Integer, default=0)
    developer = sql_db.Column(sql_db.Boolean, default=False)
    banned = sql_db.Column(sql_db.Boolean, default=False)
    ban_reason = sql_db.Column(sql_db.String(256), default="")
    banned_until = sql_db.Column(sql_db.String(50))
    banned_by = sql_db.Column(sql_db.String(100), default="")
    tokens = sql_db.Column(sql_db.Integer, default=500)
    bio = sql_db.Column(sql_db.Text, default="")
    created_at = sql_db.Column(sql_db.String(50))

    gifts = sql_db.relationship("Gift", backref="profile", lazy="dynamic")
    ban_logs = sql_db.relationship("BanLog", backref="profile", lazy="dynamic")

    def __repr__(self):
        return f"<Profile {self.username}>"

    def __str__(self):
        return self.username


class Gift(sql_db.Model):
    __tablename__ = "gifts"
    id = sql_db.Column(sql_db.Integer, primary_key=True)
    profile_id = sql_db.Column(sql_db.Integer, sql_db.ForeignKey("profiles.id"), nullable=False)
    avatar_item_desc = sql_db.Column(sql_db.Text, default="")
    consumable_item_desc = sql_db.Column(sql_db.Text, default="")
    equipment_prefab_name = sql_db.Column(sql_db.Text, default="")
    equipment_modification_guid = sql_db.Column(sql_db.Text, default="")
    xp = sql_db.Column(sql_db.Integer, default=0)
    gift_rarity = sql_db.Column(sql_db.Integer, default=0)
    message = sql_db.Column(sql_db.Text, default="")
    gift_context = sql_db.Column(sql_db.Integer, default=0)
    consumed = sql_db.Column(sql_db.Boolean, default=False)
    created_at = sql_db.Column(sql_db.String(50))

    def __repr__(self):
        return f"<Gift #{self.id}>"


class BanLog(sql_db.Model):
    __tablename__ = "ban_log"
    id = sql_db.Column(sql_db.Integer, primary_key=True)
    profile_id = sql_db.Column(sql_db.Integer, sql_db.ForeignKey("profiles.id"), nullable=False)
    action = sql_db.Column(sql_db.String(20), nullable=False)
    reason = sql_db.Column(sql_db.Text, default="")
    duration_hours = sql_db.Column(sql_db.Integer, default=0)
    banned_until = sql_db.Column(sql_db.String(50))
    admin_name = sql_db.Column(sql_db.String(100), default="")
    created_at = sql_db.Column(sql_db.String(50))

    def __repr__(self):
        return f"<BanLog #{self.id} {self.action}>"


class Room(sql_db.Model):
    __tablename__ = "rooms"
    id = sql_db.Column(sql_db.Integer, primary_key=True)
    creator_id = sql_db.Column(sql_db.Integer, nullable=False)
    name = sql_db.Column(sql_db.String(200), default="")
    description = sql_db.Column(sql_db.Text, default="")
    activity_level_id = sql_db.Column(sql_db.String(100), default="")
    accessibility = sql_db.Column(sql_db.Integer, default=0)
    is_sandbox = sql_db.Column(sql_db.Boolean, default=False)
    instanced = sql_db.Column(sql_db.Boolean, default=True)
    max_players = sql_db.Column(sql_db.Integer, default=20)
    special_gamemode = sql_db.Column(sql_db.Integer, default=0)
    state = sql_db.Column(sql_db.Integer, default=0)
    created_at = sql_db.Column(sql_db.String(50))
    modified_at = sql_db.Column(sql_db.String(50))

    def __repr__(self):
        return f"<Room {self.name}>"


class AdminTodo(sql_db.Model):
    __tablename__ = "admin_todos"
    id = sql_db.Column(sql_db.Integer, primary_key=True)
    title = sql_db.Column(sql_db.String(256), nullable=False)
    description = sql_db.Column(sql_db.Text, default="")
    priority = sql_db.Column(sql_db.Integer, default=1)
    status = sql_db.Column(sql_db.String(20), default="open")
    assigned_to = sql_db.Column(sql_db.String(100), default="")
    created_by = sql_db.Column(sql_db.String(100), default="")
    created_at = sql_db.Column(sql_db.String(50))
    completed_at = sql_db.Column(sql_db.String(50))

    def __repr__(self):
        return f"<Todo #{self.id} {self.title[:30]}>"


class AdminIssue(sql_db.Model):
    __tablename__ = "admin_issues"
    id = sql_db.Column(sql_db.Integer, primary_key=True)
    title = sql_db.Column(sql_db.String(256), nullable=False)
    description = sql_db.Column(sql_db.Text, default="")
    category = sql_db.Column(sql_db.String(50), default="bug")
    severity = sql_db.Column(sql_db.String(20), default="medium")
    status = sql_db.Column(sql_db.String(20), default="open")
    reported_by = sql_db.Column(sql_db.String(100), default="")
    assigned_to = sql_db.Column(sql_db.String(100), default="")
    created_at = sql_db.Column(sql_db.String(50))
    resolved_at = sql_db.Column(sql_db.String(50))

    def __repr__(self):
        return f"<Issue #{self.id} {self.title[:30]}>"
