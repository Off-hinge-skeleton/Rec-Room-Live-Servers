import os
import socket
import hashlib
import base64
from cryptography.fernet import Fernet

_SECRET_KEY_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), ".secret_key")
_fernet = None


def _get_fernet():
    global _fernet
    if _fernet is not None:
        return _fernet
    with open(_SECRET_KEY_PATH, "rb") as f:
        secret = f.read().strip()
    hostname = socket.gethostname().encode()
    salt = hashlib.sha256(hostname + b":kittyrec-pw-enc").digest()
    derived = hashlib.pbkdf2_hmac("sha256", secret, salt, 480_000)
    fernet_key = base64.urlsafe_b64encode(derived[:32])
    _fernet = Fernet(fernet_key)
    return _fernet


def encrypt_password(plaintext: str) -> str:
    token = _get_fernet().encrypt(plaintext.encode("utf-8"))
    return "enc:" + token.decode("ascii")


def decrypt_password(stored: str) -> str | None:
    if not stored or not stored.startswith("enc:"):
        return None
    try:
        token = stored[4:].encode("ascii")
        return _get_fernet().decrypt(token).decode("utf-8")
    except Exception:
        return None


def check_password(stored: str, candidate: str) -> bool:
    if not stored:
        return False
    if stored.startswith("enc:"):
        plaintext = decrypt_password(stored)
        return plaintext is not None and plaintext == candidate
    if stored.startswith(("pbkdf2:", "scrypt:", "argon2:")):
        from werkzeug.security import check_password_hash
        return check_password_hash(stored, candidate)
    return stored == candidate


def has_password(stored: str) -> bool:
    if not stored:
        return False
    if stored.startswith("enc:"):
        return True
    if stored.startswith(("pbkdf2:", "scrypt:", "argon2:")):
        return True
    return False
