
from .state import ws_registry, db


def push_presence(player_id: int, session=None, online: bool = True) -> None:
    ws_registry.broadcast({
        "Id": 12,
        "Msg": {
            "PlayerId": player_id,
            "IsOnline": online,
            "InScreenMode": ws_registry.is_screen_mode(player_id),
            "GameSession": session.to_dict() if session else None,
        },
    })

def push_gift(player_id: int, gift: dict) -> bool:
    sent = ws_registry.send(player_id, {"Id": 30, "Msg": gift})
    print(f"[Push] Gift id={gift.get('Id')} → pid={player_id} sent={sent}")
    if sent and gift.get("Id"):
        db.mark_gift_pushed(gift["Id"])
    return sent

def push_store_balance(player_id: int, new_balance: int, currency_type: int, amount: int) -> None:
    ws_registry.send(player_id, {
        "Id": 60,
        "Msg": {
            "Balance": new_balance,
            "CurrencyType": currency_type,
            "BalanceUpdates": [{
                "UpdateResponse": 0,
                "Data": {
                    "BalanceAddType": 5,
                    "BaseAward": amount,
                    "BalanceInGiftBox": True,
                },
            }],
        },
    })

def push_kick(player_id: int, session_id: int = 0, reason: int = -1, message: str = "Kicked by admin") -> None:
    ws_registry.send(player_id, {
        "Id": 22,
        "Msg": {
            "ReportCategory": reason,
            "Duration": 0,
            "GameSessionId": session_id,
            "Message": message,
        },
    })

def push_profile_update(player_id: int) -> None:
    from .builders import make_profile_from_db
    profile_row = db.get_profile(player_id)
    if profile_row is None:
        return
    ws_registry.broadcast({
        "Id": 11,
        "Msg": make_profile_from_db(profile_row),
    })

def push_room_update(player_id: int, room_dict: dict) -> None:
    ws_registry.send(player_id, {"Id": 14, "Msg": room_dict})

def push_session_update(player_id: int, session) -> None:
    ws_registry.send(player_id, {"Id": 13, "Msg": session.to_dict()})

def _consumable_row_to_msg(row: dict) -> dict:
    return {
        "Id": row["id"],
        "ConsumableItemDesc": row["consumable_item_desc"],
        "CreatedAt": row["created_at"].replace(" ", "T") + "Z" if "T" not in row["created_at"] else row["created_at"],
        "Count": row["count"],
        "UnlockedLevel": row["unlocked_level"],
        "IsActive": bool(row["is_active"]),
    }

def push_consumable_added(player_id: int, consumable_row: dict) -> None:
    ws_registry.send(player_id, {"Id": 70, "Msg": _consumable_row_to_msg(consumable_row)})

def push_consumable_removed(player_id: int, consumable_row: dict) -> None:
    ws_registry.send(player_id, {"Id": 71, "Msg": _consumable_row_to_msg(consumable_row)})
