worker_class = "gevent"
workers = 1
worker_connections = 1000
bind = "0.0.0.0:8080"
timeout = 120
keepalive = 5
loglevel = "warning"
accesslog = "-"
errorlog = "-"


def on_starting(server):
    import glob, os
    for f in glob.glob('/tmp/_kr_started_*'):
        try:
            os.unlink(f)
        except Exception:
            pass
