
import json
import os
import random

from functools import wraps


from flask import Blueprint, request, jsonify, Response, abort, send_file, send_from_directory
from core.config import server as _server_cfg
from core.state import db

bp = Blueprint("KittyLoader", __name__)

@bp.before_request
def _check_ua():
    if request.path == "/api/kittyloader/v1/KittyRec/getfile":
        return
    ua = request.headers.get("User-Agent", "")
    if not ua.startswith("KittyLoader/"):
        return abort(403)

Branchs = {
    "bff0c094-2d59-4f81-93dd-fc6f177ca584": "Prod",
    "fb4ce906-59c1-4ffd-af5e-6696dfad1be2": "Dev",
    "f94fa96b-7438-4323-825f-ff4dc4055db1": "BVT"
}

proxyUrl = _server_cfg.get("kittyloader_proxy", "http://localhost:5242")

def getBranch(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        Branch = request.headers.get("Branch")
        if Branch is None:
            return abort(403)
        if Branch not in Branchs:
            return abort(403)
        return f(Branch, *args, **kwargs)
    return decorated

@bp.route("/api/kittyloader/v1/start", methods=["GET"])
@getBranch
def start(Branch):
    db.save_amplitude_event(
        0, "kittyloader_start", 0,
        {"branch": Branchs.get(Branch, Branch), "ua": request.headers.get("User-Agent", "")},
        {}, "", "",
    )
    return jsonify({"exit": False})

@bp.route("/api/kittyloader/v1/exit", methods=["GET"])
@getBranch
def exit(Branch):
    return Response("", 200)

@bp.route("/api/kittyloader/v1/KittyRec/getfile", methods=["GET"])
def kittyrec_getfile():
    FileName = request.args.get("filename")
    if FileName is None:
        return abort(400)
    try:

        return send_from_directory(directory="kittyrec_dlls", path=FileName)
    except FileNotFoundError:
        return abort(404)

@bp.route("/api/kittyloader/v1/KittyRec/get", methods=["GET"])
@getBranch
def kittyrec(Branch):
    with open(os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "KittyRecDlls.json")) as f:
        jsonData: dict = json.load(f)
    if jsonData.get(Branch) is None:
        return abort(404)
    data = jsonData.get(Branch)
    return jsonify({
        "FileUrl": f"{proxyUrl}/api/kittyloader/v1/KittyRec/getfile?filename={data['file']}",
        "SHA512": data["hash"]
    })
