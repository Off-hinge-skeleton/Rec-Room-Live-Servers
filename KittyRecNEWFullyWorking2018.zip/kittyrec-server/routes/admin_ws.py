import json

from core.state import db
from routes.portal import _get_admin_account, _has_any_admin_scope


def _send(ws, msg: dict) -> None:
    try:
        ws.send(json.dumps(msg))
    except Exception:
        pass


def register_admin_ws(sock) -> None:

    @sock.route("/admin/ws")
    def admin_ws_handler(ws):
        account, scopes = _get_admin_account()
        if not account or not _has_any_admin_scope(scopes):
            ws.close()
            return

        import core.admin_ws as awr
        awr.register(ws)

        try:
            from routes.misc import get_sanitize_log
            from core.anticheat import get_suspects
            suspects = get_suspects()
            _send(ws, {"type": "init", "sanitize_log": get_sanitize_log(), "suspects": suspects})
        except Exception as e:
            print(f"[AdminWS] init error: {e}")

        try:
            while True:
                msg = ws.receive(timeout=30)
                if msg is None:
                    break
        except Exception:
            pass
        finally:
            awr.unregister(ws)
