
from flask import Blueprint, request, jsonify

from core.auth import get_server_base
from core.builders import now_ticks
from core.constants import LEVEL_PROGRESSION_MAPS, DAILY_OBJECTIVE_SETS, get_todays_objectives

bp = Blueprint("config", __name__)

@bp.route("/api/versioncheck/v3", methods=["GET"])
def version_check():
    return jsonify({"ValidVersion": True})

@bp.route("/api/config/v2", methods=["GET"])
def get_config():
    base = get_server_base()
    return jsonify({
        "MessageOfTheDay": "Welcome to KittyRec indev!",
        "CdnBaseUri": base,
        "MatchmakingParams": {
            "PreferFullRoomsFrequency": 0.5,
            "PreferEmptyRoomsFrequency": 0.5,
        },
        "ServerMaintenance": {
            "StartsInMinutes": -1,
        },
        "LevelProgressionMaps": LEVEL_PROGRESSION_MAPS,
        "DailyObjectives": DAILY_OBJECTIVE_SETS,
        "ConfigTable": [
            {"Key": "ShareCamera.Enabled",      "Value": "1"},
            {"Key": "CustomRooms.Enabled",       "Value": "1"},
            {"Key": "ChallengesV2.Enabled",      "Value": "1"},
            {"Key": "Consumables.Enabled",       "Value": "1"},
            {"Key": "Rooms.MaxCustomRooms",      "Value": "100"},
            {"Key": "Gift.DropChance",           "Value": "1.0"},
            {"Key": "Gift.Falloff",              "Value": "1.2"},
            {"Key": "Gift.MaxDaily",             "Value": "10"},
        ],
        "PhotonConfig": {
            "CrcCheckEnabled": False,
            "EnableServerTracingAfterDisconnect": False,
        },
    })

@bp.route("/api/config/v1/amplitude", methods=["GET"])
def get_amplitude_config():
    return jsonify({"AmplitudeKey": "meowmeowmeow"})
