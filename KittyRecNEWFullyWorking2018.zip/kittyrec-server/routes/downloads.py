import hashlib
import json
import os
import secrets
import shutil
import time
import uuid
import zipfile
from datetime import datetime, timezone

from flask import Blueprint, request, jsonify, render_template, Response, abort

from routes.portal import require_admin_api, require_scope, SCOPE_ADMIN

bp = Blueprint("downloads", __name__)

_DL_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "downloads")
_FILES_DIR = os.path.join(_DL_DIR, "files")
_TMP_DIR = os.path.join(_DL_DIR, "tmp")
_INDEX = os.path.join(_DL_DIR, "index.json")
_LAUNCHER_EXE   = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "data", "launcher", "KittyRecLauncher.exe"))
_HTTPPROXY_EXE  = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "HttpProxyReplacement", "HttpProxyReplacement.exe"))

_CHUNK_MAX = 10 * 1024 * 1024
_COMPILED_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "gamecode", "compiled"))
_COMPILED_PREV_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "gamecode", "compiled_prev"))


def _extract_to_compiled(zip_path, build_name):
    try:
        if not zipfile.is_zipfile(zip_path):
            print(f"[Downloads] extract: {zip_path} is not a valid zip, skipping extract")
            return False
        if os.path.isdir(_COMPILED_PREV_DIR):
            shutil.rmtree(_COMPILED_PREV_DIR, ignore_errors=True)
        if os.path.isdir(_COMPILED_DIR):
            os.rename(_COMPILED_DIR, _COMPILED_PREV_DIR)
        os.makedirs(_COMPILED_DIR, exist_ok=True)
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(_COMPILED_DIR)
        print(f"[Downloads] extracted '{build_name}' → {_COMPILED_DIR}")
        return True
    except Exception as e:
        print(f"[Downloads] extract failed for '{build_name}': {e}")
        if os.path.isdir(_COMPILED_PREV_DIR) and not os.path.isdir(_COMPILED_DIR):
            os.rename(_COMPILED_PREV_DIR, _COMPILED_DIR)
        return False


def _ensure_dirs():
    os.makedirs(_FILES_DIR, exist_ok=True)
    os.makedirs(_TMP_DIR, exist_ok=True)


def _cleanup_stale_sessions():
    if not os.path.exists(_TMP_DIR):
        return
    cutoff = time.time() - 86400
    for name in os.listdir(_TMP_DIR):
        path = os.path.join(_TMP_DIR, name)
        try:
            if os.path.isdir(path) and os.path.getmtime(path) < cutoff:
                shutil.rmtree(path, ignore_errors=True)
        except Exception:
            pass


def _load_index():
    if not os.path.exists(_INDEX):
        return []
    with open(_INDEX) as f:
        return json.load(f)


def _save_index(builds):
    _ensure_dirs()
    with open(_INDEX, "w") as f:
        json.dump(builds, f, indent=2)


def _find_build(builds, h1, h2, h3):
    for b in builds:
        if b["h1"] == h1 and b["h2"] == h2 and b["h3"] == h3:
            return b
    return None


def _normalize_filename(name: str) -> str:
    import re
    s = name.encode("ascii", "replace").decode("ascii")
    s = re.sub(r'[^\w.\-]', '_', s)
    s = re.sub(r'_+', '_', s).strip('_')
    return s or "build"


def _content_disposition(build_name: str) -> str:
    from urllib.parse import quote as _quote
    safe = _normalize_filename(build_name) + ".zip"
    encoded = _quote((build_name + ".zip").encode("utf-8"), safe="")
    return f"attachment; filename=\"{safe}\"; filename*=UTF-8''{encoded}"


def _stream_file(path, filename):
    size = os.path.getsize(path)
    range_header = request.headers.get("Range")

    if range_header:
        try:
            byte_range = range_header.replace("bytes=", "").split("-")
            start = int(byte_range[0])
            end = int(byte_range[1]) if byte_range[1] else size - 1
        except Exception:
            start, end = 0, size - 1
        end = min(end, size - 1)
        length = end - start + 1

        def generate():
            with open(path, "rb") as f:
                f.seek(start)
                remaining = length
                while remaining > 0:
                    chunk = f.read(min(65536, remaining))
                    if not chunk:
                        break
                    remaining -= len(chunk)
                    yield chunk

        headers = {
            "Content-Range": f"bytes {start}-{end}/{size}",
            "Accept-Ranges": "bytes",
            "Content-Length": str(length),
            "Content-Disposition": _content_disposition(filename),
            "Content-Type": "application/zip",
            "Cache-Control": "no-store",
        }
        return Response(generate(), status=206, headers=headers)

    def generate_full():
        with open(path, "rb") as f:
            while True:
                chunk = f.read(65536)
                if not chunk:
                    break
                yield chunk

    headers = {
        "Accept-Ranges": "bytes",
        "Content-Length": str(size),
        "Content-Disposition": _content_disposition(filename),
        "Content-Type": "application/zip",
        "Cache-Control": "no-store",
    }
    return Response(generate_full(), status=200, headers=headers)


@bp.route("/api/launcher/v1/manifest")
def launcher_manifest():
    from urllib.parse import quote as _quote
    builds = _load_index()
    meta = _load_meta_current()
    current_id = meta.get("current_build_id") if meta else None
    if not current_id:
        return jsonify({"error": "No build available"}), 404
    build = next((b for b in builds if b["id"] == current_id and b.get("enabled")), None)
    if not build:
        return jsonify({"error": "No build available"}), 404
    dl_url = f"/download/{_quote(build['date'])}/{_quote(build['build_name'])}/{build['h1']}/{build['h2']}/{build['h3']}/get"
    return jsonify({
        "build_id": build["id"],
        "build_name": build["build_name"],
        "sha256": build["sha256"],
        "size": build["size"],
        "download_url": dl_url,
        "date": build["date"],
        "download_count": build.get("download_count", 0),
    })


@bp.route("/download/launcher")
def download_launcher():
    if not os.path.exists(_LAUNCHER_EXE):
        abort(404)
    size = os.path.getsize(_LAUNCHER_EXE)
    def generate():
        with open(_LAUNCHER_EXE, "rb") as f:
            while True:
                chunk = f.read(65536)
                if not chunk:
                    break
                yield chunk
    return Response(generate(), status=200, headers={
        "Content-Type": "application/octet-stream",
        "Content-Disposition": "attachment; filename=\"KittyRecLauncher.exe\"",
        "Content-Length": str(size),
        "Cache-Control": "no-store",
    })


@bp.route("/download/httpproxy")
def download_httpproxy():
    if not os.path.exists(_HTTPPROXY_EXE):
        abort(404)
    size = os.path.getsize(_HTTPPROXY_EXE)
    def generate():
        with open(_HTTPPROXY_EXE, "rb") as f:
            while True:
                chunk = f.read(65536)
                if not chunk:
                    break
                yield chunk
    return Response(generate(), status=200, headers={
        "Content-Type": "application/octet-stream",
        "Content-Disposition": "attachment; filename=\"HttpProxyReplacement.exe\"",
        "Content-Length": str(size),
        "Cache-Control": "no-store",
    })


@bp.route("/download/current")
def download_current():
    from urllib.parse import quote as _quote
    builds = _load_index()
    meta = _load_meta_current()
    current_id = meta.get("current_build_id") if meta else None
    if not current_id:
        return render_template("download_unavailable.html"), 404
    build = next((b for b in builds if b["id"] == current_id and b.get("enabled")), None)
    if not build:
        return render_template("download_unavailable.html"), 404
    dl_url = f"/download/{_quote(build['date'])}/{_quote(build['build_name'])}/{build['h1']}/{build['h2']}/{build['h3']}/get"
    return render_template("download_page.html", build=build, dl_url=dl_url)


def _load_meta_current():
    path = os.path.join(_DL_DIR, "current.json")
    if not os.path.exists(path):
        return {}
    with open(path) as f:
        return json.load(f)


def _save_meta_current(data):
    _ensure_dirs()
    with open(os.path.join(_DL_DIR, "current.json"), "w") as f:
        json.dump(data, f)


@bp.route("/admin/api/downloads/set_current/<build_id>", methods=["POST"])
@require_scope(SCOPE_ADMIN)
def set_current_build(build_id, account, scopes):
    builds = _load_index()
    build = next((b for b in builds if b["id"] == build_id), None)
    if not build:
        return jsonify({"error": "Not found"}), 404
    _save_meta_current({"current_build_id": build_id})
    print(f"[Downloads] {account.get('username')} set current build to '{build['build_name']}'")
    return jsonify({"ok": True})


@bp.route("/download/<date>/<build_name>/<h1>/<h2>/<h3>")
def download_page(date, build_name, h1, h2, h3):
    from urllib.parse import quote as _quote
    builds = _load_index()
    build = _find_build(builds, h1, h2, h3)
    if not build or not build.get("enabled"):
        return render_template("download_unavailable.html"), 404
    dl_url = f"/download/{_quote(build['date'])}/{_quote(build['build_name'])}/{h1}/{h2}/{h3}/get"
    return render_template("download_page.html", build=build, dl_url=dl_url)


@bp.route("/download/<date>/<build_name>/<h1>/<h2>/<h3>/get")
def download_file(date, build_name, h1, h2, h3):
    builds = _load_index()
    build = _find_build(builds, h1, h2, h3)
    if not build or not build.get("enabled"):
        abort(404)
    path = os.path.join(_FILES_DIR, build["id"] + ".zip")
    if not os.path.exists(path):
        abort(404)
    for b in builds:
        if b["id"] == build["id"]:
            b["download_count"] = b.get("download_count", 0) + 1
            break
    _save_index(builds)
    print(f"[Downloads] Serving '{build['build_name']}' to {request.remote_addr}")
    return _stream_file(path, build["build_name"])


@bp.route("/admin/api/downloads/upload/start", methods=["POST"])
@require_scope(SCOPE_ADMIN)
def upload_start(account, scopes):
    _ensure_dirs()
    _cleanup_stale_sessions()
    data = request.get_json(force=True, silent=True) or {}
    build_name = str(data.get("build_name", "")).strip()[:128]
    if not build_name:
        return jsonify({"error": "build_name required"}), 400
    session_id = str(uuid.uuid4())
    session_dir = os.path.join(_TMP_DIR, session_id)
    os.makedirs(session_dir)
    with open(os.path.join(session_dir, "meta.json"), "w") as f:
        json.dump({"build_name": build_name, "uploaded_by": account.get("username", "admin"), "started_at": time.time()}, f)
    return jsonify({"ok": True, "session_id": session_id})


@bp.route("/admin/api/downloads/upload/chunk", methods=["POST"])
@require_scope(SCOPE_ADMIN)
def upload_chunk(account, scopes):
    session_id = request.form.get("session_id", "")
    chunk_index = request.form.get("chunk_index", "")
    if not session_id or chunk_index == "":
        return jsonify({"error": "session_id and chunk_index required"}), 400
    session_dir = os.path.join(_TMP_DIR, session_id)
    if not os.path.isdir(session_dir):
        return jsonify({"error": "Unknown session"}), 404
    chunk_file = request.files.get("chunk")
    if not chunk_file:
        return jsonify({"error": "No chunk data"}), 400
    chunk_path = os.path.join(session_dir, f"chunk_{int(chunk_index):08d}")
    chunk_file.save(chunk_path)
    return jsonify({"ok": True, "received": int(chunk_index)})


@bp.route("/admin/api/downloads/upload/finalize", methods=["POST"])
@require_scope(SCOPE_ADMIN)
def upload_finalize(account, scopes):
    data = request.get_json(force=True, silent=True) or {}
    session_id = data.get("session_id", "")
    total_chunks = int(data.get("total_chunks", 0))
    if not session_id or not total_chunks:
        return jsonify({"error": "session_id and total_chunks required"}), 400
    session_dir = os.path.join(_TMP_DIR, session_id)
    if not os.path.isdir(session_dir):
        return jsonify({"error": "Unknown session"}), 404
    meta_path = os.path.join(session_dir, "meta.json")
    with open(meta_path) as f:
        meta = json.load(f)
    build_id = str(uuid.uuid4())
    dest = os.path.join(_FILES_DIR, build_id + ".zip")
    sha = hashlib.sha256()
    size = 0
    with open(dest, "wb") as out:
        for i in range(total_chunks):
            chunk_path = os.path.join(session_dir, f"chunk_{i:08d}")
            if not os.path.exists(chunk_path):
                os.remove(dest)
                shutil.rmtree(session_dir, ignore_errors=True)
                return jsonify({"error": f"Missing chunk {i}"}), 400
            with open(chunk_path, "rb") as cf:
                while True:
                    buf = cf.read(65536)
                    if not buf:
                        break
                    out.write(buf)
                    sha.update(buf)
                    size += len(buf)
    shutil.rmtree(session_dir, ignore_errors=True)
    if size == 0:
        os.remove(dest)
        return jsonify({"error": "Empty file after assembly"}), 400
    h1 = secrets.token_hex(8)
    h2 = secrets.token_hex(8)
    h3 = secrets.token_hex(8)
    date_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    build = {
        "id": build_id,
        "date": date_str,
        "build_name": meta["build_name"],
        "h1": h1, "h2": h2, "h3": h3,
        "size": size,
        "sha256": sha.hexdigest(),
        "enabled": True,
        "uploaded_at": datetime.now(timezone.utc).isoformat(),
        "uploaded_by": meta.get("uploaded_by", "admin"),
        "download_count": 0,
    }
    builds = _load_index()
    builds.append(build)
    _save_index(builds)
    url = f"/download/{date_str}/{meta['build_name']}/{h1}/{h2}/{h3}"
    print(f"[Downloads] {meta.get('uploaded_by')} uploaded '{meta['build_name']}' ({size} bytes, {total_chunks} chunks) → {url}")
    _extract_to_compiled(dest, meta["build_name"])
    return jsonify({"ok": True, "url": url, "build": build})


@bp.route("/admin/api/downloads/upload", methods=["POST"])
@require_scope(SCOPE_ADMIN)
def upload_build(account, scopes):
    _ensure_dirs()

    build_name = request.form.get("build_name", "").strip()[:128]
    if not build_name:
        return jsonify({"error": "build_name required"}), 400

    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify({"error": "No file provided"}), 400
    if not f.filename.lower().endswith(".zip"):
        return jsonify({"error": "Must be a .zip file"}), 400

    build_id = str(uuid.uuid4())
    dest = os.path.join(_FILES_DIR, build_id + ".zip")

    f.save(dest)

    size = os.path.getsize(dest)
    if size == 0:
        os.remove(dest)
        return jsonify({"error": "Empty file"}), 400

    sha = hashlib.sha256()
    with open(dest, "rb") as fh:
        while True:
            chunk = fh.read(65536)
            if not chunk:
                break
            sha.update(chunk)

    h1 = secrets.token_hex(8)
    h2 = secrets.token_hex(8)
    h3 = secrets.token_hex(8)
    date_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    build = {
        "id": build_id,
        "date": date_str,
        "build_name": build_name,
        "h1": h1,
        "h2": h2,
        "h3": h3,
        "size": size,
        "sha256": sha.hexdigest(),
        "enabled": True,
        "uploaded_at": datetime.now(timezone.utc).isoformat(),
        "uploaded_by": account.get("username", "admin"),
        "download_count": 0,
    }

    builds = _load_index()
    builds.append(build)
    _save_index(builds)

    url = f"/download/{date_str}/{build_name}/{h1}/{h2}/{h3}"
    print(f"[Downloads] {account.get('username')} uploaded '{build_name}' ({size} bytes) → {url}")
    _extract_to_compiled(dest, build_name)
    return jsonify({"ok": True, "url": url, "build": build})


@bp.route("/admin/api/downloads/list", methods=["GET"])
@require_admin_api
def list_builds(account, scopes):
    builds = _load_index()
    current_id = _load_meta_current().get("current_build_id")
    return jsonify({"builds": builds, "current_build_id": current_id})


@bp.route("/admin/api/downloads/toggle/<build_id>", methods=["POST"])
@require_scope(SCOPE_ADMIN)
def toggle_build(build_id, account, scopes):
    builds = _load_index()
    for b in builds:
        if b["id"] == build_id:
            b["enabled"] = not b.get("enabled", True)
            _save_index(builds)
            return jsonify({"ok": True, "enabled": b["enabled"]})
    return jsonify({"error": "Not found"}), 404


@bp.route("/admin/api/downloads/rename/<build_id>", methods=["POST"])
@require_scope(SCOPE_ADMIN)
def rename_build(build_id, account, scopes):
    data = request.get_json(force=True, silent=True) or {}
    new_name = str(data.get("build_name", "")).strip()[:128]
    if not new_name:
        return jsonify({"error": "build_name required"}), 400
    builds = _load_index()
    for b in builds:
        if b["id"] == build_id:
            old_name = b["build_name"]
            b["build_name"] = new_name
            _save_index(builds)
            print(f"[Downloads] {account.get('username')} renamed '{old_name}' → '{new_name}'")
            return jsonify({"ok": True, "build_name": new_name})
    return jsonify({"error": "Not found"}), 404


@bp.route("/admin/api/downloads/delete/<build_id>", methods=["POST"])
@require_scope(SCOPE_ADMIN)
def delete_build(build_id, account, scopes):
    builds = _load_index()
    build = next((b for b in builds if b["id"] == build_id), None)
    if not build:
        return jsonify({"error": "Not found"}), 404
    path = os.path.join(_FILES_DIR, build_id + ".zip")
    if os.path.exists(path):
        os.remove(path)
    builds = [b for b in builds if b["id"] != build_id]
    _save_index(builds)
    print(f"[Downloads] {account.get('username')} deleted build '{build.get('build_name')}'")
    return jsonify({"ok": True})
