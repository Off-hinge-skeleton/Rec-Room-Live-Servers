import time

from flask import Blueprint, jsonify

from core.state import db, session_mgr, ws_registry
import core.state as _state
from core.config import server as _server_cfg

bp = Blueprint("health", __name__)

SERVER_BUILD = _server_cfg.get("build", "KittyRec")
_start_time = time.time()


def _check_db():
    t0 = time.monotonic()
    try:
        db.get_profile(23)
        latency_ms = round((time.monotonic() - t0) * 1000, 2)
        return "ok", latency_ms
    except Exception as e:
        latency_ms = round((time.monotonic() - t0) * 1000, 2)
        return f"error: {e}", latency_ms


@bp.route("/health")
def health():
    db_status, db_latency_ms = _check_db()
    online = len(ws_registry.connected_ids())
    sessions = len(session_mgr.all_public_sessions())

    ok = db_status == "ok"
    status = "ok" if ok else "degraded"

    return jsonify({
        "status": status,
        "build": SERVER_BUILD,
        "uptime_seconds": int(time.time() - _start_time),
        "database": {
            "status": db_status,
            "latency_ms": db_latency_ms,
        },
        "players": {
            "online": online,
            "active_sessions": sessions,
        },
        "maintenance": _state.maintenance_mode,
    }), 200 if ok else 503
