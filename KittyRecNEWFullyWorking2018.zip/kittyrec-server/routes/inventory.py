
from flask import Blueprint, Response, jsonify

from core.auth import check_auth

bp = Blueprint("inventory", __name__)

@bp.route("/api/equipment/v1/unlock", methods=["POST"])
@check_auth
def unlock_equipment():
    return Response("OK", 200)

@bp.route("/api/equipment/v1/gift", methods=["POST"])
@check_auth
def gift_equipment():
    return Response("OK", 200)

@bp.route("/api/consumables/v1/getUnlocked", methods=["GET"])
@check_auth
def get_unlocked_consumables():
    return jsonify([])

@bp.route("/api/consumables/v1/consume", methods=["POST"])
@check_auth
def consume_consumable():
    return Response("", 200)

@bp.route("/api/consumables/v1/updateActive", methods=["POST"])
@check_auth
def update_consumable_active():
    return Response("", 200)

@bp.route("/api/consumables/v1/use", methods=["POST"])
@check_auth
def use_consumable():
    return Response("OK", 200)

@bp.route("/api/consumables/v1/gift", methods=["POST"])
@check_auth
def gift_consumable():
    return Response("OK", 200)
