
import mimetypes
import os

from flask import Blueprint, Response, abort

bp = Blueprint("media", __name__)

_PUBLIC_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "public")
_VIDEOS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "Videos")

_EXTRACTED_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "gamecode", "extracted")

_VIDEO_EXTS = {".mp4", ".webm", ".mov", ".avi", ".mkv", ".m4v"}
_IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}
_AUDIO_EXTS = {".ogg", ".wav", ".mp3", ".fsb"}
_FONT_EXTS = {".ttf", ".otf"}
_ALLOWED_EXTS = _VIDEO_EXTS | _IMAGE_EXTS | _AUDIO_EXTS | _FONT_EXTS | {".json", ".txt", ".svg", ".dll", ".shader", ".xml", ".bytes"}


def _serve_file(directory, filename):
    path = os.path.realpath(os.path.join(directory, filename))
    if not path.startswith(os.path.realpath(directory) + os.sep):
        abort(403)
    safe_name = os.path.basename(path)

    if not os.path.isfile(path):
        abort(404)

    ext = os.path.splitext(safe_name)[1].lower()
    if ext not in _ALLOWED_EXTS:
        abort(403)

    mime = mimetypes.guess_type(safe_name)[0] or "application/octet-stream"
    size = os.path.getsize(path)

    def stream():
        with open(path, "rb") as f:
            while True:
                chunk = f.read(65536)
                if not chunk:
                    break
                yield chunk

    return Response(
        stream(),
        200,
        {
            "Content-Type": mime,
            "Content-Length": size,
            "Accept-Ranges": "bytes",
            "Cache-Control": "public, max-age=3600",
        },
    )


@bp.route("/public/<path:filename>", methods=["GET"])
def serve_public(filename):
    return _serve_file(_PUBLIC_DIR, filename)


@bp.route("/Videos/<path:filename>", methods=["GET"])
def serve_video(filename):
    resp = _serve_file(_VIDEOS_DIR, filename)
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    resp.headers["CDN-Cache-Control"] = "no-store"
    return resp


_VALID_ASSET_CATS = {"Texture2D", "Sprite", "AudioClip", "Font", "TextAsset", "Shader", "MonoBehaviour"}

@bp.route("/assets/<category>/<path:filename>", methods=["GET"])
def serve_extracted_asset(category, filename):
    if category not in _VALID_ASSET_CATS:
        abort(404)
    asset_dir = os.path.join(_EXTRACTED_DIR, category)
    return _serve_file(asset_dir, filename)
