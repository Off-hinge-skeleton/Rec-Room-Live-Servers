
from flask import Blueprint, request, jsonify, Response

from core.auth import check_auth, get_current_profile_id
from core.state import db, session_mgr, ws_registry, APP_VERSION
from core.builders import now_ticks
from core.constants import DORM_ROOM_GUID

bp = Blueprint("presence", __name__)

@bp.route("/api/presence/v2/setscreenmode", methods=["POST"])
@check_auth
def set_screen_mode():
    pid = get_current_profile_id()
    data = request.get_json(force=True, silent=True) or {}
    in_screen = bool(data.get("InScreenMode", False))
    ws_registry.set_screen_mode(pid, in_screen)
    if in_screen and pid:
        db.set_setting(pid, "screen_mode_user", "1")
        if db.get_setting(pid, "Recroom.OOBE") != "100":
            db.set_setting(pid, "Recroom.OOBE", "100")
            db.update_profile(pid, {"registration_status": 2})
            _send_oobe_skip_dm(pid)
            print(f"[OOBE] Auto-set OOBE=100 for screen mode player {pid}")
    return Response("OK", 200)


_KITTYREC_PID = 23

def _send_oobe_skip_dm(pid: int) -> None:
    thread_id = db.get_or_create_chat([_KITTYREC_PID, pid])
    msg_text = (
        "your game is prob broken since your on screenmode and in the oobe. "
        "dont worry the kittyrec anticheat is blessing your little heart by "
        "letting you skip the oobe<3"
    )
    msg_id = db.send_chat_message(thread_id, _KITTYREC_PID, msg_text)
    msg = db.get_chat_message(msg_id)
    ws_registry.send(pid, {"Id": 90, "Msg": msg})

@bp.route("/api/presence/v1/playerDisconnected", methods=["POST"])
@check_auth
def player_disconnected():
    return Response("OK", 200)

@bp.route("/api/presence/v3/heartbeat", methods=["POST"])
@check_auth
def presence_heartbeat():
    from core.builders import activity_info
    pid = get_current_profile_id() or 1
    session = session_mgr.get_player_session(pid)
    if session is None:
        name, key, sandbox = activity_info(DORM_ROOM_GUID)
        session = session_mgr.join_room(pid, DORM_ROOM_GUID, name, key, sandbox=sandbox)
    return jsonify({
        "Id": 4,
        "Msg": {
            "PlayerId": pid,
            "IsOnline": True,
            "InScreenMode": ws_registry.is_screen_mode(pid),
            "GameSession": session.to_dict(),
        },
    })

@bp.route("/api/presence/v1/setplayertype", methods=["POST"])
@check_auth
def set_player_type():
    return jsonify([])

@bp.route("/api/presence/v2/list", methods=["POST"])
@check_auth
def get_presence_list():
    ids = (request.get_json(force=True, silent=True) or [])[:200]
    result = []
    for pid in ids:
        session = session_mgr.get_player_session(pid)
        is_online = ws_registry.is_connected(pid)
        result.append({
            "PlayerId": pid,
            "IsOnline": is_online,
            "GameSessionId": session.photon_room_id if session else "",
            "AppVersion": APP_VERSION,
            "LastUpdateTime": now_ticks(),
            "Activity": session.activity_key if session else "",
            "Private": session.private if session else False,
            "AvailableSpace": (max(0, session.max_capacity - len(session.players))
                               if session else 0),
            "GameInProgress": session.game_in_progress if session else False,
        })
    return jsonify(result)
