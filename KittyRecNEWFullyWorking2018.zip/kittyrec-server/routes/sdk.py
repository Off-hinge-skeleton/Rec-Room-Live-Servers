import json
import os
import random
import jwt
from functools import wraps
import uuid
from flask import Blueprint, request, jsonify, abort, send_from_directory
from werkzeug.utils import secure_filename


from core.config import sdk as _sdk_cfg, base_url as _base_url
from core.state import db

jwtKey = _sdk_cfg.get("jwt_secret", "")

bp = Blueprint("KittySDK", __name__)

def getUset(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.headers.get("Authorization")
        
        if not auth or not auth.startswith("Bearer "):
            return abort(401)
        
        try:
            token = auth.split(" ")[1]
            
            authr = jwt.decode(token, jwtKey, algorithms=["HS256"])
            
            userd = db.get_profile(int(authr.get("sub")))
            
            if userd is None:
                return abort(401)
            
            return f(userd, *args, **kwargs)
            
        except Exception as e:
            print(f"Auth Error: {e}")
            return abort(401)
            
    return decorated

@bp.route("/api/sdk/v1", methods=["POST"])
def login():
    jsondata = request.get_json(silent=True)
    
    if not jsondata or not isinstance(jsondata, dict):
        return abort(400)
    
    username = jsondata.get("username")
    password = jsondata.get("password")
    
    if not username or not password:
        return abort(400)

    profile = db.check_password(username, password)
    
    if profile is None:
        
        return jsonify({
        "Error": "Invalid username or password",
        "Token": ""
    }), 200
        
    if not profile.get("Developer"):
        return jsonify({
        "Error": "Access denied: not a developer",
        "Token": ""
    })
    
    token = jwt.encode({
        "iss": f"{_base_url}/KittySDK",
        "sub": str(profile.get("Id"))
    }, jwtKey, algorithm="HS256")
    
    return jsonify({
        "Error": "",
        "Token": token,
        "User": profile,
    })

@bp.route("/api/sdk/v1/myrooms", methods=["GET"])
@getUset
def myrooms(user):
    show_all = request.args.get("show_all", "false").lower() == "true"
    if show_all:
        if user.get("Developer"):
            rooms = db.get_all_rooms()
        else:
            return abort(403)
    else:
        rooms = db.get_rooms_by_creator(user.get("Id"))
    return jsonify(rooms)

@bp.route("/assetbundles/<path:path>", methods=["GET"])
def aassetbundles(path):
    try:
        return send_from_directory(directory="assetbundles", path=path)
    except FileNotFoundError:
        return abort(404)

@bp.route("/api/sdk/v1/upload", methods=["POST"])
@getUset
def upload(user):
    print(request.form)
    print(request.files)

    Type = request.form.get("type")
    if Type is None:
        return abort(400)
    if Type == "room":
        roomId = request.form.get("roomId")
        if roomId is None:
            return abort(400)
        if not isinstance(roomId, str):
            return abort(400)
        try:
            roomId = int(roomId)
        except ValueError:
            return abort(400)
        sceneName = request.form.get("sceneName")
        if sceneName is None:
            return abort(400)
        if not isinstance(sceneName, str):
            return abort(400)
        
        file = request.files.get("assetBundle")
        if file is None:
            return abort(400)
        
        rooms = db.get_all_rooms() if user.get("Developer") else db.get_rooms_by_creator(user.get("Id"))

        room = next((r for r in rooms if r.get("RoomId") == roomId), None)
        if not room:
            abort(404)
        
        randomFileName = secure_filename(f"sdk_room_{room.get("Name")}_{uuid.uuid4()}")
        if randomFileName is None:
            randomFileName = str(uuid.uuid4())
        saveDirectory = "assetbundles"
        
        os.makedirs(saveDirectory, exist_ok=True)
        
        file.save(os.path.join(saveDirectory, f"{randomFileName}.assetbundle"))

        db.update_room_field(roomId, "unity_asset_bundle_url", f"https://kittyrec.tabbycluster.net/assetbundles/{randomFileName}.assetbundle")
        roomData = db.update_room_field(roomId, "unity_scene_name", sceneName)


        return jsonify(roomData)

        
    
    return abort(404)