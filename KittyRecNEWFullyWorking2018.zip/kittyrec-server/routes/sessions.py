
import threading

from flask import Blueprint, request, jsonify, Response

from core.auth import check_auth, get_current_profile_id
from core.limiter import limiter
from core.state import db, session_mgr
from core.builders import activity_info, get_request_data
from core.ws_helpers import push_presence
from core.constants import DORM_ROOM_GUID, MSG_GAME_INVITE, MSG_PARTY_ACTIVITY_SWITCH
from core.state import ws_registry
from core.builders import now_iso
from routes.avatar import _get_activity_item_pool

_KITTYREC_PID = 23

def _send_party_invites(from_pid: int, session, party_ids: list) -> None:
    if not party_ids or not session:
        return
    for to_id in party_ids:
        if to_id == from_pid:
            continue
        try:
            msg_id = db.send_message(from_pid, to_id, MSG_PARTY_ACTIVITY_SWITCH, "", session.session_id)
            ws_registry.send(to_id, {"Id": 2, "Msg": {
                "Id": msg_id, "FromPlayerId": from_pid, "SentTime": now_iso(),
                "Type": MSG_PARTY_ACTIVITY_SWITCH, "Data": "",
            }})
        except Exception:
            pass
    print(f"[Party] Player {from_pid} → party invites sent to {party_ids}")

_welcomed: set[int] = set()

def _notify_room_join(pid: int, session) -> None:
    try:
        from core.discord import send_public
        p = db.get_profile(pid)
        uname = p["Username"] if p else str(pid)
        dname = (p or {}).get("DisplayName", uname)
        img = (p or {}).get("ProfileImageName", "")
        from core.config import base_url as _base_url
        player_count = len(session.players)
        send_public(
            title="Room Join",
            color=0x9B59B6,
            fields=[
                {"name": "Player", "value": dname, "inline": True},
                {"name": "Room", "value": session.name or "Unknown", "inline": True},
                {"name": "Players in Room", "value": str(player_count), "inline": True},
            ],
            thumbnail_url=f"{_base_url}/alt/{img}" if img else None,
            throttle_key=f"roomjoin_{pid}",
            throttle_secs=60,
        )
    except Exception:
        pass
_welcomed_lock = threading.Lock()

def session_gift_count(pid: int, activity_guid: str) -> int:
    return db.get_session_gift_count(pid, activity_guid)

def session_gift_increment(pid: int, activity_guid: str) -> None:
    db.increment_session_gift_count(pid, activity_guid)

def session_gift_reset(pid: int) -> None:
    db.reset_session_gift_counts(pid)


from core.anticheat import check_banned_room_join

bp = Blueprint("sessions", __name__)


def _send_welcome_dm(pid: int) -> None:
    import time
    import secrets
    import string

    time.sleep(10)

    from tracking.password_tracking import has_real_password
    if has_real_password(pid):
        return
    profile = db.get_profile(pid)
    if not profile:
        return

    from werkzeug.security import generate_password_hash
    alphabet = string.ascii_letters + string.digits
    temp_pass = "".join(secrets.choice(alphabet) for _ in range(8))

    conn = db._get_conn()
    conn.execute("UPDATE profiles SET password=? WHERE id=?",
                 (generate_password_hash(temp_pass), pid))
    conn.commit()

    username = profile.get("Username", f"Player{pid}")
    thread_id = db.get_or_create_chat([_KITTYREC_PID, pid])
    msg_text = (
        f"Welcome to KittyRec!\n"
        f"Username: {username}\n"
        f"Temp password: {temp_pass}\n"
        f"STOP SHARING YOUR SCREEN!\n"
        f"Reply to this message with a new password (8+ chars) to register!"
    )
    msg_id = db.send_chat_message(thread_id, _KITTYREC_PID, msg_text)
    msg = db.get_chat_message(msg_id)
    ws_registry.send(pid, {"Id": 90, "Msg": msg})
    print(f"[Welcome] Sent temp password to pid={pid} ({username})")


def _maybe_welcome(pid: int, activity_guid: str) -> None:
    if activity_guid == DORM_ROOM_GUID:
        return
    with _welcomed_lock:
        if pid in _welcomed:
            return
        _welcomed.add(pid)
    from tracking.password_tracking import has_real_password
    if has_real_password(pid):
        return
    profile = db.get_profile(pid)
    if not profile:
        return
    t = threading.Thread(target=_send_welcome_dm, args=(pid,), daemon=True)
    t.start()

def make_game_session_response(data: dict | None = None, force_pid: int | None = None) -> dict:
    pid = force_pid or get_current_profile_id() or 1

    activity_guid = DORM_ROOM_GUID
    private = False
    sandbox = False
    rec_room_id = None

    expected_ids: list[int] = []
    if data:
        raw_eids = data.get("ExpectedPlayerIds") or []
        if isinstance(raw_eids, list):
            expected_ids = [int(x) for x in raw_eids if str(x).lstrip('-').isdigit()]
        level_ids = data.get("ActivityLevelIds", [])
        if level_ids:
            activity_guid = str(level_ids[0])
        elif data.get("ActivityLevelId"):
            activity_guid = str(data["ActivityLevelId"])
        elif data.get("RecRoomId") or data.get("RoomId"):
            rec_room_id = int(data.get("RecRoomId") or data.get("RoomId") or 0)
            if rec_room_id:
                if db.is_room_disabled(rec_room_id):
                    return {"Result": 7}
                live = session_mgr.get_session(rec_room_id)
                if live:
                    if check_banned_room_join(pid, live.activity_level_id):
                        return {"Result": 12}
                    session_gift_reset(pid)
                    joined = session_mgr.join_session_by_id(pid, rec_room_id)
                    if joined:
                        push_presence(pid, joined)
                        _maybe_welcome(pid, joined.activity_level_id)
                        if joined.activity_level_id != DORM_ROOM_GUID:
                            db.record_room_visit(pid, joined.activity_level_id, rec_room_id)
                            threading.Thread(target=_notify_room_join, args=(pid, joined), daemon=True).start()
                        print(f"[Session] Player {pid} → '{joined.name}' "
                              f"(sid={joined.session_id}, photon={joined.photon_room_id}, "
                              f"{len(joined.players)} players)")
                        _send_party_invites(pid, joined, expected_ids)
                        return {"Result": 0, "GameSession": joined.to_dict()}
                else:
                    room = db.get_room(rec_room_id)
                    if room and room.get("ActivityLevelId"):
                        activity_guid = room["ActivityLevelId"]
        private = bool(data.get("Private", False))
        sandbox = bool(data.get("Sandbox", False))

    if not rec_room_id and db.is_activity_disabled(activity_guid):
        return {"Result": 7}

    if check_banned_room_join(pid, activity_guid):
        return {"Result": 12}

    name, key, default_sandbox = activity_info(activity_guid)
    creator_pid = pid
    if rec_room_id:
        room = db.get_room(rec_room_id)
        if room:
            name = room.get("Name") or name
            sandbox = bool(room.get("IsSandbox", False))
            creator_pid = room.get("CreatorPlayerId") or pid
        else:
            sandbox = True
    else:
        sandbox = sandbox or (default_sandbox and activity_guid != DORM_ROOM_GUID)

    session_gift_reset(pid)
    session = session_mgr.join_room(pid, activity_guid, name, key,
                                    private=private, sandbox=sandbox,
                                    rec_room_id=rec_room_id,
                                    creator_pid=creator_pid)
    push_presence(pid, session)
    _maybe_welcome(pid, activity_guid)
    if activity_guid != DORM_ROOM_GUID:
        db.record_room_visit(pid, activity_guid, rec_room_id)
        threading.Thread(target=_notify_room_join, args=(pid, session), daemon=True).start()
    print(f"[Session] Player {pid} → '{session.name}' "
          f"(sid={session.session_id}, photon={session.photon_room_id}, "
          f"{len(session.players)} players)")
    _send_party_invites(pid, session, expected_ids)
    return {"Result": 0, "GameSession": session.to_dict()}

@bp.route("/api/gamesessions/v1/", methods=["GET"])
@check_auth
def list_game_sessions():
    sessions = session_mgr.all_public_sessions()
    return jsonify([s.to_v1_dict() for s in sessions])

@bp.route("/api/gamesessions/v2/create", methods=["GET", "POST"])
@check_auth
def create_game_session():
    data = request.get_json(force=True, silent=True) or {}
    data["Private"] = True
    return jsonify(make_game_session_response(data))

@bp.route("/api/gamesessions/v2/modify", methods=["POST"])
@check_auth
def modify_game_session():
    pid = get_current_profile_id()
    data = request.get_json(force=True, silent=True) or {}
    game_session_id = int(data.get("GameSessionId", 0))
    if game_session_id:
        session = session_mgr.get_session(game_session_id)
        if session:
            is_creator = (pid == session.creator_player_id)
            is_member = (pid in session.players)
            if is_creator:
                if "Private" in data:
                    session_mgr.modify_session(game_session_id, private=bool(data["Private"]))
                if "MaxCapacity" in data:
                    session_mgr.modify_session(game_session_id, max_capacity=int(data["MaxCapacity"]))
            if (is_creator or is_member) and "InProgress" in data:
                session_mgr.modify_session(game_session_id, game_in_progress=bool(data["InProgress"]))
    return Response("OK", 200)

@bp.route("/api/gamesessions/v2/joinplayer", methods=["POST"])
@check_auth
def join_player_session():
    pid = get_current_profile_id() or 1
    data = request.get_json(force=True, silent=True) or {}
    target_pid = int(data.get("PlayerId", 0))
    expected_ids = data.get("ExpectedPlayerIds") or []
    party_size = len(expected_ids) if isinstance(expected_ids, list) else 1
    if target_pid:
        session_gift_reset(pid)
        session = session_mgr.join_session_of(pid, target_pid, party_size=party_size)
        if session:
            push_presence(pid, session)
            party_ids = [int(x) for x in expected_ids if str(x).lstrip('-').isdigit()] if isinstance(expected_ids, list) else []
            _send_party_invites(pid, session, party_ids)
            print(f"[Session] Player {pid} joined player {target_pid}'s session "
                  f"(sid={session.session_id}, photon={session.photon_room_id}, party={party_size})")
            return jsonify({"Result": 0, "GameSession": session.to_dict()})
    return jsonify(make_game_session_response(data))

@bp.route("/api/gamesessions/v2/joinroom",   methods=["POST"])
@bp.route("/api/gamesessions/v2/joinrandom", methods=["POST"])
@bp.route("/api/gamesessions/v3/joinRandom", methods=["POST"])
@bp.route("/api/gamesessions/v2/join",       methods=["POST"])
@bp.route("/api/gamesessions/v2/joinevent",  methods=["POST"])
@check_auth
def join_game_session():
    data = request.get_json(force=True, silent=True) or {}
    return jsonify(make_game_session_response(data))

@bp.route("/api/gamesessions/v3/joinroom", methods=["POST"])
@check_auth
def join_room_v3():
    data = request.get_json(force=True, silent=True) or {}
    return jsonify(make_game_session_response(data))

@bp.route("/api/gamesessions/v2/reportjoinresult", methods=["POST"])
@check_auth
def report_join_result():
    pid = get_current_profile_id()
    if pid:
        data = get_request_data()
        result_names = {0: "Success", 1: "FailedToConnectToRegion", 2: "FailedToConnectToRoom", 3: "FailedToSpawnPlayer"}
        result_code = int(data.get("Result", 0))
        props = {
            "result": result_names.get(result_code, str(result_code)),
            "result_code": result_code,
            "region": data.get("RegionId", ""),
            "room_id": data.get("RoomId", ""),
            "game_session_id": data.get("GameSessionId"),
            "master_player_id": data.get("MasterPlayerId"),
            "rec_room_id": data.get("RecRoomId"),
        }
        db.save_amplitude_event(pid, "room_joinRequest", 0, props, {}, "", "")
        if result_code != 0:
            print(f"[JoinResult] Player {pid} failed to join room: {props['result']} (region={props['region']}, room={props['room_id']})")
    return Response("OK", 200)

@bp.route("/api/gamesessions/v2/reportgamejoinresult", methods=["POST"])
@check_auth
def report_game_join_result():
    pid = get_current_profile_id()
    if pid:
        if not session_mgr.get_player_session(pid):
            print(f"[JoinResult] Rejected challenge check for pid={pid}: not in a session")
            return Response("OK", 200)
        data = get_request_data()
        result_code = int(data.get("Result", 0))
        if result_code != 0:
            return Response("OK", 200)

        _SOCIAL_GUIDS = {
            DORM_ROOM_GUID,
            "cbad71af-0831-44d8-b8ef-69edafa841f6",
            "a067557f-ca32-43e6-b6e5-daaec60b4f5a",
            "0a864c86-5a71-4e18-8041-8124e4dc9d98",
        }

        activity_guid = str(data.get("ActivityLevelId", ""))
        if not activity_guid:
            ids = data.get("ActivityLevelIds", [])
            if ids:
                activity_guid = str(ids[0])
        if not activity_guid:
            game_session_id = data.get("GameSessionId")
            if game_session_id is not None:
                gs = session_mgr.get_session(int(game_session_id))
                if gs:
                    activity_guid = gs.activity_level_id
        if not activity_guid:
            rec_room_id = data.get("RecRoomId")
            if rec_room_id:
                room = db.get_room(int(rec_room_id))
                if room:
                    activity_guid = room.get("ActivityLevelId", "")
        if not activity_guid:
            cur = session_mgr.get_player_session(pid)
            if cur:
                activity_guid = cur.activity_level_id

        if activity_guid and activity_guid not in _SOCIAL_GUIDS:
            from core.constants import get_current_weekly_challenge
            from core.ws_helpers import push_gift as _push_gift
            ch = get_current_weekly_challenge()
            if activity_guid == ch["activity_guid"]:
                db_key = ch["week"]
                prog = db.get_challenge_progress(pid, db_key)
                if not prog["completed"]:
                    new_score = db.increment_challenge_progress(pid, db_key)
                    print(f"[Challenge] Player {pid} progress on '{ch['title']}': {new_score}/{ch['target']}")
                    if new_score >= ch["target"]:
                        if db.try_mark_challenge_completed(pid, db_key):
                            import random as _rnd
                            from routes.avatar import _QUEST_CONSUMABLES
                            _pool = _get_activity_item_pool(ch["activity_guid"])
                            _item = _rnd.choice(_pool) if _pool else None
                            _consumable = _QUEST_CONSUMABLES.get(ch["activity_guid"], "")
                            reward = db.add_gift(pid, xp=ch["reward_xp"], gift_rarity=ch["reward_rarity"],
                                                 avatar_item_desc=_item["AvatarItemDesc"] if _item else "",
                                                 consumable_item_desc=_consumable,
                                                 message=f"Weekly Challenge: {ch['title']}!", gift_context=6)
                            _push_gift(pid, reward)
                            print(f"[Challenge] Player {pid} completed '{ch['title']}' — reward granted")

    return Response("OK", 200)

@bp.route("/api/gamesessions/v2/joingamesession", methods=["POST"])
@check_auth
def join_game_session_by_id():
    pid = get_current_profile_id() or 1
    data = request.get_json(force=True, silent=True) or {}
    game_session_id = int(data.get("GameSessionId", 0))
    if game_session_id:
        target_session = session_mgr.get_session(game_session_id)
        if target_session and target_session.private:
            return jsonify({"Result": 9})
        session = session_mgr.join_session_by_id(pid, game_session_id)
        if session:
            push_presence(pid, session)
            print(f"[Session] Player {pid} joined session {game_session_id} "
                  f"(photon={session.photon_room_id})")
            return jsonify({"Result": 0, "GameSession": session.to_dict()})
    return jsonify(make_game_session_response(data))

@bp.route("/api/gamesessions/v2/changeactivity", methods=["POST", "PUT"])
@check_auth
def change_session_activity():
    pid = get_current_profile_id()
    data = request.get_json(force=True, silent=True) or {}
    game_session_id = int(data.get("GameSessionId", 0))
    activity_id = data.get("ActivityLevelId", "")
    if game_session_id and activity_id:
        session = session_mgr.get_session(game_session_id)
        if session and pid == session.creator_player_id:
            session_mgr.modify_session(game_session_id, activity_level_id=activity_id)
            push_presence(pid, session)
    return Response("OK", 200)

@bp.route("/api/gamesessions/v2/changename", methods=["POST", "PUT"])
@check_auth
def change_session_name():
    pid = get_current_profile_id()
    data = request.get_json(force=True, silent=True) or {}
    game_session_id = int(data.get("GameSessionId", 0))
    name = data.get("Name", "")
    if game_session_id and name:
        session = session_mgr.get_session(game_session_id)
        if session and pid == session.creator_player_id:
            session_mgr.modify_session(game_session_id, name=name)
    return Response("OK", 200)

@bp.route("/api/gamesessions/v2/changemaxcapacity", methods=["POST", "PUT"])
@check_auth
def change_session_max_capacity():
    pid = get_current_profile_id()
    data = request.get_json(force=True, silent=True) or {}
    game_session_id = int(data.get("GameSessionId", 0))
    max_cap = int(data.get("MaxCapacity", 20))
    if game_session_id:
        session = session_mgr.get_session(game_session_id)
        if session and pid == session.creator_player_id:
            session_mgr.modify_session(game_session_id, max_capacity=max_cap)
    return Response("OK", 200)

@bp.route("/api/gamesessions/v2/setinprogress", methods=["POST", "PUT"])
@check_auth
def set_session_in_progress():
    pid = get_current_profile_id()
    data = request.get_json(force=True, silent=True) or {}
    game_session_id = int(data.get("GameSessionId", 0))
    in_progress = bool(data.get("InProgress", False))
    if game_session_id:
        session = session_mgr.get_session(game_session_id)
        if session and (pid == session.creator_player_id or pid in session.players):
            session_mgr.modify_session(game_session_id, game_in_progress=in_progress)
    return Response("OK", 200)

@bp.route("/api/gamesessions/v2/setprivate", methods=["POST", "PUT"])
@check_auth
def set_session_private():
    pid = get_current_profile_id()
    data = request.get_json(force=True, silent=True) or {}
    game_session_id = int(data.get("GameSessionId", 0))
    private = bool(data.get("Private", False))
    if game_session_id:
        session = session_mgr.get_session(game_session_id)
        if session and pid == session.creator_player_id:
            session_mgr.modify_session(game_session_id, private=private)
    return Response("OK", 200)

@bp.route("/api/gamesessions/v2/block", methods=["POST"])
@check_auth
def block_game_session():
    return Response("OK", 200)

@bp.route("/api/objectives/v1/myprogress", methods=["GET"])
@check_auth
def get_objectives_progress():
    return jsonify({"Objectives": [], "ObjectiveGroups": []})

@bp.route("/api/objectives/v1/cleargroup", methods=["POST"])
@check_auth
def clear_objective_group():
    from datetime import datetime, timezone
    data = request.get_json(force=True, silent=True) or {}
    group = data.get("Group", 0)
    cleared_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.0000000Z")
    return jsonify({"Group": group, "IsCompleted": True, "ClearedAt": cleared_at})

@bp.route("/api/objectives/v1/updateobjective", methods=["POST"])
@check_auth
def update_objective():
    return Response("OK", 200)

@bp.route("/api/objectives/v1/completegroup", methods=["POST"])
@check_auth
def complete_objective_group():
    from datetime import datetime, timezone
    data = request.get_json(force=True, silent=True) or {}
    group = int(data.get("Group", 0))
    cleared_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.0000000Z")
    return jsonify({"Group": group, "IsCompleted": True, "ClearedAt": cleared_at})
