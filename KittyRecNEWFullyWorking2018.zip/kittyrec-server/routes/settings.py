
from datetime import date as _date
from flask import Blueprint, request, jsonify, Response

from core.auth import check_auth, get_current_profile_id
from core.builders import get_request_data
from core.state import db

bp = Blueprint("settings", __name__)

_SERVER_MANAGED_KEYS = {"royale_xp", "screen_mode_user"}

@bp.route("/api/settings/v2/", methods=["GET"])
@check_auth
def get_settings():
    pid = get_current_profile_id()
    if pid is None:
        return jsonify([])
    settings = db.get_settings(pid)
    today_count = db.get_daily_gift_count(pid, _date.today().isoformat())
    for s in settings:
        if s["Key"] == "GIFT_COUNT":
            s["Value"] = str(today_count)
            break
    else:
        if today_count > 0:
            settings.append({"Key": "GIFT_COUNT", "Value": str(today_count)})
    is_screen_user = any(s["Key"] == "screen_mode_user" and s["Value"] == "1" for s in settings)
    if is_screen_user:
        has_oobe = False
        for s in settings:
            if s["Key"] == "Recroom.OOBE":
                if s["Value"] != "100":
                    s["Value"] = "100"
                    db.set_setting(pid, "Recroom.OOBE", "100")
                    db.update_profile(pid, {"registration_status": 2})
                has_oobe = True
                break
        if not has_oobe:
            db.set_setting(pid, "Recroom.OOBE", "100")
            db.update_profile(pid, {"registration_status": 2})
            settings.append({"Key": "Recroom.OOBE", "Value": "100"})
    return jsonify(settings)

@bp.route("/api/settings/v2/set", methods=["POST"])
@check_auth
def set_setting():
    pid = get_current_profile_id()
    data = get_request_data()
    if pid is None:
        print(f"[Settings] Dropping unauthenticated set: {data.get('Key', '')!r}")
        return Response("OK", 200)
    key = str(data.get("Key", ""))[:128]
    if key in _SERVER_MANAGED_KEYS:
        return Response("OK", 200)
    value = str(data.get("Value", ""))[:4096]
    db.set_setting(pid, key, value)
    if key == "Recroom.OOBE":
        db.update_profile(pid, {"registration_status": 2})
    return Response("OK", 200)

@bp.route("/api/settings/v2/remove", methods=["POST"])
@check_auth
def remove_setting():
    pid = get_current_profile_id()
    if pid is None:
        return Response("OK", 200)
    data = get_request_data()
    db.remove_setting(pid, data.get("Key", ""))
    return Response("OK", 200)

@bp.route("/api/settings/v2/<path:key>", methods=["GET"])
@check_auth
def get_setting_by_key(key):
    pid = get_current_profile_id()
    if pid is None:
        return jsonify({"Key": key, "Value": ""})
    value = db.get_setting(pid, key)
    return jsonify({"Key": key, "Value": value if value is not None else ""})

@bp.route("/api/equipment/v1/getUnlocked", methods=["GET"])
@check_auth
def get_unlocked_equipment():
    pid = get_current_profile_id()
    if not pid:
        return jsonify([])
    return jsonify(db.get_unlocked_equipment(pid))

@bp.route("/api/equipment/v1/update", methods=["POST"])
@check_auth
def update_equipment():
    pid = get_current_profile_id()
    if not pid:
        return Response("OK", 200)
    items = (request.get_json(force=True, silent=True) or [])[:200]
    if isinstance(items, list) and items:
        db.set_equipment_favorites(pid, items)
    return jsonify([])

@bp.route("/api/consumables/v1/getUnlocked", methods=["GET"])
@check_auth
def get_unlocked_consumables():
    pid = get_current_profile_id()
    if not pid:
        return jsonify([])
    rows = db.get_consumable_inventory(pid)
    from datetime import datetime, timezone
    result = []
    for r in rows:
        raw_ts = r.get("created_at") or ""
        if raw_ts and "T" not in raw_ts:
            raw_ts = raw_ts.replace(" ", "T") + "Z"
        if not raw_ts:
            raw_ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        result.append({
            "Id": r["id"],
            "ConsumableItemDesc": r["consumable_item_desc"],
            "CreatedAt": raw_ts,
            "Count": r["count"],
            "UnlockedLevel": r.get("unlocked_level", 0),
            "IsActive": bool(r.get("is_active", 0)),
        })
    return jsonify(result)

@bp.route("/api/consumables/v1/consume", methods=["POST"])
@check_auth
def consume_consumable():
    pid = get_current_profile_id()
    data = get_request_data()
    try:
        consumable_id = int(data.get("Id", 0))
    except (TypeError, ValueError):
        consumable_id = 0
    delta = int(data.get("DeltaCount", 1))
    if pid and consumable_id:
        db.use_consumable(pid, consumable_id, abs(delta))
    return Response("OK", 200)

@bp.route("/api/consumables/v1/updateActive", methods=["POST"])
@check_auth
def update_active_consumable():
    pid = get_current_profile_id()
    data = get_request_data()
    try:
        consumable_id = int(data.get("Id", 0))
    except (TypeError, ValueError):
        consumable_id = 0
    is_active = data.get("IsActive", False)
    if pid and consumable_id:
        db.set_consumable_active(pid, consumable_id, is_active)
    return Response("OK", 200)
