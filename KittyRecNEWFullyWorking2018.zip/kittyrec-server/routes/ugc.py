
import json
import os

from flask import Blueprint, jsonify, abort

bp = Blueprint("ugc", __name__)

_DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "ugc_outfit_items.json")


def _load_items():
    try:
        with open(_DATA_PATH, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


@bp.route("/api/ugc/v1/outfititem/get", methods=["GET"])
def get_outfit_items():
    return abort(410)
