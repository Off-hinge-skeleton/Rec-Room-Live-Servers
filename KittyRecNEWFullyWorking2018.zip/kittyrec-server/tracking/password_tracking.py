import json
import os
import threading

_LOCK = threading.Lock()
_PATH = os.path.join(os.path.dirname(__file__), "password_resets.json")


def _read():
    try:
        with open(_PATH, "r") as f:
            return set(json.load(f))
    except (FileNotFoundError, json.JSONDecodeError):
        return set()


def _write(ids):
    with open(_PATH, "w") as f:
        json.dump(sorted(ids), f)


def mark_password_set(pid: int):
    with _LOCK:
        ids = _read()
        ids.add(pid)
        _write(ids)


def clear_password_set(pid: int):
    with _LOCK:
        ids = _read()
        ids.discard(pid)
        _write(ids)


def has_real_password(pid: int) -> bool:
    with _LOCK:
        return pid in _read()
