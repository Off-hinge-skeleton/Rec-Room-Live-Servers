using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

public static class ClientSecurity
{
    private const string MagicSignature = "GdYHMcKKpDK8mQviYTFVUFTre3olRz8JGWPqNZ6Ke44";

    public static string GenerateToken(Account account)
    {

        var roles = new List<string> { "gameClient", "screenshare" };

        if (account.IsDeveloper) roles.Add("developer");
        if (account.IsModerator) roles.Add("moderator");
        if (account.IsJunior) roles.Add("junior");

        return BuildToken(account.Id.ToString(), roles);
    }

    private static string BuildToken(string accountId, object roleValue)
    {
        string header = EncodeBase64Url("{\"alg\":\"HS256\",\"typ\":\"JWT\"}");

        long now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();

        var payload = new
        {
            nbf = now,
            exp = now + 360000, // Valid for 100 hours
            iss = "https://auth.rec.net",
            client_id = "recnet",
            role = roleValue, 
            sub = accountId,
            auth_time = now,
            idp = "local",
            jti = Guid.NewGuid().ToString("N").ToUpper(),
            sid = Guid.NewGuid().ToString("N").ToUpper(),
            iat = now,
            scope = new[] { "openid", "rn.api", "rn.commerce", "rn.notify", "rn.chat", "rn.accounts", "rn.auth", "rn.rooms" },
            amr = new[] { "mfa" }
        };

        string payloadEncoded = EncodeBase64Url(JsonConvert.SerializeObject(payload));
        return $"{header}.{payloadEncoded}.{MagicSignature}";
    }

    private static string EncodeBase64Url(string text)
    {
        byte[] bytes = Encoding.UTF8.GetBytes(text);
        return Convert.ToBase64String(bytes)
            .TrimEnd('=')
            .Replace('+', '-')
            .Replace('/', '_');
    }

    public static string GetIdFromToken(string authHeader)
    {
        try
        {

            if (string.IsNullOrEmpty(authHeader) || !authHeader.StartsWith("Bearer ")) return null;
            
            string token = authHeader.Substring(7);
            string[] parts = token.Split('.');
            if (parts.Length < 2) return null;

            string base64 = parts[1].Replace('-', '+').Replace('_', '/');
            switch (base64.Length % 4)
            {
                case 2: base64 += "=="; break;
                case 3: base64 += "="; break;
            }

            byte[] bytes = Convert.FromBase64String(base64);
            string json = Encoding.UTF8.GetString(bytes);
            var payload = JObject.Parse(json);
            
            return payload["sub"]?.ToString();
        }
        catch 
        { 
            return null; 
        }
    }
}