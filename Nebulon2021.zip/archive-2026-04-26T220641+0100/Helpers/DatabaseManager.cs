using MySqlConnector;
using Dapper;
using System.Data;

public class DatabaseManager
{
    private readonly string _connectionString = 
        "Server=uk1.cp.surden.me;Port=3306;Database=s50_database;User=u50_zT1TW6Fsi0;Password=kW7yakKFv0U+Jpa.7!Ny8k^R;";

    public DatabaseManager(IConfiguration configuration)
    {
    }

    /*public IDbConnection GetConnection()
    {
        var conn = new MySqlConnection(_connectionString);
        conn.Open();
        return conn;
    }*/
    public MySqlConnection GetConnection()
    {
        return new MySqlConnection(_connectionString);
    }
    
    public async Task<MySqlConnection> GetOpenConnectionAsync()
    {
        var connection = new MySqlConnection(_connectionString);
        await connection.OpenAsync();
        return connection;
    }
    
    public MySqlConnection CreateConnection()
    {
        return new MySqlConnection(_connectionString);
    }
}