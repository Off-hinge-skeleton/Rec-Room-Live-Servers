public class ServerSettings
{
    public string BaseUrl { get; set; }
    public string WebSocketUrl { get; set; }
}