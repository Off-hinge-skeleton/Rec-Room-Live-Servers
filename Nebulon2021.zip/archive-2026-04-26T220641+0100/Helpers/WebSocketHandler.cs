using System.Net.WebSockets;
using System.Text;

public static class WebSocketHandler
{
    public static void MapWebSocketEndpoints(this IApplicationBuilder app)
    {
        app.UseWebSockets();

        app.Use(async (context, next) =>
        {
            if (context.Request.Path == "/ws") 
            {
                if (context.WebSockets.IsWebSocketRequest)
                {
                    using var socket = await context.WebSockets.AcceptWebSocketAsync();
                    await HandleSignalRConnection(socket);
                    return;
                }
                context.Response.StatusCode = StatusCodes.Status400BadRequest;
                return;
            }
            await next();
        });
    }

    private static async Task HandleSignalRConnection(WebSocket webSocket)
    {
        var buffer = new byte[1024 * 4];

        byte[] handshakeResponse = Encoding.UTF8.GetBytes("{}\u001e");
        await webSocket.SendAsync(new ArraySegment<byte>(handshakeResponse), WebSocketMessageType.Text, true, CancellationToken.None);

        try
        {
            while (webSocket.State == WebSocketState.Open)
            {
                var result = await webSocket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);

                if (result.MessageType == WebSocketMessageType.Close)
                {
                    await webSocket.CloseAsync(WebSocketCloseStatus.NormalClosure, "Closed by game", CancellationToken.None);
                }
                else
                {
                    string receivedMessage = Encoding.UTF8.GetString(buffer, 0, result.Count);
                    Console.WriteLine($"[WS Received] {receivedMessage}");
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[WS ERROR] {ex.Message}");
        }
    }
}