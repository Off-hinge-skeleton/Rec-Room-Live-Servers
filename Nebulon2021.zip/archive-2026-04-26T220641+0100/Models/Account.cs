public class Account
{
    public int Id { get; set; }
    public string Username { get; set; }
    public string DisplayName { get; set; }
    public string Bio { get; set; }
    public string BannerImage { get; set; }
    public string ProfileImage { get; set; }
    public DateTime CreatedAt { get; set; }
        
    // Flags
    public bool IsJunior { get; set; }
    public bool IsDeveloper { get; set; }
    public bool IsModerator { get; set; }
        
    // Currencies
    public int Tokens { get; set; }
    public int LaserTickets { get; set; }
    public int IsleGold { get; set; }
    public int DraculaSilver { get; set; }

    // Auth/Platform tracking
    public int Platform { get; set; }
    public string PlatformId { get; set; }
    public string DeviceId { get; set; }
}