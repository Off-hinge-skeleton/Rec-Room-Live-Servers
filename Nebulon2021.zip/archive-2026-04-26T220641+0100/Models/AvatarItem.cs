using Newtonsoft.Json;

public class AvatarItem
{
    [JsonProperty("AvatarItemId")]
    public int Id { get; set; }
    public string AvatarItemDesc { get; set; }
    public int AvatarItemType { get; set; }
    public int PlatformMask { get; set; }
    public string FriendlyName { get; set; }
    public string Tooltip { get; set; }
    public int Rarity { get; set; }
    public string TagList { get; set; }
    public bool IsBaseAvatarItem { get; set; }
    public string CreatedAt { get; set; }
    public string ThumbnailImage { get; set; }
}

public class PlayerAvatarItem
{
    public int Id { get; set; }
    public int AccountId { get; set; }
    public int AvatarItemId { get; set; }
}

public class PlayerSetting
{
    public int Id { get; set; }
    public int AccountId { get; set; }
    public string Key { get; set; }
    public string Value { get; set; }
}

public class PlayerAvatar
{
    public int Id { get; set; }
    public int AccountId { get; set; }
    public string OutfitSelections { get; set; }
    public string FaceFeatures { get; set; }
    public string SkinColor { get; set; }
    public string HairColor { get; set; }
}

public class EquipmentItem
{
    public int Id { get; set; }
    public string PrefabName { get; set; }
    public string ModificationGuid { get; set; }
    public string FriendlyName { get; set; }
    public string Tooltip { get; set; }
    public int Rarity { get; set; }
}

public class ConsumableItem
{
    public int Id { get; set; }
    public List<int> Ids { get; set; }
    public string ConsumableItemDesc { get; set; }
    public int Category { get; set; }
}

public class PlayerEquipment
{
    public int Id { get; set; }
    public int AccountId { get; set; }
    public int EquipmentItemId { get; set; }
    public bool Favorited { get; set; }
}

public class PlayerConsumable
{
    public int Id { get; set; }
    public int AccountId { get; set; }
    public int ConsumableItemId { get; set; }
    public int Count { get; set; }
    public bool IsActive { get; set; }
}