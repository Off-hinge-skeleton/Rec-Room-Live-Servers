public class CachedLogin
{
    public int Id { get; set; }
    public int Platform { get; set; }
    public string DeviceId { get; set; }
    public string PlatformId { get; set; }
    public int AccountId { get; set; }
    public DateTime LastLoginTime { get; set; }
}