public class GameConfigItem
{
    public string Key { get; set; }
    public string Value { get; set; }
    public object ActiveExperiments { get; set; }
}