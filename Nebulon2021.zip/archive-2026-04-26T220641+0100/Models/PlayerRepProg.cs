public class PlayerProgression
{
    public int Id { get; set; }
    public int AccountId { get; set; }
    public int Level { get; set; }
    public int XP { get; set; }
}

public class PlayerReputation
{
    public int Id { get; set; }
    public int AccountId { get; set; }
    public int IsCheerful { get; set; }
    public int Noteriety { get; set; }
    public int CheerGeneral { get; set; }
    public int CheerHelpful { get; set; }
    public int CheerGreatHost { get; set; }
    public int CheerSportsman { get; set; }
    public int CheerCreative { get; set; }
    public int CheerCredit { get; set; }
    public int SelectedCheer { get; set; }
    public int SubscriberCount { get; set; }
    public int SubscribedCount { get; set; }
}