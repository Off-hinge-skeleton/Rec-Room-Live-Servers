public class Room
{
    public int Id { get; set; }
    public int RoomId { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }
    public int CreatorAccountId { get; set; }
    public bool IsDorm { get; set; }
    public List<SubRoom> SubRooms { get; set; }
    public List<RoomRole> Roles { get; set; }
    public int MaxPlayers { get; set; }
}

public class SubRoom
{
    public int SubRoomId { get; set; }
    public string Name { get; set; }
    public string UnitySceneId { get; set; }
    public int SavedByAccountId { get; set; }
}

public class RoomRole
{
    public int AccountId { get; set; }
    public int Role { get; set; }
}

public class RoomInstance
{
    public int Id { get; set; }
    public long RoomInstanceId { get; set; }
    public int RoomId { get; set; }
    public int SubRoomId { get; set; }
    public string Name { get; set; }
    public string Location { get; set; }
    public string PhotonRegionId { get; set; }
    public string PhotonRoomId { get; set; }
    public bool IsPrivate { get; set; }
    public List<int> PlayerAccountIds { get; set; } = new List<int>();
    public int MaxCapacity { get; set; } = 20;
}