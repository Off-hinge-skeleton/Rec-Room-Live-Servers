var builder = WebApplication.CreateBuilder(args);

builder.Services.Configure<ServerSettings>(builder.Configuration.GetSection("Server"));
builder.Services.AddSingleton<DatabaseManager>();

builder.WebHost.UseUrls("http://0.0.0.0:25582");
//builder.WebHost.UseUrls("https://nebulon.oldrecroom.com");

var app = builder.Build();

// Set the data directory for ImageServer
ImageServer.DataDir = AppContext.BaseDirectory;

ImageServer.MapImageServerEndpoints(app);
CdnServer.MapCdnServerEndpoints(app);
// ----------- Output and Log endpoint responses ---------------
var missingEndpoints = new HashSet<string>();
var missingEndpointLock = new object();
var missingEndpointFilePath = "missing_endpoints.txt";
var logFilePath = "logs.txt";
app.Use(async (context, next) =>
{
    var log = new List<string>();

    var method = context.Request.Method;
    var path = context.Request.Path + context.Request.QueryString;

    log.Add($"[REQUEST] {method} {path}");

    if (method == "POST" || method == "PUT")
    {
        context.Request.EnableBuffering();
        using var reader = new StreamReader(context.Request.Body, leaveOpen: true);
        var requestBody = await reader.ReadToEndAsync();
        context.Request.Body.Position = 0;

        if (!string.IsNullOrEmpty(requestBody))
        {
            log.Add($"Request Body: {requestBody}");
        }
    }

    var originalBodyStream = context.Response.Body;

    using var responseBody = new MemoryStream();
    context.Response.Body = responseBody;

    try
    {
        await next();
    }
    catch (Exception ex)
    {
        context.Response.StatusCode = 500;
        log.Add($"API Response: {method} {path} - 500 Internal Server Error");
        log.Add($"ERROR: {ex.Message}");

        PrintLog(log, 500, ConsoleColor.Red);
        return;
    }

    context.Response.Body.Seek(0, SeekOrigin.Begin);
    string responseText = await new StreamReader(context.Response.Body).ReadToEndAsync();
    context.Response.Body.Seek(0, SeekOrigin.Begin);

    var statusCode = context.Response.StatusCode;

    var reasonPhrase = statusCode switch
    {
        200 => "OK",
        404 => "Not Found",
        500 => "Internal Server Error",
        101 => "ws ok",
        _ => "Unknown"
    };

    log.Add($"API Response: {method} {path} - {statusCode} {reasonPhrase}");

    if (statusCode == 404 || statusCode >= 500)
    {
        var missingLine = $"!!! MISSING ENDPOINT: {context.Request.Path}";
        log.Add(missingLine);

        lock (missingEndpointLock) 
        {
            if (missingEndpoints.Add(missingLine))
            {
                try
                {
                    File.WriteAllLines(missingEndpointFilePath, missingEndpoints);
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine($"[FILE UPDATED] Added: {missingLine}");
                    Console.ResetColor();
                }
                catch (Exception fileEx)
                {
                    Console.WriteLine($"[FILE ERROR] {fileEx.Message}");
                }
            }
        }
    }
    else if (!string.IsNullOrEmpty(responseText) && context.Response.ContentType == "application/json")
    {
        log.Add($"Body: {responseText}");
    }

    PrintLog(log, statusCode);

    await responseBody.CopyToAsync(originalBodyStream);
});

void PrintLog(List<string> log, int statusCode, ConsoleColor? overrideColor = null)
{
    var color = overrideColor ?? statusCode switch
    {
        404 => ConsoleColor.Yellow,
        >= 500 => ConsoleColor.Red,
        >= 400 => ConsoleColor.DarkYellow,
        _ => ConsoleColor.Green
    };

    Console.ForegroundColor = color;

    foreach (var line in log)
    {
        Console.WriteLine(line);
    }

    Console.WriteLine("--------------------------------------------");
    Console.ResetColor();

    try
    {
        var fullLog = string.Join(Environment.NewLine, log)
                      + Environment.NewLine
                      + "--------------------------------------------"
                      + Environment.NewLine;

        File.AppendAllText(logFilePath, fullLog);
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[LOG FILE ERROR] {ex.Message}");
    }
}

//--------------------------------


// --- Middleware ---
app.MapWebSocketEndpoints();

// ------ Map each server's endpoint -------------
app.MapClubServerEndpoints();
app.MapWeeklyChallengeServerEndpoints();
app.MapStorefrontServerEndpoints();
app.MapAuthServerEndpoints();
app.MapAccountServerEndpoints();
app.MapNameserverEndpoints();
app.MapRoomServerEndpoints();
app.MapAPIServerEndpoints();

// Image server must be last due to the catch endpoint for profile pictures
//ImageServer.MapImageServerEndpoints(app);
// -------------------------------


app.MapFallback(async context =>
{
    var path = context.Request.Path;
    context.Response.StatusCode = 404;
    await context.Response.WriteAsync($"URI - 404 Not Found: {path}");
});


app.Run();