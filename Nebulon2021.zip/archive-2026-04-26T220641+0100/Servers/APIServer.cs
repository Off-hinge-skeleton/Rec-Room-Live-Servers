using System.Text.Json;
using Dapper;
using LiteDB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

public static class APIServer
{
    public static async Task MapAPIServerEndpoints(this IEndpointRouteBuilder app)
    {

        //---- Varaibles ----
        var BlankResponse = () => Results.Empty;
        var BracketResponse = () => new string[] { };


        // --- Version Check/Start up endpoints ---
        app.MapGet("/api/versioncheck/{*remainder}", (string? remainder, HttpContext context) =>
        {
            var version = context.Request.Query["v"]; // Correct version is 20210827
 			return new { VersionStatus = 0 }; // hack hack
            //if (version == "20210827")  return new { VersionStatus = 0 }; //Correct Version
            //else return new { VersionStatus = 1};
        });

        app.MapGet("/api/gamesight/event", BracketResponse);


        // --- Config Endpoints ---
        app.MapGet("/api/config/v1/amplitude", () => new
        {
            AmplitudeKey = "NebulonKey"
        });

        //Hardcoded for now
        app.MapGet("/api/config/v2", () => new
        {
            MessageOfTheDay = "Welcome to the Nebula Server!",
            CdnBaseUri = "http://localhost:2056/",
            ShareBaseUrl = "I love men - A wise man",
            LevelProgressionMaps = new object[] { },
            MatchmakingParams = new
            {
                PreferFullRoomsFrequency = 1,
                PreferEmptyRoomsFrequency = 0
            },
            DailyObjectives = new[]
            {
                new[] { new { type = 21, score = 1, xp = 0 }, new { type = 802, score = 3, xp = 0 }, new { type = 100, score = 2, xp = 0 } },
                new[] { new { type = 502, score = 5, xp = 0 }, new { type = 400, score = 3, xp = 0 }, new { type = 101, score = 2, xp = 0 } },
                new[] { new { type = 301, score = 3, xp = 0 }, new { type = 202, score = 4, xp = 0 }, new { type = 603, score = 2, xp = 0 } },
                new[] { new { type = 21, score = 1, xp = 0 }, new { type = 802, score = 3, xp = 0 }, new { type = 100, score = 2, xp = 0 } },
                new[] { new { type = 502, score = 5, xp = 0 }, new { type = 400, score = 3, xp = 0 }, new { type = 101, score = 2, xp = 0 } },
                new[] { new { type = 301, score = 3, xp = 0 }, new { type = 202, score = 4, xp = 0 }, new { type = 603, score = 2, xp = 0 } },
                new[] { new { type = 302, score = 3, xp = 0 }, new { type = 401, score = 2, xp = 0 }, new { type = 800, score = 1, xp = 0 } }
            },
            ConfigTable = new[]
            {
                new { Key = "Gift.DropChance", Value = "0.5" },
                new { Key = "Gift.XP", Value = "0.5" }
            },
            PhotonConfig = new
            {
                CloudRegion = "us",
                CrcCheckEnabled = false,
                EnableServerTracingAfterDisconnect = false
            },
            AutoMicMutingConfig = new
            {
                MicSpamVolumeThreshold = 0,
                MicVolumeSampleInterval = 0,
                MicVolumeSampleRollingWindowLength = 0,
                MicSpamSamplePercentageForWarning = 0,
                MicSpamSamplePercentageForWarningToEnd = 0,
                MicSpamSamplePercentageForForceMute = 0,
                MicSpamSamplePercentageForForceMuteToEnd = 0,
                MicSpamWarningStateVolumeMultiplier = 0
            }
        });


        app.MapGet("/api/gameconfigs/v1/all", () =>
        {
            var path = Path.Combine(AppContext.BaseDirectory, "Jsons", "GameConfig.json");

            var json = File.ReadAllText(path);

            var data = System.Text.Json.JsonSerializer.Deserialize<List<GameConfigItem>>(json);
            return data;
        });

        app.MapPost("/hub/v1/negotiate", (IOptions<ServerSettings> settings) =>
        {
            return Results.Json(new
            {
                ConnectionId = "Huba",
                negotiationVersion = 0,
                availableTransports = new[]
                {
                    new { transport = "WebSockets", transferFormats = new[] { "Text", "Binary" } }
                },
                //url = settings.Value.WebSocketUrl 
                url = "wss://nebulon.oldrecroom.com/ws"
                //url = "ws://nebulon.oldrecroom.com/ws"
                //url = "ws://localhost:2059/ws"
            });
        });

        // ----------------------------


        // --- Avatar Endpoints ---
        app.MapGet("/api/avatar/v1/defaultunlocked", BracketResponse);

        app.MapGet("/api/avatar/v4/items", async (HttpContext context, DatabaseManager dbManager) =>
        {
            string authHeader = context.Request.Headers["Authorization"];
            string subId = ClientSecurity.GetIdFromToken(authHeader);
            if (!int.TryParse(subId, out int accountId)) return Results.Unauthorized();

            using var db = dbManager.GetConnection();

            var items = await db.QueryAsync<dynamic>(@"
                SELECT 
                    i.Id, i.AvatarItemDesc, i.AvatarItemType, i.PlatformMask, 
                    i.FriendlyName, i.Tooltip, i.Rarity, i.IsBaseAvatar, 
                    i.CreatedAt, i.ThumbnailImage
                FROM AllAvatarItems i
                INNER JOIN PlayerAvatarItems p ON i.Id = p.AvatarItemId
                WHERE p.AccountId = @AccountId", new { AccountId = accountId });

            var result = items.Select(i => new
            {
                AvatarItemDesc = (string)i.AvatarItemDesc,
                AvatarItemType = (int)i.AvatarItemType,
                PlatformMask = (int)i.PlatformMask,
                FriendlyName = (string)i.FriendlyName,
                Tooltip = (string)i.Tooltip,
                Rarity = (int)i.Rarity,
                TagList = (string)null,
                AvatarItemId = (int)i.Id, 
                IsBaseAvatarItem = i.IsBaseAvatar == 1,
                CreatedAt = (string)i.CreatedAt,
                ThumbnailImage = (string)i.ThumbnailImage
            });

            return Results.Ok(result);
        });

        app.MapGet("/api/avatar/v2", async (HttpContext context, DatabaseManager dbManager) =>
        {
            string authHeader = context.Request.Headers["Authorization"];
            string subId = ClientSecurity.GetIdFromToken(authHeader);
            if (!int.TryParse(subId, out int accountId)) return Results.Unauthorized();

            using var db = dbManager.GetConnection();

            var avatar = await db.QueryFirstOrDefaultAsync<dynamic>(@"
                SELECT AccountId, OutfitSelection, FaceFeatures, SkinColor, HairColor 
                FROM PlayerAvatars 
                WHERE AccountId = @Id", new { Id = accountId });

            if (avatar == null) return Results.NotFound();

            return Results.Ok(new
            {
                accountId = (int)avatar.AccountId,
                outfitSelections = string.IsNullOrWhiteSpace((string)avatar.OutfitSelection) ? "" : (string)avatar.OutfitSelection,
                faceFeatures = string.IsNullOrWhiteSpace((string)avatar.FaceFeatures) ? "" : (string)avatar.FaceFeatures,
                skinColor = (string)avatar.SkinColor ?? "",
                hairColor = (string)avatar.HairColor ?? ""
            });
        });

        //Need to make database for
        app.MapGet("/api/avatar/v3/saved", BracketResponse);

        app.MapPost("/api/avatar/v2/set", async (HttpContext context, DatabaseManager dbManager) =>
        {
            string authHeader = context.Request.Headers["Authorization"];
            string subId = ClientSecurity.GetIdFromToken(authHeader);
            if (!int.TryParse(subId, out int accountId)) return Results.Unauthorized();

            using var reader = new StreamReader(context.Request.Body);
            string rawJson = await reader.ReadToEndAsync();

            if (string.IsNullOrEmpty(rawJson)) return Results.BadRequest();

            var avatarData = Newtonsoft.Json.Linq.JObject.Parse(rawJson);
            using var db = dbManager.GetConnection();

            await db.ExecuteAsync(@"
                UPDATE PlayerAvatars 
                SET OutfitSelection = @Outfit, 
                    FaceFeatures = @Face, 
                    SkinColor = @Skin, 
                    HairColor = @Hair
                WHERE AccountId = @Id", 
            new { 
                Outfit = avatarData["OutfitSelections"]?.ToString(),
                Face = avatarData["FaceFeatures"]?.ToString(),
                Skin = avatarData["SkinColor"]?.ToString(),
                Hair = avatarData["HairColor"]?.ToString(),
                Id = accountId 
            });

            Console.WriteLine($"[API] PlayerAvatars updated for account: {accountId}");
            return Results.Content("{}", "application/json");
        });

        // -----------------------------------

        // --- Settings & Backpack ---
        app.MapGet("/api/settings/v2", async (HttpContext context, DatabaseManager dbManager) =>
        {
            string authHeader = context.Request.Headers["Authorization"];
            string subId = ClientSecurity.GetIdFromToken(authHeader);
            if (!int.TryParse(subId, out int accountId)) return Results.Unauthorized();

            using var db = dbManager.GetConnection();

            var settings = await db.QueryAsync<dynamic>(@"
                SELECT `Key`, `Value` 
                FROM PlayerSettings 
                WHERE AccountId = @Id", new { Id = accountId });
            var result = settings.Select(s => new 
            { 
                key = (string)s.Key, 
                value = (string)s.Value 
            });

            return Results.Ok(result);
        });

        app.MapGet("/api/equipment/v2/getUnlocked", async (HttpContext context, DatabaseManager dbManager) =>
        {
            string authHeader = context.Request.Headers["Authorization"];
            string subId = ClientSecurity.GetIdFromToken(authHeader);
            
            if (!int.TryParse(subId, out int accountId)) accountId = 1; 

            using var db = dbManager.GetConnection();

            var equipment = await db.QueryAsync<dynamic>(@"
                SELECT 
                    m.PrefabName, m.ModificationGuid, m.FriendlyName, 
                    m.Tooltip, m.Rarity, p.Favorited
                FROM AllEquipment m
                INNER JOIN PlayerEquipment p ON m.Id = p.EquipmentId
                WHERE p.AccountId = @Id", new { Id = accountId });

            var result = equipment.Select(e => new
            {
                prefabName = (string)e.PrefabName,
                modificationGuid = (string)e.ModificationGuid,
                unlockedLevel = 0,
                favorited = e.Favorited == 1 || (e.Favorited is bool b && b),
                platformMask = -1,
                friendlyName = (string)e.FriendlyName,
                tooltip = (string)e.Tooltip,
                rarity = (int)e.Rarity
            });

            return Results.Ok(result);
        });

        app.MapPost("/api/equipment/v1/update", async (HttpContext context, DatabaseManager dbManager) =>
        {
            string authHeader = context.Request.Headers["Authorization"];
            string subId = ClientSecurity.GetIdFromToken(authHeader);
            if (!int.TryParse(subId, out int accountId)) return Results.Unauthorized();

            using var reader = new StreamReader(context.Request.Body);
            string requestBody = await reader.ReadToEndAsync();
            var updates = Newtonsoft.Json.JsonConvert.DeserializeObject<List<dynamic>>(requestBody);

            if (updates == null || updates.Count == 0) return Results.Ok();
            using var db = dbManager.GetConnection();

            foreach (var update in updates)
            {
                string upGuid = update.ModificationGuid;
                bool upFav = update.Favorited;

                await db.ExecuteAsync(@"
                    UPDATE PlayerEquipment 
                    SET Favorited = @IsFavorited
                    WHERE AccountId = @AccountId 
                    AND EquipmentId = (SELECT Id FROM AllEquipment WHERE ModificationGuid = @Guid LIMIT 1)", 
                new { 
                    IsFavorited = upFav ? 1 : 0, 
                    AccountId = accountId, 
                    Guid = upGuid 
                });
            }
            return Results.Content("{}", "application/json");
        });

        app.MapGet("/api/consumables/v2/getUnlocked", async (HttpContext context, DatabaseManager dbManager) =>
        {
            string authHeader = context.Request.Headers["Authorization"];
            string subId = ClientSecurity.GetIdFromToken(authHeader);
            if (!int.TryParse(subId, out int accountId)) accountId = 1;

            using var db = dbManager.GetConnection();

            var consumables = await db.QueryAsync<dynamic>(@"
                SELECT 
                    m.Id, m.Ids, m.ConsumableItemDesc, m.Category,
                    p.Count, p.IsActive
                FROM AllConsumables m
                INNER JOIN PlayerConsumables p ON m.Id = p.ConsumableItemId
                WHERE p.AccountId = @AccountId", new { AccountId = accountId });

            string fixedDate = "2022-02-19T05:29:59.909Z";

            var result = consumables.Select(c => new
            {
                Id = (int)c.Id,
                Ids = new List<int> { (int)c.Id },
                ConsumableItemDesc = (string)c.ConsumableItemDesc,
                PlatformMask = -1,
                CreatedAt = fixedDate,
                CreatedAts = new List<string> { fixedDate }, 
                Count = (int)c.Count,
                InitialCount = (int)c.Count,
                UnlockedLevel = 0,
                IsActive = Convert.ToInt32(c.IsActive) == 1,
                IsTransferable = true,
                Category = (int)c.Category
            });

            return Results.Ok(result);
        });

        app.MapPost("/api/settings/v2/set", async (HttpContext context, DatabaseManager dbManager) =>
        {
            string authHeader = context.Request.Headers["Authorization"];
            string subId = ClientSecurity.GetIdFromToken(authHeader);
            if (!int.TryParse(subId, out int accountId)) return Results.Unauthorized();

            using var reader = new StreamReader(context.Request.Body);
            string requestBody = await reader.ReadToEndAsync();
            var update = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(requestBody);

            if (update == null || update.Key == null) return Results.BadRequest();

            string key = (string)update.Key;
            string val = (string)update.Value;

            using var db = dbManager.GetConnection();

            await db.ExecuteAsync(@"
                INSERT INTO PlayerSettings (AccountId, `Key`, `Value`) 
                VALUES (@AccountId, @Key, @Value) 
                ON DUPLICATE KEY UPDATE `Value` = @Value", 
                new { AccountId = accountId, Key = key, Value = val });

            Console.WriteLine($"[Settings] Set {key} to {val} for Account {accountId}");

            return Results.Ok(new { success = true });
        });
        // -----------------------------

        // --- Moderation ---
        app.MapGet("/api/PlayerReporting/v1/moderationBlockDetails", () => Results.Content("{\"ReportCategory\":0,\"Duration\":0,\"GameSessionId\":0,\"IsHostKick\":false,\"Message\":\"\",\"PlayerIdReporter\":null,\"IsBan\":false}", "application/json"));

        app.MapPost("/api/PlayerReporting/v1/hile", () => new
        {
            Message = "",
            Type = 0
        });
        //-------------------

        // --- Reputation & Progression ---
        app.MapGet("/api/playerReputation/v2/bulk", async (HttpContext context, DatabaseManager dbManager) =>
        {
            if (!int.TryParse(context.Request.Query["id"], out int id)) return Results.BadRequest();

            using var db = dbManager.GetConnection();

            var rep = await db.QueryFirstOrDefaultAsync<dynamic>(@"
                SELECT * FROM PlayerReputations WHERE AccountId = @Id", new { Id = id });

            if (rep == null) return Results.Ok(new List<object>());

            return Results.Ok(new[] { new {
                accountId = (int)rep.AccountId,
                isCheerful = rep.IsCheerful,
                cheerGeneral = (int)rep.CheerGeneral,
                cheerHelpful = (int)rep.CheerHelpful,
                cheerGreatHost = (int)rep.CheerGreatHost,
                cheerSportsman = (int)rep.CheerSportsman,
                cheerCreative = (int)rep.CheerCreative,
                CheerCredit = (int)rep.CheerCredit,
                subscriberCount = (int)rep.SubscriberCount,
                subscribedCount = (int)rep.SubscribedCount,

                notoriety = (int)rep.Notoriety,
                selectedCheer = (int?)rep.SelectedCheer
            }});
        });

        app.MapGet("/api/players/v2/progression/bulk", async (HttpContext context, DatabaseManager dbManager) =>
        {
            if (!int.TryParse(context.Request.Query["id"], out int id)) return Results.BadRequest();

            using var db = dbManager.GetConnection();

            var prog = await db.QueryFirstOrDefaultAsync<dynamic>(@"
                SELECT AccountId, Level, XP 
                FROM PlayerProgressions 
                WHERE AccountId = @Id", new { Id = id });

            if (prog == null)
            {
                //return Results.Ok(new[] { new { PlayerId = id, Level = 1, XP = 0 } });
                return Results.Ok(new List<object>());
            }

            return Results.Ok(new[] { new { 
                PlayerId = (int)prog.AccountId, 
                Level = (int)prog.Level, 
                XP = (int)prog.XP 
            } });
        });
        //----------------------------------

        // --- Relationship ---
        app.MapGet("/api/relationships/v2/get", BracketResponse); //Might need changing


        // --- MISC ---
        app.MapPost("/ws/negotiate", (HttpContext context) =>
        {
            return Results.Ok(new
            {
                connectionId = "Huba",
                availableTransports = new[] {
                    new {
                        transport = "WebSockets",
                        transferFormats = new[] { "Text", "Binary" }
                    }
                }
            });
        });

        app.MapGet("/thread", BracketResponse);

        app.MapGet("/api/quickPlay/v1/getandclear", () => new { });

        //Blank for now till we add messages. Probably MessagesServer.cs or something
        app.MapGet("/api/messages/v2/get", BracketResponse);

        app.MapGet("/config/LoadingScreenTipData", () =>
        {
            // Using triple quotes lets us paste JSON directly without escaping
            string json = """
            [
                {
                    "ImageName": "Community/room/DormRoom.png",
                    "Message": "Check out your own personal space!",
                    "PlatformMask": -1,
                    "RoomNames": [],
                    "Title": "Welcome to your Dorm Room!"
                },
                {
                    "ImageName": "Community/room/intro/intro.png",
                    "Message": "Let's see what Rec Room is all about. Head inside to start playing!",
                    "PlatformMask": -1,
                    "RoomNames": [ "orientation" ],
                    "Title": "Welcome to Rec Room"
                }
            ]
            """;

            return Results.Content(json, "application/json");
        });

        //Roles
        app.MapGet("/role/developer/{id}", async (long id, DatabaseManager dbManager) =>
        {
            using var db = dbManager.GetConnection();

            bool isDeveloper = await db.QuerySingleOrDefaultAsync<bool>(
                "SELECT IsDeveloper FROM Accounts WHERE Id = @Id",
                new { Id = id });

            return Results.Text(isDeveloper.ToString().ToLower(), "text/plain");
        });
        app.MapGet("/role/moderator/{id}", async (long id, DatabaseManager dbManager) =>
        {
            using var db = dbManager.GetConnection();

            bool isModerator = await db.QuerySingleOrDefaultAsync<bool>(
                "SELECT IsModerator FROM Accounts WHERE Id = @Id",
                new { Id = id });
            return Results.Text(isModerator.ToString().ToLower(), "text/plain");
        });
        //--------
        
        //Chat
        app.MapPost("/api/sanitize/v1", async (HttpContext context) =>
        {
            var request = await context.Request.ReadFromJsonAsync<SanitizeRequest>();
    		string cleanValue = request?.Value ?? "";

    		return Results.Json(cleanValue);
        });

        // Temp here
        //Till we add Weekly
        /*app.MapGet("/api/challenge/v2/getCurrent", () => new
        {
            ChallengeMapId = 0,
            StartAt = "2021-12-27T21:27:38.188Z",
            EndAt = "2028-12-27T21:27:38.188Z",
            ServerTime = "2026-04-14T21:27:38.188Z",
            Challenges = new object[] { },
            Gift = new
            {
                GiftDropId = 1,
                AvatarItemDesc = "",
                Xp = 2,
                Level = 0,
                EquipmentPrefabName = "[PaintBallRifleScoped]"
            },
            ChallengeThemeString = "Water",
            FallbackGiftName = ""
        });*/

        //Till we add announcements
        app.MapGet("/announcements/v2/subscription/mine/unread", BracketResponse);
        app.MapGet("/announcements/v2/mine/unread", BracketResponse);

        app.MapGet("/api/PlayerReporting/v1/voteToKickReasons", BracketResponse);

        app.MapGet("/api/objectives/v1/myprogress", () => new
        {
            
            Objectives = new []
            {
                new { Index = 2, Group = 0, Progress = 0, VisualProgress = 0, IsCompleted = false, IsRewarded = false, HasClaimedReward = false },
                new { Index = 1, Group = 0, Progress = 0, VisualProgress = 0, IsCompleted = false, IsRewarded = false, HasClaimedReward = false },
                new { Index = 0, Group = 0, Progress = 0, VisualProgress = 0, IsCompleted = false, IsRewarded = false, HasClaimedReward = false }
            },
            ObjectiveGroups = new[]
            {
                new { Group = 0, IsCompleted = false, ClearedAt = "2026-04-14T01:59:14.864Z" }
            }
        });

        app.MapGet("/api/gamerewards/v1/pending", BracketResponse);

        app.MapGet("/api/communityboard/v2/current", () => new
        {
            //FeaturedPlayer = new { Id = 9809516, TitleOverride = "You!", UrlOverride = (string?)null },
            FeaturedPlayer = new { Id = 1, TitleOverride = "You!", UrlOverride = (string?)null },
            FeaturedRoomGroup = new
            {
                FeaturedRoomGroupId = 0,
                Name = "Get Started",
                Rooms = new[]
                {
                    new { RoomName = "TacoLoft", RoomId = 6447, ImageName = "Pc8fGEuX9EGqLlOfnNR3xw" },
                    new { RoomName = "forsophie1", RoomId = 367247, ImageName = "b59b03d3e2234af8a0ae5b9043440580" },
                    new { RoomName = "3DCharades", RoomId = 3, ImageName = "57c0a08d2d074cd0ad499bb74cae197f.png" },
                    new { RoomName = "Paintball", RoomId = 8, ImageName = "93a53ced93a04f658795a87f4a4aab85" },
                    new { RoomName = "GoldenTrophy", RoomId = 13, ImageName = "38e9d0d4eff94556a0b106508249dcf9" }
                    // Note: I shortened the list for code brevity, but you can add all of them back!
                },
                FeaturedRooms = new[]
                {
                    new { RoomName = "Paintball", RoomId = 8, ImageName = "93a53ced93a04f658795a87f4a4aab85" }
                }
            },
            CurrentAnnouncement = new
            {
                Message = "Subscribe To The Nebulon Youtube Channel!",
                MoreInfoUrl = "https://www.youtube.com/@Slat"
            },
            InstagramImages = (object?)null,
            Videos = new List<object>()
            {
                new
                {
     				BlobName = "023da8cad03470805b64c6967293e006.mp4",
      				Title= "cdn test",
      				Description = "",
      				ThumbnailBlobName= "2f86b86c66d244c0855e957aca84174f",
      				SourceUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
                }
            }
        });

        app.MapGet("/api/playerevents/v1/all", () => new
        {
            Created = new object[] { },
            Responses = new object[] { }
        });

        app.MapGet("/api/roomkeys/v1/mine", BracketResponse);

        app.MapPost("/api/CampusCard/v1/UpdateAndGetSubscription", () => new
        {
            subscription = new
            {
                subscriptionId = 1,
                //recNetPlayerId = 9809516, // Use your AccountId here
                recNetPlayerId = 1,
                platformId = "1",
                platformPurchaseId = "1",
                level = 0,
                period = 0,
                expirationDate = "2028-12-27T21:27:38.188Z",
                isAutoRenewing = true,
                createdAt = "2021-12-27T21:27:38.188Z",
                modifiedAt = "2026-04-14T21:27:38.188Z"
            }
        });

        app.MapGet("/api/announcement/v1/get", BracketResponse);
		app.MapGet("/api/inventions/v2/mine", BracketResponse);
        app.MapGet("/api/roomcurrencies/v1/betaEnabled", () => Results.Content("true", "application/json"));
        app.MapGet("/api/roomkeys/v1/room", (int roomId) => Results.Ok(new object[] { }));


        app.MapPut("/player/statusvisibility", () => Results.Ok());
        app.MapPost("/player/photonregionpings", () => Results.Ok());
        app.MapPut("/player/vrmovementmode", () => Results.Ok(new { success = true }));

    }
}

public class SanitizeRequest
{
    public string Value { get; set; }
    public int ReplacementChar { get; set; }
}