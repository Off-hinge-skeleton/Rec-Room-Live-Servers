using Microsoft.AspNetCore.Mvc;
using LiteDB;
using Dapper;
using Newtonsoft.Json.Linq;

public static class AccountServer
{
    public static void MapAccountServerEndpoints(this IEndpointRouteBuilder app)
    {

        /*app.MapGet("/cachedlogin/forplatformid/{platform}/{id}", async (int platform, string id, DatabaseManager dbManager) =>
        {
            using var db = dbManager.GetConnection();

            var results = await db.QueryAsync<dynamic>(@"
            SELECT Platform, PlatformId, AccountId, LastTimeLogin
            FROM CachedLogins
            WHERE PlatformId = @PlatformId AND Platform = @Platform", new { PlatformId = id, Platform = platform });

            return Results.Ok(results.Select(c => new
            {
                platform = c.Platform,
                platformId = c.PlatformId,
                accountId = c.AccountId,
                lastLoginTime = c.LastTimeLogin
            }));
        });*/
        
        app.MapPost("/cachedlogin/forplatformids", async (HttpContext context, DatabaseManager dbManager) =>
        {
            var form = await context.Request.ReadFormAsync();
            var platformIds = form["id"].ToList();

            if (platformIds.Count == 0)
            {
                return Results.Ok(new List<object>());
            }

            using var db = dbManager.GetConnection();

            var logins = await db.QueryAsync<dynamic>(@"
                SELECT cl.AccountId, cl.PlatformId
                FROM CachedLogins cl
                WHERE cl.PlatformId IN @Ids",
                new { Ids = platformIds });

            var resultList = logins.Select(login => new
            {
                platform = 0,
                platformId = login.PlatformId.ToString(),
                accountId = (int)login.AccountId,
                lastLoginTime = DateTime.UtcNow
            }).ToList();

            return Results.Ok(resultList);
        });

        app.MapPost("/account/create", async (HttpContext context, DatabaseManager dbManager) =>
        {
            var form = await context.Request.ReadFormAsync();
            
            string platformId = form["platformId"];
            string deviceId = form["deviceId"];
            int platform = int.TryParse(form["platform"], out var p) ? p : 0;

            string randomName = "Player" + new Random().Next(1000, 9999);
            //string now = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ");
            DateTime now = DateTime.UtcNow;
            string defaultProfileImage = "hdqeamlcmatc6qzoi2ybgf0ddijjcf.jpg";

            using var db = dbManager.GetConnection();

            int newAccountId = await db.QuerySingleAsync<int>(@"
                INSERT INTO Accounts (
                    Username, DisplayName, Bio, BannerImage, ProfileImage, 
                    CreatedAt, IsJunior, IsDeveloper, IsModerator, 
                    Tokens, LaserTickets, IsleGold, CrescendoSilver,
                    PersonalPronouns, IdentityFlags, AvailableUsernameChanges,
                    RegistrationStatus
                ) VALUES (
                    @Name, @Name, 'I''m new here!', 'default', @ProfileImage, 
                    @Date, 0, 0, 0, 
                    500, 0, 0, 0,
                    0, 0, 1, 
                    0
                );
                SELECT LAST_INSERT_ID();", 
                new { 
                    Name = randomName, 
                    Date = now, 
                    ProfileImage = $"{randomName}.jpg" 
                });

            await db.ExecuteAsync(@"
                INSERT INTO CachedLogins (Platform, DeviceId, PlatformId, AccountId, LastTimeLogin)
                VALUES (@Platform, @DeviceId, @PlatformId, @AccountId, @Date)",
                new { Platform = platform, DeviceId = deviceId, PlatformId = platformId, AccountId = newAccountId, Date = now });

            await db.ExecuteAsync(@"
                INSERT INTO PlayerAvatarItems (AccountId, AvatarItemId)
                SELECT @AccountId, A.Id FROM AllAvatarItems A
                INNER JOIN DefaultAvatarItems D ON A.AvatarItemDesc = D.AvatarItemDesc",
                new { AccountId = newAccountId });

            await db.ExecuteAsync(@"
                INSERT INTO PlayerEquipment (AccountId, EquipmentId)
                SELECT @AccountId, E.Id FROM AllEquipment E
                INNER JOIN DefaultEquipment D ON E.ModificationGuid = D.SkinGuid",
                new { AccountId = newAccountId });

            await db.ExecuteAsync(@"
                INSERT INTO PlayerAvatars (AccountId, OutfitSelection, FaceFeatures, SkinColor, HairColor) 
                VALUES (@AccountId, '', '', '', '')",
                new { AccountId = newAccountId });

            await db.ExecuteAsync(@"
                INSERT INTO PlayerProgressions (AccountId, Level, XP) 
                VALUES (@AccountId, 1, 0)", 
                new { AccountId = newAccountId });

            await db.ExecuteAsync(@"
                INSERT INTO PlayerReputations (
                    AccountId, Notoriety, CheerGeneral, CheerGreatHost, CheerSportsman, CheerCreative, SubscribedCount, SubscriberCount, IsCheerful, SelectedCheer
                ) VALUES (@AccountId, 0, 0, 0, 0, 0, 0, 0, 0, 0)", 
                new { AccountId = newAccountId });

            return Results.Ok(new
            {
                success = true,
                value = new
                {
                    AccountId = newAccountId,
                    Username = randomName,
                    DisplayName = randomName,
                    ProfileImage = "defaultProfileImage",
                    BannerImage = "default",
                    isJunior = (bool?)null,
                    Platforms = platform,
                    PersonalPronouns = 0,
                    IdentityFlags = 0,
                    CreatedAt = now,
                    Email = (string)null,
                    Phone = (string)null,
                    JuniorState = (int?)null,
                    Birthday = (string)null,
                    ParentAccountId = (int?)null,
                    AvailableUsernameChanges = 1,
                    IsVerified = false,
                    RegistrationStatus = 2
                }
            });
        });
          

        app.MapGet("/account/bulk", async ([FromQuery(Name = "id")] int[] id, DatabaseManager dbManager) =>
        {
            if (id == null || id.Length == 0) return Results.Ok(new object[] { });

            using var db = dbManager.GetConnection();

            var accounts = await db.QueryAsync<dynamic>(@"
                SELECT 
                    Id, Username, DisplayName, ProfileImage, BannerImage, IsJunior, CreatedAt 
                FROM Accounts 
                WHERE Id IN @Ids", new { Ids = id });

            var result = accounts.Select(a => new
            {
                accountId = (int)a.Id,
                username = (string)a.Username,
                displayName = (string)a.DisplayName,
                profileImage = (string)a.ProfileImage,
                bannerImage = (string)a.BannerImage,
                isJunior = a.IsJunior == 1 || (a.IsJunior is bool b && b),
                platforms = 0,
                createdAt = a.CreatedAt.ToString()
            });

            return Results.Ok(result);
        });

        app.MapGet("/account/me", async (HttpContext context, DatabaseManager dbManager) =>
        {
            string authHeader = context.Request.Headers["Authorization"];
            string subId = ClientSecurity.GetIdFromToken(authHeader);

            if (!int.TryParse(subId, out int accountId)) return Results.Unauthorized();

            using var db = dbManager.GetConnection();

            var account = await db.QueryFirstOrDefaultAsync<dynamic>(@"
                SELECT 
                    Id, Username, DisplayName, ProfileImage, BannerImage, IsJunior, CreatedAt 
                FROM Accounts 
                WHERE Id = @Id", new { Id = accountId });

            if (account == null) return Results.Unauthorized();

            return Results.Ok(new
            {
                accountId = (int)account.Id,
                username = (string)account.Username,
                displayName = (string)account.DisplayName,
                profileImage = (string)account.ProfileImage,
                bannerImage = (string)account.BannerImage,
                isJunior = account.IsJunior == 1 || (account.IsJunior is bool b && b),
                platforms = 0,
                createdAt = account.CreatedAt.ToString(),
                isVerified = true,
                registrationStatus = 2
            });
        });

        app.MapPost("/player/login", () => new
        {
            access_token = "eyJhbGciOiJSUzI1NiIsImtpZCI6IkREU2F1d2dZdkE1S1NEcVFQWHJRbk1ZeXhMbyIsInR5cCI6ImF0K2p3dCIsIng1dCI6IkREU2F1d2dZdkE1S1NEcVFQWHJRbk1ZeXhMbyJ9.eyJuYmYiOjE2Njk1NzUzOTksImV4cCI6MTY2OTU3ODk5OSwiaXNzIjoiaHR0cHM6Ly9hdXRoLnJlYy5uZXQiLCJjbGllbnRfaWQiOiJyZWNuZXQiLCJyb2xlIjoid2ViQ2xpZW50Iiwic3ViIjoiNjIyNjgwNyIsImF1dGhfdGltZSI6MTY1Nzc3Mzk1NSwiaWRwIjoibG9jYWwiLCJqdGkiOiJEOUUwNTY2QjU2NTE4QkNEMjBBNjRDMkQ2MzUwQzRFMyIsInNpZCI6IjU2NEY5QUFGQzNBRjQxREQwQTQzOENDMTlFODk5NzYzIiwiaWF0IjoxNjY5NTc1Mzk5LCJzY29wZSI6WyJvcGVuaWQiLCJybi5hcGkiLCJybi5jb21tZXJjZSIsInJuLm5vdGlmeSIsInJuLm1hdGNoLnJlYWQiLCJybi5jaGF0Iiwicm4uYWNjb3VudHMiLCJybi5hdXRoIiwicm4ubGluayIsInJuLmNsdWJzIiwicm4ucm9vbXMiLCJybi5kaXNjb3ZlcnkiXSwiYW1yIjpbIm1mYSJdfQ.TVkpz8Nbmz_8fFdbf3xI0CHwjogaIR45TmhK4NXSgx__e85M0xNO8UDSbGJaUMeSN7rn_I1obrzvqqJhDjqOAyQs39rtKJ-lyMq_oFDf1DOjFhB_KWCQ3V_N1SIOpoTnzoD7kr3voixtB4VrTo1HkUQPK_6a2FvUfg3sNwBBAxVvSv7jRPF5_BLGLRACfT3vIHfM7baSOFYkgijnGu9Okd4XKCSolb0hBO14vRMSUZ_gzdm2YubWEF5PK4kiIKMLnnvqUIAXt37sn0m7SjFK_7CI5K7TcSGJcnO-r63PaKsH3UfPqkTq6QWJKUh9X59mQcUJ6iClkY6Pv8LZWjqpkg",
            refresh_token = "",
            error = "",
            error_description = "eyJhbGciOiJSUzI1NiIsImtpZCI6IkREU2F1d2dZdkE1S1NEcVFQWHJRbk1ZeXhMbyIsInR5cCI6ImF0K2p3dCIsIng1dCI6IkREU2F1d2dZdkE1S1NEcVFQWHJRbk1ZeXhMbyJ9.eyJuYmYiOjE2Njk1NzUzOTksImV4cCI6MTY2OTU3ODk5OSwiaXNzIjoiaHR0cHM6Ly9hdXRoLnJlYy5uZXQiLCJjbGllbnRfaWQiOiJyZWNuZXQiLCJyb2xlIjoid2ViQ2xpZW50Iiwic3ViIjoiNjIyNjgwNyIsImF1dGhfdGltZSI6MTY1Nzc3Mzk1NSwiaWRwIjoibG9jYWwiLCJqdGkiOiJEOUUwNTY2QjU2NTE4QkNEMjBBNjRDMkQ2MzUwQzRFMyIsInNpZCI6IjU2NEY5QUFGQzNBRjQxREQwQTQzOENDMTlFODk5NzYzIiwiaWF0IjoxNjY5NTc1Mzk5LCJzY29wZSI6WyJvcGVuaWQiLCJybi5hcGkiLCJybi5jb21tZXJjZSIsInJuLm5vdGlmeSIsInJuLm1hdGNoLnJlYWQiLCJybi5jaGF0Iiwicm4uYWNjb3VudHMiLCJybi5hdXRoIiwicm4ubGluayIsInJuLmNsdWJzIiwicm4ucm9vbXMiLCJybi5kaXNjb3ZlcnkiXSwiYW1yIjpbIm1mYSJdfQ.TVkpz8Nbmz_8fFdbf3xI0CHwjogaIR45TmhK4NXSgx__e85M0xNO8UDSbGJaUMeSN7rn_I1obrzvqqJhDjqOAyQs39rtKJ-lyMq_oFDf1DOjFhB_KWCQ3V_N1SIOpoTnzoD7kr3voixtB4VrTo1HkUQPK_6a2FvUfg3sNwBBAxVvSv7jRPF5_BLGLRACfT3vIHfM7baSOFYkgijnGu9Okd4XKCSolb0hBO14vRMSUZ_gzdm2YubWEF5PK4kiIKMLnnvqUIAXt37sn0m7SjFK_7CI5K7TcSGJcnO-r63PaKsH3UfPqkTq6QWJKUh9X59mQcUJ6iClkY6Pv8LZWjqpkg"
        });

        app.MapPost("/player/logout", () =>
        {
            return Results.Ok();
        });

        app.MapPost("/player/heartbeat", (HttpContext context) =>
        {
            string authHeader = context.Request.Headers["Authorization"];
            string subId = ClientSecurity.GetIdFromToken(authHeader);
            if (!int.TryParse(subId, out int accountId)) accountId = 1;

            RoomServer.PlayerSessions.TryGetValue(accountId, out JObject? currentRoom);
            var heartbeatResponse = new
            {
                playerId = accountId,
                statusVisibility = 0,
                deviceClass = 0,
                roomInstance = currentRoom, 
                isOnline = true
            };
            string json = Newtonsoft.Json.JsonConvert.SerializeObject(heartbeatResponse);
            
            return Results.Content(json, "application/json");
        });
        /*app.MapPost("/player/heartbeat", async (HttpContext context) =>
        {
            string authHeader = context.Request.Headers["Authorization"];
            string subId = ClientSecurity.GetIdFromToken(authHeader);
            if (!int.TryParse(subId, out int accountId)) accountId = 1;

            context.Request.EnableBuffering();
            using var reader = new StreamReader(context.Request.Body);
            var body = await reader.ReadToEndAsync();

            int statusVis = 0;
            int deviceCls = 1; 

            if (!string.IsNullOrWhiteSpace(body))
            {
                try 
                {
                    var requestData = Newtonsoft.Json.JsonConvert.DeserializeObject<HeartbeatRequest>(body);
                    if (requestData != null) 
                    {
                        statusVis = requestData.statusVisibility;
                        deviceCls = requestData.deviceClass;
                    }
                } 
                catch { }
            }

            RoomServer.PlayerSessions.TryGetValue(accountId, out var currentRoom);

            object? finalRoom = null;
            if (currentRoom != null && currentRoom["roomId"] != null && currentRoom["roomId"].Type != Newtonsoft.Json.Linq.JTokenType.Null)
            {
                finalRoom = currentRoom;
            }

            var heartbeatResponse = new
            {
                playerId = accountId,
                statusVisibility = statusVis,
                deviceClass = deviceCls,
                vrMovementMode = 1,
                roomInstance = finalRoom, 
                isOnline = finalRoom != null,
                appVersion = "20260426",
                platform = 0
            };

            string json = Newtonsoft.Json.JsonConvert.SerializeObject(heartbeatResponse);
            return Results.Content(json, "application/json");
        });*/
    }
}

public class HeartbeatRequest
{
    public int playerId { get; set; }
    public int statusVisibility { get; set; }
    public int deviceClass { get; set; }
    public int vrMovementMode { get; set; }
    public object? roomInstance { get; set; }
    public bool isOnline { get; set; }
    public string? appVersion { get; set; }
    public int platform { get; set; }
}