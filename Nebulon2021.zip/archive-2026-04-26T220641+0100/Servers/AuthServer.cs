using Dapper;
public static class AuthServer
{
    public static void MapAuthServerEndpoints(this IEndpointRouteBuilder app)
    {
        app.MapGet("/eac/challenge", () => Results.Content(":3", "text/plain"));
//app.MapGet("/eac/challenge", () => Results.Content("\"AQAAAOmBNw8TMlSZs9NsuyGxsU7WMoKVcieTW8IyoSMEGcbTIPg7DZ4JGZTCfg4b1h58FOOkM7r0LUhRVwlq8wo528o3LR9g/kHzlrVJA6H0+HaYTQzjKEe+zl5/VupqSXk8PXQ0BlNiRED3x5YMCGiM+F0fYmd0NU4K0d5hY+A=\"", "text/plain"));

        // Called by the game to find which account is linked to a Steam ID
        // Format: /cachedlogin/forplatformid/{platformType}/{steamId}
        app.MapGet("/cachedlogin/forplatformid/{platformType}/{platformId}", async (
            string platformType, string platformId, DatabaseManager dbManager) =>
        {
            using var db = dbManager.GetConnection();
            await db.OpenAsync();
                
            /*var logins = await db.QueryAsync<dynamic>(@"
                SELECT cl.AccountId, cl.DeviceId, cl.PlatformId, cl.LoginLock,
                       a.Username, a.DisplayName
                FROM CachedLogins cl
                INNER JOIN Accounts a ON a.Id = cl.AccountId
                WHERE cl.PlatformId = @PlatformId",
                new { PlatformId = platformId });*/
             var logins = await db.QueryAsync<dynamic>(@"
                SELECT cl.AccountId, cl.DeviceId, cl.PlatformId,
                       a.Username, a.DisplayName
                FROM CachedLogins cl
                INNER JOIN Accounts a ON a.Id = cl.AccountId
                WHERE cl.PlatformId = @PlatformId",
                new { PlatformId = platformId });

            if (logins == null)
            {
                    // No account linked to this Steam ID yet
                    return Results.NotFound(new { error = "No cached login found for this platform ID" });
            }
            
            var resultList = logins.Select(login => new
            {
                platform = int.Parse(platformType),
                platformId = login.PlatformId,
                accountId = login.AccountId,
                lastLoginTime = DateTime.UtcNow
            }).ToList();
            
            return Results.Ok(resultList);

            /*return Results.Ok(new
            {
                accountId  = login.AccountId,
                deviceId   = login.DeviceId,
                platformId = login.PlatformId,
                loginLock  = login.LoginLock
            });*/

        });

        app.MapPost("/connect/token", async (HttpContext context, DatabaseManager dbManager) =>
        {
            var form = await context.Request.ReadFormAsync();
            string platformId = form["platform_id"];
            string deviceId = form["device_id"];

            if (!int.TryParse(form["account_id"], out int requestedId))
            {
                return Results.BadRequest("Missing account_id");
            }

            using var db = dbManager.GetConnection();

            var loginRecord = await db.QueryFirstOrDefaultAsync<dynamic>(@"
                SELECT AccountId FROM CachedLogins 
                WHERE AccountId = @AccId AND (PlatformId = @PId OR DeviceId = @DId)",
                new { AccId = requestedId, PId = platformId, DId = deviceId });

            if (loginRecord == null)
            {
                return Results.Json(new
                {
                    error = "invalid_request",
                    error_description = "Account not linked to this platform"
                }, statusCode: 400);
            }

            var account = await db.QueryFirstOrDefaultAsync<Account>(
                "SELECT * FROM Accounts WHERE Id = @Id", new { Id = requestedId });

            if (account == null) return Results.BadRequest("Account data missing");

            string token = ClientSecurity.GenerateToken(account);

            return Results.Json(new
            {
                access_token  = token,
                token_type    = "Bearer",
                expires_in    = 360000,
                refresh_token = deviceId,
                scope         = "offline_access profile rn rn.accounts rn.accounts.gc rn.api rn.chat rn.clubs rn.commerce rn.match.read rn.match.write rn.notify rn.rooms rn.storage",
                key           = "8oQ+e+WQaOBPbEcakhqs3dwZZdOmmyDUmJSD9u4AHMY=",
                account_id    = requestedId
            });
        });
    }
}