using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.StaticFiles;

public static class CdnServer
{
    public static string DataDir { get; set; } = AppContext.BaseDirectory;

    public static void MapCdnServerEndpoints(WebApplication app)
    {
        app.MapGet("/cdn/{*img_path}", (HttpContext context, string? img_path) =>
        {
            return Results.NotFound();
        });
    }
}