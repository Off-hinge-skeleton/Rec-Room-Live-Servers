public static class ClubServer
{
    public static void MapClubServerEndpoints(this IEndpointRouteBuilder app)
    {
        var BlankResponse = () => Results.Empty;
        var BracketResponse = () => new string[] { };

        app.MapGet("/club/home/me", () => { return Results.NotFound(); });

        app.MapGet("/subscription/mine/member", BracketResponse);

        app.MapGet("/subscription/details/{id}", (int id) => new
        {
            accountId = id,
            clubId = 0,
            subscriberCount = 2
        });
    }
}