using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Formats.Png;
using SixLabors.ImageSharp.PixelFormats;
using SixLabors.ImageSharp.Processing;
using Dapper;
using System.Text.Json;

public static class ImageServer
{
    public static string DataDir { get; set; } = AppContext.BaseDirectory;

    public static void MapImageServerEndpoints(WebApplication app)
    {
        app.MapGet("/imageserver/{*img_path}", async (HttpContext context, string? img_path) =>
        {
            context.Response.StatusCode = 404;
        });
        
        app.MapPost("/api/images/v4/uploadsaved", async (HttpContext context, DatabaseManager dbManager) =>
        {
            try 
            {
                var form = await context.Request.ReadFormAsync();
                var imageFile = form.Files.GetFile("image");
                var metaJson = form["imgMeta"].ToString();

                if (imageFile == null || string.IsNullOrEmpty(metaJson)) return Results.BadRequest();

                var meta = JsonSerializer.Deserialize<ImageMetadata>(metaJson);

                string authHeader = context.Request.Headers["Authorization"];
                string subId = ClientSecurity.GetIdFromToken(authHeader);
                if (!long.TryParse(subId, out long accountId)) accountId = 1;

                using var db = dbManager.GetConnection();
                var username = await db.ExecuteScalarAsync<string>(
                    "SELECT Username FROM Accounts WHERE Id = @Pid", new { Pid = accountId }) ?? "UnknownUser";

                bool isProfilePic = meta.savedImageType == 4;
                string subFolder = isProfilePic ? "ProfilePictures" : "RegularUploads";

                string directoryPath = Path.Combine(Directory.GetCurrentDirectory(), "Images", subFolder);
                if (!Directory.Exists(directoryPath)) Directory.CreateDirectory(directoryPath);

                string timestamp = DateTime.Now.ToString("yyyyMMdd-HHmmss");
                string fileName = $"{timestamp}-{username}.jpg";
                string filePath = Path.Combine(directoryPath, fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await imageFile.CopyToAsync(stream);
                }

                await db.ExecuteAsync(@"
                    INSERT INTO PlayerImages (FileName, OwnerId, RoomId, SavedImageType, PlayersInPhoto, CreatedAt)
                    VALUES (@File, @Owner, @Room, @Type, @Players, NOW())",
                    new {
                        File = fileName,
                        Owner = accountId,
                        Room = meta.roomId,
                        Type = meta.savedImageType,
                        Players = JsonSerializer.Serialize(meta.playerIds)
                    });

                if (isProfilePic)
                {
                    await db.ExecuteAsync(
                        "UPDATE Accounts SET ProfileImage = @Img WHERE Id = @Pid",
                        new { Img = fileName, Pid = accountId });
                }

                return Results.Ok(new { ImageName = fileName });
            }
            catch (Exception ex)
            {
                return Results.Problem(ex.ToString());
            }
        });
        
        app.MapPut("/account/me/profileimage", async (HttpContext context, DatabaseManager dbManager) =>
        {
            string authHeader = context.Request.Headers["Authorization"];
            string subId = ClientSecurity.GetIdFromToken(authHeader);

            if (string.IsNullOrEmpty(subId) || !long.TryParse(subId, out long accountId))
            {
                return Results.Unauthorized();
            }

            string newProfileImage = "";

            context.Request.EnableBuffering();
            using var reader = new StreamReader(context.Request.Body, leaveOpen: true);
            var body = await reader.ReadToEndAsync();

            if (!string.IsNullOrWhiteSpace(body))
            {
                var parts = body.Split('&');
                foreach (var part in parts)
                {
                    var keyValue = part.Split('=');
                    if (keyValue.Length == 2 && Uri.UnescapeDataString(keyValue[0]) == "imageName")
                    {
                        newProfileImage = Uri.UnescapeDataString(keyValue[1]);
                        break;
                    }
                }
            }

            if (string.IsNullOrEmpty(newProfileImage))
            {
                return Results.BadRequest("imageName is required");
            }

            using var db = dbManager.GetConnection();

            int rowsAffected = await db.ExecuteAsync(
                "UPDATE Accounts SET ProfileImage = @Img WHERE Id = @Pid", 
                new { Img = newProfileImage, Pid = accountId });

            if (rowsAffected == 0) return Results.NotFound();

            return Results.Ok(new { Success = true });
        });

        // Catch-all for profile picture requests like /randomName.jpg
        /*app.MapGet("/{filename}.{ext}", async (HttpContext context, string filename, string ext) =>
        {
            context.Response.StatusCode = 404;
        });*/
        
        app.MapGet("/imageserver/{filename}.{ext}", async (HttpContext context, string filename, string ext) =>
        {
                return Results.NotFound();
        });
    }

public class ImageMetadata
{
    public List<long> playerIds { get; set; } = new List<long>(); 
    public int savedImageType { get; set; }
    public long roomId { get; set; }
    public long playerEventId { get; set; }
    public int accessibility { get; set; }
}