using Microsoft.Extensions.Options;
public static class Nameserver
{
    public static void MapNameserverEndpoints(this IEndpointRouteBuilder app)
    {
        app.MapGet("/2", (IOptions<ServerSettings> settings) =>
        {
            //var baseUrl = settings.Value.BaseUrl;
            //var baseUrl = "http://uk1.cp.surden.me:25582";
            var baseUrl = "https://nebulon.oldrecroom.com";

            return new Dictionary<string, string>
            {
                { "Auth", baseUrl },
                { "API", baseUrl },
                { "WWW", baseUrl },
                { "Notifications", baseUrl },
                { "Images", baseUrl + "/imageserver/" },
                { "CDN", baseUrl + "/cdn" },
                { "Commerce", baseUrl },
                { "Matchmaking", baseUrl },
                { "Storage", baseUrl },
                { "Chat", baseUrl },
                { "Leaderboard", baseUrl },
                { "Accounts", baseUrl },
                { "Link", baseUrl },
                { "RoomComments", baseUrl },
                { "Clubs", baseUrl },
                { "Rooms", baseUrl },
                { "PlatformNotifications", baseUrl },
                { "Moderation", baseUrl },
                { "DataCollection", baseUrl }
            };
        });
    }
}