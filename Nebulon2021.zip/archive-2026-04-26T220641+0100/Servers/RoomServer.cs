using Dapper;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json.Linq;
using System.Collections.Concurrent;

public static class RoomServer
{
    public static ConcurrentDictionary<int, JObject> PlayerSessions = new ConcurrentDictionary<int, JObject>();
    public static List<ActiveRoom> ActiveRooms = new List<ActiveRoom>();

    public static void MapRoomServerEndpoints(this IEndpointRouteBuilder app)
    {
        var BracketResponse = () => new string[] { };


            app.MapGet("/rooms/{id}/interactionby/me", async (int id, HttpContext context, DatabaseManager dbManager) =>
        {
            //{"Cheered":true,"Favorited":false,"LastVisitedAt":"2025-03-22T15:47:31.7518452Z"}
            var response = new
            {
                Cheered = false,
                Favorited = false,
                LastVisitedAt = DateTime.Now
            };
            string finalJson = Newtonsoft.Json.JsonConvert.SerializeObject(response);
            return Results.Content(finalJson, "application/json");
        });
        //Get room by Id
        app.MapGet("/rooms/{id}", async (int id, HttpContext context, DatabaseManager dbManager) =>
        {
            string authHeader = context.Request.Headers["Authorization"];
            string subId = ClientSecurity.GetIdFromToken(authHeader);
            if (!int.TryParse(subId, out int accountId)) return Results.Unauthorized();

            using var db = dbManager.GetConnection();

            string roomJson = await db.QueryFirstOrDefaultAsync<string>(
                "SELECT JsonData FROM Rooms WHERE RoomId = @Id", new { Id = id });

            if (string.IsNullOrEmpty(roomJson)) return Results.NotFound();

            JObject room = JObject.Parse(roomJson);

            room["CreatorAccountId"] = accountId;

            if (room["SubRooms"] is JArray subRooms) 
            {
                foreach (var subRoom in subRooms)
                {
                    subRoom["SavedByAccountId"] = accountId;
                }
            }

            if (room["Roles"] is JArray roles && roles.Count > 0)
            {
                roles[0]["AccountId"] = accountId;
                roles[0]["Role"] = 255;
            }
            Console.WriteLine($"[RoomServer] Dorm room loading for {accountId}");
            return Results.Content(room.ToString(Newtonsoft.Json.Formatting.None), "application/json");
        });

        //Get rooms by tag
        app.MapGet("/rooms/hot", async (string? tag, int? take, DatabaseManager dbManager) =>
        {
            using var db = dbManager.GetConnection();

            var roomJson = await db.QueryAsync<string>(
                "SELECT JsonData FROM Rooms WHERE Tags LIKE @TagQuery LIMIT @Take",
                new { TagQuery = $"%{tag}%", Take = take ?? 20}
            );

            var results = new List<Newtonsoft.Json.Linq.JObject>();
            foreach (var json in roomJson)
            {
                results.Add(Newtonsoft.Json.Linq.JObject.Parse(json));
            }

            var response = new
            {
                TotalResults = results.Count,
                Results = results
            };
            string finalJson = Newtonsoft.Json.JsonConvert.SerializeObject(response);
            return Results.Content(finalJson, "application/json");
        });

        //Get room by name
        app.MapGet("/rooms", async (HttpContext context, DatabaseManager dbManager) =>
        {
            string roomName = context.Request.Query["name"].FirstOrDefault();
            if (string.IsNullOrEmpty(roomName)) return Results.BadRequest("Name Parameter missing");

            using var db = dbManager.GetConnection();

            string roomJson = await db.QueryFirstOrDefaultAsync<string>(
                "SELECT JsonData FROM Rooms WHERE Name = @Name", new { Name = roomName });

            if (string.IsNullOrEmpty(roomJson))
            {
                Console.WriteLine($"[RoomServer] Room not found in Database for: {roomName}");
                return Results.NotFound();
            }

            JObject room = JObject.Parse(roomJson);
            Console.WriteLine($"[RoomServer] Found room {roomName}");
            return Results.Content(room.ToString(Newtonsoft.Json.Formatting.None), "application/json");
        });

        app.MapPost("/goto/none", (HttpContext context) =>
        {
            string authHeader = context.Request.Headers["Authorization"];
            string subId = ClientSecurity.GetIdFromToken(authHeader);
            if (!int.TryParse(subId, out int accountId)) accountId = 1;
            string dormSceneId = "76d98498-60a1-430c-ab76-b54a29b7a163";
            if (PlayerSessions.ContainsKey(accountId) && PlayerSessions[accountId] is not null)
            {
                PlayerSessions[accountId] = null;
            }
            return Results.Json(new
            {
                roomInstanceId = 1,
                roomId = 1,
                subRoomId = 1,
                roomInstanceType = 2,
                location = dormSceneId,
                dataBlob = "",
                eventId = 0,
                clubId = 0,
                photonRegionId = "us",
                photonRoomId = Guid.NewGuid().ToString(), 
                name = "DormRoom",
                maxCapacity = 4,
                isFull = false,
                isPrivate = true,
                isInProgress = false,
                EncryptVoiceChat = false
            });
        });

        app.MapPost("/goto/room/{name}/{subRoomName?}", async (string name, string? subRoomName, HttpContext context, DatabaseManager dbManager) =>
        {
            string authHeader = context.Request.Headers["Authorization"];
            string subId = ClientSecurity.GetIdFromToken(authHeader);
            if (!int.TryParse(subId, out int accountId)) accountId = 1;

            var form = await context.Request.ReadFormAsync();
            int.TryParse(form["JoinMode"], out int joinMode);

            using var db = dbManager.GetConnection();

            string templateJson = await db.QuerySingleOrDefaultAsync<string>(
                "SELECT JsonData FROM GotoRooms WHERE RoomName = @Name", new { Name = name });

            if (string.IsNullOrEmpty(templateJson)) 
                return Results.NotFound(new { errorCode = 1, message = "Room not found" });

            ActiveRoom selectedRoom = null;

            bool isPrivateRequest = (joinMode != 0);

            if (!isPrivateRequest) 
            {
                selectedRoom = ActiveRooms.FirstOrDefault(r => 
                    r.RoomName == name && 
                    !r.IsPrivate && 
                    !r.IsInProgress && 
                    r.PlayerIds.Count < r.MaxCapacity);
            }

            if (selectedRoom == null)
            {
                JObject instance = JObject.Parse(templateJson);
                string newPhotonId = Guid.NewGuid().ToString();
                int maxCap = (int)(instance["maxCapacity"] ?? 20);

                selectedRoom = new ActiveRoom
                {
                    RoomName = name,
                    PhotonRoomId = newPhotonId,
                    InstanceData = instance,
                    MaxCapacity = maxCap,
                    IsPrivate = isPrivateRequest,
                    
                };

                selectedRoom.InstanceData["photonRoomId"] = newPhotonId;
                selectedRoom.InstanceData["isPrivate"] = selectedRoom.IsPrivate;
                
                ActiveRooms.Add(selectedRoom);
            }

             
            if (PlayerSessions.ContainsKey(accountId) && PlayerSessions[accountId] is not null &&
                (int?)PlayerSessions[accountId]["roomId"] is not null &&
                (int?)selectedRoom.InstanceData["roomId"] is not null &&
                (int?)PlayerSessions[accountId]["roomId"] == (int)(selectedRoom.InstanceData["roomId"] ?? 0) &&
                (int?)PlayerSessions[accountId]["subRoomId"] is not null &&
                (int?)selectedRoom.InstanceData["subRoomId"] is not null &&
                (int?)PlayerSessions[accountId]["subRoomId"] == (int)(selectedRoom.InstanceData["subRoomId"] ?? 0))
            {
                var responseObj1 = new
                {
                    errorCode = 13,
                };
                string finalJson1 = Newtonsoft.Json.JsonConvert.SerializeObject(responseObj1);
            	return Results.Content(finalJson1, "application/json");
                //return Results.Content(new { errorCode = 13, message = "Already In Best Instance" });
            }
            
            if (!selectedRoom.PlayerIds.Contains(accountId))
            {
                selectedRoom.PlayerIds.Add(accountId);
            }
            
            selectedRoom.InstanceData["isFull"] = selectedRoom.PlayerIds.Count >= selectedRoom.MaxCapacity;
           
            
            selectedRoom.InstanceData["roomInstanceId"] = new Random().NextInt64(1000, 999999);
            
            PlayerSessions[accountId] = selectedRoom.InstanceData;

            var responseObj = new
            {
                errorCode = 0,
                roomInstance = new
                {
                    roomInstanceId = (long)(selectedRoom.InstanceData["roomInstanceId"] ?? 0),
                    roomId = (int)(selectedRoom.InstanceData["roomId"] ?? 0),
                    subRoomId = (int)(selectedRoom.InstanceData["subRoomId"] ?? 0),
                    roomInstanceType = (int)(selectedRoom.InstanceData["roomInstanceType"] ?? 0),
                    location = (string)selectedRoom.InstanceData["location"],
                    photonRegionId = (string)selectedRoom.InstanceData["photonRegionId"],
                    photonRoomId = (string)selectedRoom.InstanceData["photonRoomId"],
                    name = (string)selectedRoom.InstanceData["name"],
                    maxCapacity = (int)selectedRoom.MaxCapacity,
                    dataBlob = (string)selectedRoom.InstanceData["dataBlob"] ?? "",
                    isFull = (bool)selectedRoom.InstanceData["isFull"],
                    isPrivate = (bool)selectedRoom.InstanceData["isPrivate"],
                    isInProgress = (bool)(selectedRoom.InstanceData["isInProgress"] ?? false)
                }
            };

            string finalJson = Newtonsoft.Json.JsonConvert.SerializeObject(responseObj);
            return Results.Content(finalJson, "application/json");
        });

        app.MapGet("/rooms/bulk", async (string name, HttpContext context, DatabaseManager dbManager) =>
        {
            using var db = dbManager.GetConnection();

            string roomJson = await db.QuerySingleOrDefaultAsync<string>("SELECT JsonData FROM Rooms WHERE Name = @Name", new { Name = name });

            if (string.IsNullOrEmpty(roomJson)) return Results.Content("[]", "application/json");

            string bulkResponse = $"[{roomJson}]";

            return Results.Content(bulkResponse, "application/json");
        });

        app.MapGet("/rooms/createdby/me", BracketResponse);


    }
}

public class ActiveRoom
{
    public string RoomName { get; set; }
    public string PhotonRoomId { get; set; }
    public JObject InstanceData { get; set; }
    public List<int> PlayerIds { get; set; } = new List<int>();
    public bool IsPrivate { get; set; }
    public bool IsInProgress { get; set; }
    public int MaxCapacity { get; set; }
}
