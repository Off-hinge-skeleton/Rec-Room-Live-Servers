using System.Data.Common;
using Dapper;
using Microsoft.AspNetCore.Http.Features;

public static class StorefrontServer
{
    public static void MapStorefrontServerEndpoints(this IEndpointRouteBuilder app)
    {
        app.MapGet("/api/storefronts/v4/balance/{currencyId}", async (int currencyId, HttpContext context, DatabaseManager dbManager) =>
        {
            string authHeader = context.Request.Headers["Authorization"];
            string subId = ClientSecurity.GetIdFromToken(authHeader);
            if (!int.TryParse(subId, out int accountId)) accountId = 1;
            string columnName = currencyId switch
            {
                1 => "LaserTickets",
                2 => "Tokens",
                100 => "IsleGold",
                101 => "CrescendoSilver",
                _ => "Tokens"
            };

            using var db = dbManager.GetConnection();

            int amount = await db.ExecuteScalarAsync<int>(
                $"SELECT {columnName} FROM Accounts WHERE Id = @Id", new { Id = accountId });

            var response = new List<object>
            {
                new 
                { 
                    Id = accountId, 
                    CurrencyType = currencyId, 
                    Balance = amount 
                }
            };
            
            string json = Newtonsoft.Json.JsonConvert.SerializeObject(response);
            return Results.Content(json, "application/json");
        });

        app.MapGet("/api/storefronts/v3/giftdropstore/{id}", async (int id, DatabaseManager dbManager) =>
        {
            using var db = dbManager.GetConnection();

            var storefront = await db.QueryFirstOrDefaultAsync<dynamic>(
                "SELECT * FROM Storefronts WHERE Id = @Id", new { Id = id });

            if (storefront == null) return Results.NotFound();

            //Calculate next update for rec center
            DateTime nextUpdate;
            int type = (int)storefront.StorefrontType;

            if (type == 2)
            {
                DateTime now = DateTime.UtcNow;
                int daysUntilWednesday = ((int)DayOfWeek.Wednesday - (int)now.DayOfWeek + 7) % 7;
                if (daysUntilWednesday == 0 && now.Hour >= 22) daysUntilWednesday = 7;
                nextUpdate = now.Date.AddDays(daysUntilWednesday).AddHours(22);
            }
            else
            {
                string dbDate = (string)storefront.NextUpdate;
                if (!DateTime.TryParse(dbDate, out nextUpdate)) nextUpdate = DateTime.UtcNow.AddYears(1);
            }

            var items = (await db.QueryAsync<dynamic>(@"
                SELECT * FROM StorefrontItems 
                WHERE StorefrontId = @Id 
                AND (ActiveFrom IS NULL OR ActiveFrom <= CURRENT_TIMESTAMP)
                AND (ActiveTo IS NULL OR ActiveTo >= CURRENT_TIMESTAMP)", 
                new { Id = id })).ToList();

            var storeItemsList = new List<object>();

            foreach (var item in items)
            {
                var giftDrop = await db.QueryFirstOrDefaultAsync<dynamic>(
                    "SELECT * FROM GiftDrops WHERE StorefrontItemId = @Id", new { Id = item.Id });

                var prices = await db.QueryAsync<dynamic>(
                    "SELECT * FROM StorefrontPrices WHERE StorefrontItemId = @Id", new { Id = item.Id });

                if (giftDrop == null) continue;

                storeItemsList.Add(new
                {
                    GiftDrop = new
                    {
                        GiftDropId = (int)giftDrop.GiftDropId,
                        FriendlyName = (string)giftDrop.FriendlyName ?? "",
                        Tooltip = (string)giftDrop.Tooltip ?? "",
                        ConsumableItemDesc = (string)giftDrop.ConsumableItemDesc,
                        AvatarItemDesc = (string)giftDrop.AvatarItemDesc,
                        AvatarItemType = (int)giftDrop.AvatarItemType,
                        EquipmentPrefabName = (string)giftDrop.EquipmentPrefabName,
                        EquipmentModificationGuid = (string)giftDrop.EquipmentModificationGuid,
                        IsQuery = giftDrop.IsQuery != 0,
                        Unique = giftDrop.UniqueItem != 0, 
                        SubscribersOnly = giftDrop.SubscribersOnly != 0,
                        Rarity = (int)giftDrop.Rarity,
                        CurrencyType = (int)giftDrop.CurrencyType,
                        Currency = (int)giftDrop.Currency,
                        Context = (int)giftDrop.Context,
                        ItemSetId = (int?)giftDrop.ItemSetId,
                        ItemSetFriendlyName = (string)giftDrop.ItemSetFriendlyName
                    },
                    PurchasableItemId = (int)item.PurchasableItemId,
                    Type = (int)item.Type,
                    Prices = prices.Select(p => new { 
                        CurrencyType = (int)p.CurrencyType, 
                        Price = (int)p.Price,
                        StorefrontSaleData = (object)null 
                    }).ToList(),
                    SubscriberPrices = new List<object>(),
                    IsFeatured = item.IsFeatured != 0,
                    NewUntil = (DateTime?)item.NewUntil
                });
            }

            return Results.Json(new
            {
                StorefrontType = type,
                SubscriberDiscountPercent = 0,
                NextUpdate = nextUpdate,
                NewUntil = (DateTime?)null,
                StoreItems = storeItemsList
            });
        }) ;

        app.MapPost("/api/storefronts/v2/buyItem", async (HttpContext context, DatabaseManager dbManager) =>
        {
            string authHeader = context.Request.Headers["Authorization"];
            string subId = ClientSecurity.GetIdFromToken(authHeader);
            if (!int.TryParse(subId, out int accountId)) return Results.Unauthorized();

            using var reader = new StreamReader(context.Request.Body);
            string rawJson = await reader.ReadToEndAsync();
            var buyRequest = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(rawJson);

            int purchasableId = (int)buyRequest.PurchasableItemId;
            int currencyType = (int)buyRequest.CurrencyType;

            using var db = dbManager.GetConnection();

            var item = await db.QueryFirstOrDefaultAsync<dynamic>(
                 "SELECT Id FROM StorefrontItems WHERE PurchasableItemId = @Id", new { Id = purchasableId });

            if (item == null) 
                return Results.Ok(new { BalanceUpdates = new List<object> { new { UpdateResponse = 4 } } });

            int? price = await db.QueryFirstOrDefaultAsync<int?>(
                "SELECT Price FROM StorefrontPrices WHERE StorefrontItemId = @Id AND CurrencyType = @Currency",
                new { Id = item.Id, Currency = currencyType });

            if (price == null) return Results.BadRequest();

            int currentTokens = await db.QueryFirstOrDefaultAsync<int>(
                "SELECT Tokens FROM Accounts WHERE Id = @Id", new { Id = accountId });
            if (currentTokens < price)
                return Results.Ok(new { BalanceUpdates = new List<object> { new { UpdateResponse = 2 } } });

            await db.ExecuteAsync("UPDATE Accounts SET Tokens = Tokens - @Price WHERE Id = @Id",
                new { Price = price, Id = accountId });
            
            var giftDrop = await db.QueryFirstOrDefaultAsync<dynamic>(
                "SELECT * FROM GiftDrops WHERE StorefrontItemId = @Id", new { Id = item.Id });

            if (giftDrop == null) return Results.BadRequest("Gift drop data missing.");

            int giftId = await db.QueryFirstOrDefaultAsync<int>(@"
                INSERT INTO ReceivedGifts (ReceiverAccountId, ConsumableItemDesc, AvatarItemDesc, AvatarItemType, FriendlyName, 
                                        EquipmentPrefabName, EquipmentModificationGuid, CurrencyType, Currency, 
                                        GiftContext, GiftRarity, Message, IsConsumed)
                VALUES (@AccId, @Cons, @AvDesc, @AvType, @Name, @Equip, @Guid, @CurType, @Cur, @Ctx, @Rar, @Msg, 0);
                SELECT LAST_INSERT_ID();",
                new
                {
                    AccId = accountId, 
                    Cons = (string)giftDrop.ConsumableItemDesc, 
                    AvDesc = (string)giftDrop.AvatarItemDesc, 
                    AvType = (int)giftDrop.AvatarItemType, 
                    Name = (string)giftDrop.FriendlyName, 
                    Equip = (string)giftDrop.EquipmentPrefabName, 
                    Guid = (string)giftDrop.EquipmentModificationGuid, 
                    CurType = (int)giftDrop.CurrencyType, 
                    Cur = (int)giftDrop.Currency, 
                    Ctx = (int)giftDrop.Context, 
                    Rar = (int)giftDrop.Rarity, 
                    Msg = "A gift for you <3" 
                });
            
            var response = new
            {
                BalanceUpdates = new List<object>
                {
                    new
                    {
                        UpdateResponse = 0,
                        Data = new List<object>
                        {
                            new
                            {
                                Id = giftId,
                                FromPlayerId = (object)null,
                                ConsumableItemDesc = (string)giftDrop.ConsumableItemDesc,
                                ConsumableCount = 1,
                                AvatarItemDesc = (string)giftDrop.AvatarItemDesc,
                                AvatarItemType = (int)giftDrop.AvatarItemType,
                                CurrencyType = (int)giftDrop.CurrencyType,
                                Currency = (int)giftDrop.Currency,
                                Xp = 0,
                                PackageType = 0,
                                Message = "A gift for you <3",
                                EquipmentPrefabName = (string)giftDrop.EquipmentPrefabName,
                                EquipmentModificationGuid = (string)giftDrop.EquipmentModificationGuid,
                                GiftContext = (int)giftDrop.Context,
                                GiftRarity = (int)giftDrop.Rarity,
                                Platform = -1,
                                PlatformsToSpawnOn = -1,
                                BalanceType = (object)null
                            }
                        }
                    }
                },
                Balance = (currentTokens - price),
                CurrencyType = currencyType
            };

            return Results.Content(Newtonsoft.Json.JsonConvert.SerializeObject(response), "application/json");
        });

        app.MapPost("/api/avatar/v2/gifts/consume", async (HttpContext context, DatabaseManager dbManager) =>
        {
            string authHeader = context.Request.Headers["Authorization"];
            string subId = ClientSecurity.GetIdFromToken(authHeader);
            if (!int.TryParse(subId, out int accountId)) return Results.Unauthorized();

            var form = await context.Request.ReadFormAsync();
            if (!int.TryParse(form["Id"], out int giftId)) return Results.BadRequest();

            using var db = dbManager.GetConnection();

            var gift = await db.QueryFirstOrDefaultAsync<dynamic>(
                "SELECT * FROM ReceivedGifts WHERE Id = @Id AND ReceiverAccountId = @AccId",
                new { Id = giftId, AccId = accountId });

            if (gift == null || gift.IsConsumed != 0) return Results.Ok(new { msg = "Already Handled" });

            if (!string.IsNullOrEmpty((string)gift.AvatarItemDesc))
            {
                await db.ExecuteAsync(@"
                    INSERT IGNORE INTO PlayerAvatarItems (AccountId, AvatarItemId)
                    SELECT @AccId, Id FROM AllAvatarItems WHERE AvatarItemDesc = @Desc",
                    new { AccId = accountId, Desc = (string)gift.AvatarItemDesc });
            }

            if (!string.IsNullOrEmpty((string)gift.EquipmentModificationGuid))
            {
                await db.ExecuteAsync(@"
                    INSERT IGNORE INTO PlayerEquipment (AccountId, EquipmentId, Favorited)
                    SELECT @AccId, Id, 0 
                    FROM AllEquipment 
                    WHERE ModificationGuid = @Guid",
                    new { AccId = accountId, Guid = (string)gift.EquipmentModificationGuid });
            }

            if (!string.IsNullOrEmpty((string)gift.ConsumableItemDesc))
            {
                await db.ExecuteAsync(@"
                    INSERT INTO PlayerConsumables (AccountId, ConsumableItemId, Count)
                    SELECT @AccId, Id, 1 FROM AllConsumables WHERE ConsumableItemDesc = @Desc
                    ON DUPLICATE KEY UPDATE Count = Count + 1",
                    new { AccId = accountId, Desc = (string)gift.ConsumableItemDesc });
            }

            if ((int)gift.Currency > 0)
            {
                string columnName = (int)gift.CurrencyType switch
                {
                    1 => "LaserTickets",
                    2 => "Tokens",
                    100 => "IsleGold",
                    101 => "CrescendoSilver",
                    _ => null
                };

                if (columnName != null)
                {
                    await db.ExecuteAsync(
                        $"UPDATE Accounts SET {columnName} = {columnName} + @Amount WHERE Id = @Id",
                        new { Amount = (int)gift.Currency, Id = accountId });
                }
            }

            await db.ExecuteAsync("UPDATE ReceivedGifts SET IsConsumed = 1 WHERE Id = @Id", new { Id = giftId });

            return Results.Ok(new { msg = "Success" });
        });

        //Gifts & Gift generation from game
        app.MapGet("/api/avatar/v2/gifts", async (HttpContext context, DatabaseManager dbManager) =>
        {
            string authHeader = context.Request.Headers["Authorization"];
            string subId = ClientSecurity.GetIdFromToken(authHeader);
            if (!int.TryParse(subId, out int accountId)) return Results.Unauthorized();

            using var db = dbManager.GetConnection();

            var pendingGifts = (await db.QueryAsync<dynamic>(
                "SELECT * FROM ReceivedGifts WHERE ReceiverAccountId = @Id AND IsConsumed = 0", 
                new { Id = accountId })).ToList();

            var response = pendingGifts.Select(g => new {
                Id = (int)g.Id,
                FromPlayerId = (object)g.FromPlayerId,
                ConsumableItemDesc = (string)g.ConsumableItemDesc,
                ConsumableCount = 1,
                AvatarItemDesc = (string)g.AvatarItemDesc,
                AvatarItemType = (int?)g.AvatarItemType,
                CurrencyType = (int?)g.CurrencyType,
                Currency = (int?)g.Currency,
                Xp = 0,
                PackageType = 0,
                Message = (string)g.Message,
                EquipmentPrefabName = (string)g.EquipmentPrefabName,
                EquipmentModificationGuid = (string)g.EquipmentModificationGuid,
                GiftContext = (int?)g.GiftContext,
                GiftRarity = (int?)g.GiftRarity,
                Platform = -1,
                PlatformsToSpawnOn = -1,
                BalanceType = (object)null
            }).ToList();

            string json = Newtonsoft.Json.JsonConvert.SerializeObject(response);
            return Results.Content(json, "application/json");
        });

        app.MapPost("api/avatar/v2/gifts/generate", async (HttpContext context, DatabaseManager dbManager) =>
        {
            try
            {
                string authHeader = context.Request.Headers["Authorization"];
                string subId = ClientSecurity.GetIdFromToken(authHeader);
                if (!int.TryParse(subId, out int accountId)) return Results.Unauthorized();

                var form = await context.Request.ReadFormAsync();
                int.TryParse(form["GiftContext"], out int giftContext);
                string message = form["Message"].ToString() ?? "You earned a reward!";
                int.TryParse(form["Xp"], out int xpAmount);

                using var db = dbManager.GetConnection();
                var random = new Random();
                if (xpAmount > 0)
                {
                    await db.ExecuteAsync("UPDATE PlayerProgression SET XP = XP + @Xp WHERE AccountId = @Id", 
                        new { Xp = xpAmount, Id = accountId });
                }

                string avatarItemDesc = "";
                string friendlyName = "";
                int avatarItemType = 0;
                int currencyType = 2;
                int currency = 0;
                string consumableItemDesc = "";
                int giftRarity = 20;

                // [Quest & Stunt Runner Rewards] Logic for 4000-series (Quests) and 11000-series (Stunt Runner)
                bool isQuestOrStunt = (giftContext >= 4000 && giftContext < 5000) || (giftContext >= 11000 && giftContext < 12000);

                if (isQuestOrStunt)
                {
                    // Find one item from the loot table for this context that the player DOES NOT own yet
                    var possibleReward = await db.QueryFirstOrDefaultAsync<dynamic>(@"
                        SELECT * FROM EarnableRewards 
                        WHERE RewardContext = @Ctx 
                        AND AvatarItemDesc NOT IN (SELECT AvatarItemDesc FROM AllAvatarItems WHERE Id IN (SELECT AvatarItemId FROM PlayerAvatarItems WHERE AccountId = @Id))
                        ORDER BY RANDOM() LIMIT 1", 
                        new { Ctx = giftContext, Id = accountId });

                    if (possibleReward != null)
                    {
                        avatarItemDesc = (string)possibleReward.AvatarItemDesc;
                        friendlyName = (string)possibleReward.FriendlyName;
                        avatarItemType = (int)possibleReward.AvatarItemType;
                        giftRarity = (int)possibleReward.GiftRarity;
                    }
                    else
                    {
 
                        currency = (giftContext % 10 == 3) ? 500 : 250; 
                        message = "Rank Complete! You've earned all rewards for this tier.";
                    }
                }
                else if (giftContext == 9000) 
                {
                    currencyType = 1; 
                    currency = 25;
                    message = "Thanks for playing Laser Tag!";
                }
                else
                {
                    int[] amounts = { 10, 20, 40, 100 };
                    currency = amounts[random.Next(amounts.Length)];
                    message = "Activity Completed";
                }

                var giftId = await db.QuerySingleAsync<int>(@"
                    INSERT INTO ReceivedGifts (
                        ReceiverAccountId, FromPlayerId, Message, AvatarItemDesc, FriendlyName, 
                        ConsumableItemDesc, CurrencyType, Currency, GiftContext, GiftRarity, 
                        IsConsumed
                    )
                    VALUES (
                        @AccId, 1, @Msg, @AvDesc, @Name, 
                        @Cons, @CurType, @Cur, @Ctx, @Rar, 0
                    );
                    SELECT LAST_INSERT_ID();",
                    new {
                        AccId = accountId, Msg = message, AvDesc = avatarItemDesc, Name = friendlyName,
                        Cons = consumableItemDesc, CurType = currencyType, Cur = currency, 
                        Ctx = giftContext, Rar = giftRarity
                    });

                var response = new
                {
                    Id = giftId,
                    FromPlayerId = 1,
                    ConsumableItemDesc = consumableItemDesc,
                    AvatarItemDesc = avatarItemDesc,
                    FriendlyName = friendlyName,
                    AvatarItemType = avatarItemType,
                    EquipmentPrefabName = "",
                    EquipmentModificationGuid = "",
                    CurrencyType = currencyType,
                    Currency = currency,
                    Xp = xpAmount,
                    Level = 0,
                    Platform = -1,
                    PlatformsToSpawnOn = -1,
                    BalanceType = 0,
                    GiftContext = giftContext,
                    GiftRarity = giftRarity,
                    Message = message
                };

                return Results.Content(Newtonsoft.Json.JsonConvert.SerializeObject(response), "application/json");
            }
            catch (Exception ex)
            {
                return Results.Problem(ex.Message);
            }
        });

        app.MapPost("/api/gamerewards/v1/request", async (HttpContext context, DatabaseManager dbManager) =>
        {
            try
            {
                string authHeader = context.Request.Headers["Authorization"];
                string subId = ClientSecurity.GetIdFromToken(authHeader);
                if (!int.TryParse(subId, out int accountId)) return Results.Unauthorized();

                var form = await context.Request.ReadFormAsync();
                
                string contextStr = form["giftContext"].ToString();
                if (string.IsNullOrEmpty(contextStr)) contextStr = form["GiftContext"].ToString();

                int giftContext;
                if (!int.TryParse(contextStr, out giftContext))
                {
                    if (Enum.TryParse<GiftContext>(contextStr, out var contextEnum))
                    {
                        giftContext = (int)contextEnum;
                    }
                }

                string message = form["Message"].ToString() ?? "Activity completed!";
                int.TryParse(form["Xp"], out int xpAmount);

                using var db = dbManager.GetConnection();
                var random = new Random();

                if (xpAmount > 0)
                {
                    await db.ExecuteAsync("UPDATE PlayerProgression SET XP = XP + @Xp WHERE AccountId = @Id", 
                        new { Xp = xpAmount, Id = accountId });
                }

                string avatarItemDesc = "";
                string friendlyName = "";
                int avatarItemType = 0;
                int currencyType = 2; // Tokens
                int currency = 0;
                string consumableItemDesc = "";
                int giftRarity = 20;

                if (giftContext == 9000)
                {
                    currencyType = 1;
                    currency = 25;
                    message = "Thanks for playing Laser Tag!";
                }
                else if (giftContext >= 4000 && giftContext < 5000)
                {
                    var inventoryJson = await db.QueryFirstOrDefaultAsync<string>(
                        "SELECT AvatarItems FROM PlayerItems WHERE AccountId = @Id", new { Id = accountId });
                    
                    var ownedItems = System.Text.Json.JsonSerializer.Deserialize<List<System.Text.Json.JsonElement>>(inventoryJson ?? "[]");
                    var ownedGuids = ownedItems
                        .Select(e => e.TryGetProperty("AvatarItemDesc", out var desc) ? desc.GetString() : null)
                        .Where(g => g != null)
                        .ToList();

                    dynamic possibleReward = null;
                    if (ownedGuids.Any())
                    {
                        possibleReward = await db.QueryFirstOrDefaultAsync<dynamic>(
                            @"SELECT * FROM EarnableRewards 
                            WHERE RewardContext = @Ctx 
                            AND AvatarItemDesc NOT IN @Owned 
                            ORDER BY RANDOM() LIMIT 1", 
                            new { Ctx = giftContext, Owned = ownedGuids });
                    }
                    else
                    {
                        possibleReward = await db.QueryFirstOrDefaultAsync<dynamic>(
                            "SELECT * FROM EarnableRewards WHERE RewardContext = @Ctx ORDER BY RANDOM() LIMIT 1", 
                            new { Ctx = giftContext });
                    }

                    if (possibleReward != null)
                    {
                        avatarItemDesc = possibleReward.AvatarItemDesc;
                        friendlyName = possibleReward.FriendlyName;
                        avatarItemType = (int)possibleReward.AvatarItemType;
                        giftRarity = (int)possibleReward.GiftRarity;
                    }
                    else
                    {
                        currency = (giftContext % 10 == 3) ? 500 : 250;
                        currencyType = 2;
                        message = "Rank Complete! You've earned all rewards for this tier.";
                    }
                }
                else
                {
                    int[] amounts = { 10, 20, 50, 100, 250 };
                    currency = amounts[random.Next(amounts.Length)];
                    friendlyName = $"{currency} Tokens";
                }

                var giftId = await db.QuerySingleAsync<int>(@"
                    INSERT INTO ReceivedGifts (
                        ReceiverAccountId, FromPlayerId, Message, AvatarItemDesc, FriendlyName, 
                        ConsumableItemDesc, AvatarItemType, EquipmentPrefabName, EquipmentModificationGuid,
                        CurrencyType, Currency, GiftContext, GiftRarity, 
                        IsConsumed, CreatedAt
                    )
                    VALUES (
                        @AccId, 1, @Msg, @AvDesc, @Name, 
                        @Cons, @AvType, '', '',
                        @CurType, @Cur, @Ctx, @Rar, 
                        0, @Now
                    );
                    SELECT LAST_INSERT_ID();",
                    new {
                        AccId = accountId, Msg = message, AvDesc = avatarItemDesc, Name = friendlyName,
                        Cons = consumableItemDesc, AvType = avatarItemType, CurType = currencyType, Cur = currency, 
                        Ctx = giftContext, Rar = giftRarity, Now = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss")
                    });

                return Results.Ok(new
                {
                    success = true,
                    giftBox = new
                    {
                        Id = giftId,
                        FromPlayerId = 1,
                        ConsumableItemDesc = consumableItemDesc,
                        AvatarItemDesc = avatarItemDesc,
                        FriendlyName = friendlyName,
                        AvatarItemType = avatarItemType,
                        EquipmentPrefabName = "",
                        EquipmentModificationGuid = "",
                        CurrencyType = currencyType,
                        Currency = currency,
                        Xp = xpAmount,
                        Level = 0,
                        Platform = -1,
                        PlatformsToSpawnOn = -1,
                        BalanceType = 0,
                        GiftContext = giftContext,
                        GiftRarity = giftRarity,
                        Message = message
                    }
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Reward Error: {ex}");
                return Results.Problem(ex.Message);
            }
        });

        //This one is temp ssince I dont know completely what is calling it
        app.MapGet("/api/storefronts/v1/balanceAddType/{ct}/{store}", (int ct, int store) =>
        {
            return Results.Ok(new 
            {
                CurrencyType = ct,
                BalanceAddType = store,
                BaseAward = 2,
                BonusAwardMin = 900,
                BonusAwardMax = 9000,
                RateLimitType = 1,
                IgnorePartialMultiplier = true,
                MaxPartialMultiplier = 1.0,
                RateLimit = 3,
                BalanceInGiftBox = true
            });
        });
    }
}

public enum GiftContext
	{
		None = -1,
		Default,
		First_Activity,
		Game_Drop,
		All_Daily_Challenges_Complete,
		All_Weekly_Challenge_Complete,
		Daily_Challenge_Complete,
		Weekly_Challenge_Complete,
		Unassigned_Equipment = 10,
		Unassigned_Avatar,
		Unassigned_Consumable,
		Reacquisition = 20,
		Membership,
		NUX_TokensAndDressUp = 30,
		NUX_Experiment1,
		NUX_Experiment2,
		NUX_Experiment3,
		NUX_Experiment4,
		NUX_Experiment5,
		LevelUp = 100,
		Purchased_Gift_A = 500,
		Purchased_Gift_B,
		Purchased_Gift_C,
		Purchased_Gift_D,
		Holiday = 1000,
		Contest,
		Promotion,
		SubscribersOnly,
		Deprecated = 1100,
		RecRoyale = 1200,
		Paintball_ClearCut = 2000,
		Paintball_Homestead,
		Paintball_Quarry,
		Paintball_River,
		Paintball_Dam,
		Paintball_DriveIn,
		Discgolf_Propulsion = 3000,
		Discgolf_Lake,
		Discgolf_Mode_CoopCatch = 3500,
		Quest_Goblin_A = 4000,
		Quest_Goblin_B,
		Quest_Goblin_C,
		Quest_Goblin_S,
		Quest_Goblin_Consumable,
		Quest_Cauldron_A = 4010,
		Quest_Cauldron_B,
		Quest_Cauldron_C,
		Quest_Cauldron_S,
		Quest_Cauldron_Consumable,
		Quest_Pirate1_A = 4100,
		Quest_Pirate1_B,
		Quest_Pirate1_C,
		Quest_Pirate1_S,
		Quest_Pirate1_X,
		Quest_Pirate1_Consumable,
		Quest_Dracula1_A = 4200,
		Quest_Dracula1_B,
		Quest_Dracula1_C,
		Quest_Dracula1_S,
		Quest_Dracula1_X,
		Quest_Dracula1_Consumable,
		Quest_Dracula1_SS,
		Quest_SciFi_A = 4500,
		Quest_SciFi_B,
		Quest_SciFi_C,
		Quest_SciFi_S,
		Quest_Scifi_Consumable,
		Charades = 5000,
		Soccer = 6000,
		Paddleball = 7000,
		Dodgeball = 8000,
		Lasertag = 9000,
		Bowling = 10000,
		StuntRunner_TheMainEvent_A = 11000,
		StuntRunner_TheMainEvent_B,
		StuntRunner_TheMainEvent_C,
		StuntRunner_TheMainEvent_D,
		StuntRunner_TheMainEvent_S,
		StuntRunner_TheMainEvent_X,
		StuntRunner_TheMainEvent_Consumable,
		StuntRunner_TheMainEvent_SS,
		Store_LaserTag = 100000,
		Store_RecCenter = 100010,
		Consumable = 110000,
		Token = 110100,
		Punchcard_Challenge_Complete = 110200,
		All_Punchcard_Challenges_Complete,
		Commerce_Purchase = 200000
	}