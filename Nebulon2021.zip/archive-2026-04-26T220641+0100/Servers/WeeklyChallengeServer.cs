using Dapper;
using System.Text.Json;
using System.Net.WebSockets;

public static class WeeklyChallengeServer
{
    public static void MapWeeklyChallengeServerEndpoints(this IEndpointRouteBuilder app)
    {
    	app.MapGet("/api/challenge/v2/getCurrent", async (HttpContext context, DatabaseManager dbManager) =>
        {
            try
            {
                using var db = dbManager.GetConnection();
                DateTime now = DateTime.UtcNow;

                string authHeader = context.Request.Headers["Authorization"];
                string subId = ClientSecurity.GetIdFromToken(authHeader);
                if (!long.TryParse(subId, out long accountId)) accountId = 1;

                var schedule = await db.QueryFirstOrDefaultAsync<dynamic>(
                    @"SELECT ws.*, gd.* FROM WeeklySchedules ws
                      JOIN GiftDrops gd ON ws.GiftDropId = gd.GiftDropId
                      WHERE @Now BETWEEN StartAt AND EndAt LIMIT 1", 
                    new { Now = now });

                if (schedule == null) return Results.Ok(new { });

                int scheduleId = Convert.ToInt32(schedule.Id);

                var rawChallenges = await db.QueryAsync<dynamic>(
                    @"SELECT c.Id, c.Name, c.Type, c.RequiredRoomGuid, c.Goal, c.Description, c.Tooltip,
                             p.IsCompleted, p.CurrentValue
                      FROM WeeklyChallengeConfigs c
                      LEFT JOIN PlayerWeeklyProgress p ON c.Id = p.ChallengeId 
                                                      AND p.PlayerId = @Pid 
                                                      AND p.ScheduleId = @Sid
                      WHERE c.ScheduleId = @Sid",
                    new { Pid = accountId, Sid = scheduleId });

                var challengeItems = rawChallenges.Select(c => {
                    int type = Convert.ToInt32(c.Type);
                    string guid = c.RequiredRoomGuid?.ToString() ?? "";
                    int goal = Convert.ToInt32(c.Goal);
                    int progress = c.CurrentValue != null ? Convert.ToInt32(c.CurrentValue) : 0;

                    bool isDone = false;
                    if (c.IsCompleted != null)
                    {
                        isDone = Convert.ToInt64(c.IsCompleted) == 1;
                    }

                   string generatedConfig = type switch
                    {
                        1 => ChallengeTemplates.GetQuestWinConfig(guid),
                        2 => ChallengeTemplates.GetQuestEntryConfig(guid),
                        4 => ChallengeTemplates.GetGameWinConfig(goal, guid),
                        _ => ChallengeTemplates.GetGameConfig(goal, guid) 
                    };

                    if (generatedConfig.Contains("\"v\":0,\"s\":0"))
                    {
                        string progressSnippet = $"\"v\":{progress},\"s\":{(isDone ? 1 : 0)}";
                        generatedConfig = generatedConfig.Replace("\"v\":0,\"s\":0", progressSnippet);
                    }

                    if (isDone)
                    {
                        generatedConfig = generatedConfig.Replace("{\"ct\":", "{\"c\":true,\"ct\":");
                        if (generatedConfig.Contains("\"ctc\":["))
                        {
                            generatedConfig = generatedConfig.Replace("\"ctc\":[{", "\"ctc\":[{\"c\":true,");
                        }
                    }

                    return new ChallengeItem
                    {
                        ChallengeId = Convert.ToInt32(c.Id),
                        Name = c.Name?.ToString() ?? "Challenge",
                        Description = c.Description?.ToString() ?? "",
                        Tooltip = c.Tooltip?.ToString() ?? "",
                        Config = generatedConfig,
                        Complete = isDone
                    };
                }).ToList();

                // Safe Date Parsing
                DateTime startAt = Convert.ToDateTime(schedule.StartAt);
                DateTime endAt = Convert.ToDateTime(schedule.EndAt);

                return Results.Ok(new WeeklyResponse
                {
                    ChallengeMapId = scheduleId,
                    ChallengeThemeString = schedule.ChallengeTheme?.ToString() ?? "Weekly",
                    StartAt = startAt.ToString("s"),
                    EndAt = endAt.ToString("s"),
                    Challenges = challengeItems,
                    Gift = new WeeklyGift
                    {
                        GiftDropId = Convert.ToInt32(schedule.GiftDropId ?? 0),
                        GiftContext = 4, 
                        GiftRarity = Convert.ToInt32(schedule.GiftRarity ?? 0),
                        AvatarItemDesc = schedule.AvatarItemDesc?.ToString() ?? "",
                        AvatarItemType = (int?)schedule.AvatarItemType,
                        EquipmentPrefabName = schedule.EquipmentPrefabName?.ToString(),
                        EquipmentModificationGuid = schedule.EquipmentModificationGuid?.ToString(),
                        ConsumableItemDesc = schedule.ConsumableItemDesc?.ToString(),
                        Currency = Convert.ToInt32(schedule.Currency ?? 0),
                        CurrencyType = Convert.ToInt32(schedule.CurrencyType ?? 0),
                        Xp = Convert.ToInt32(schedule.Xp ?? 0),
                        Level = Convert.ToInt32(schedule.Level ?? 0)
                    },
                    CompletedRequired = challengeItems.Count(c => c.Complete) >= 3 
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Weekly Error] {ex}");
                return Results.Problem("Error fetching weeklies");
            }
        });
        
        app.MapPost("/api/storefronts/v1/objectives", async (HttpContext context, DatabaseManager dbManager) =>
        {
            try 
            {
                string authHeader = context.Request.Headers["Authorization"];
                string subId = ClientSecurity.GetIdFromToken(authHeader);
                if (!long.TryParse(subId, out long accountId)) accountId = 1;

                using var db = dbManager.GetConnection();

                // 1. Get current active weekly
                var schedule = await db.QueryFirstOrDefaultAsync<dynamic>(
                    @"SELECT ws.Id, ws.GiftDropId, gd.* FROM WeeklySchedules ws
                    JOIN GiftDrops gd ON ws.GiftDropId = gd.GiftDropId
                    WHERE NOW() BETWEEN StartAt AND EndAt LIMIT 1");

                if (schedule == null) 
                    return Results.Ok(new { objectiveGroupStatuses = new[] { new { group = 1, isCompleted = false } } });

                int scheduleId = Convert.ToInt32(schedule.Id);

                // 2. Count completed challenges
                int completedCount = await db.ExecuteScalarAsync<int>(
                    "SELECT COUNT(*) FROM PlayerWeeklyProgress WHERE PlayerId = @Pid AND ScheduleId = @Sid AND IsCompleted = 1",
                    new { Pid = accountId, Sid = scheduleId });

                // 3. Check if they already have the weekly reward item
                bool hasGrandPrize = await db.ExecuteScalarAsync<bool>(
                    "SELECT COUNT(*) FROM ReceivedGifts WHERE ReceiverAccountId = @Pid AND Message = 'Weekly Reward!' LIMIT 1",
                    new { Pid = accountId });

                // 4. Handle Rewards
                if (completedCount >= 3 && !hasGrandPrize)
                {
                    // Give Grand Prize (Weekly Skin)
                    await db.ExecuteAsync(@"
                        INSERT INTO ReceivedGifts (ReceiverAccountId, ConsumableItemDesc, AvatarItemDesc, AvatarItemType, FriendlyName, 
                                                EquipmentPrefabName, EquipmentModificationGuid, CurrencyType, Currency, 
                                                GiftContext, GiftRarity, Message, IsConsumed, CreatedAt)
                        VALUES (@AccId, @Cons, @AvDesc, @AvType, @Name, @Equip, @Guid, @CurType, @Cur, 4, @Rar, 'Weekly Reward!', 0, NOW());",
                        new {
                            AccId = accountId, 
                            Cons = (string)schedule.ConsumableItemDesc, 
                            AvDesc = (string)schedule.AvatarItemDesc, 
                            AvType = (int?)schedule.AvatarItemType, 
                            Name = (string)schedule.FriendlyName ?? "Weekly Item", 
                            Equip = (string)schedule.EquipmentPrefabName, 
                            Guid = (string)schedule.EquipmentModificationGuid, 
                            CurType = Convert.ToInt32(schedule.CurrencyType ?? 0), 
                            Cur = Convert.ToInt32(schedule.Currency ?? 0), 
                            Rar = Convert.ToInt32(schedule.GiftRarity ?? 0)
                        });
                    Console.WriteLine($"[Weekly] Player {accountId} earned the Grand Prize!");
                }
                else if (completedCount < 3)
                {
                    // Give standard progress reward (Tokens)
                    await db.ExecuteAsync(@"
                        INSERT INTO ReceivedGifts (ReceiverAccountId, CurrencyType, Currency, GiftContext, Message, IsConsumed, CreatedAt)
                        VALUES (@AccId, 2, 50, 4, 'Progress Reward!', 0, NOW());", 
                        new { AccId = accountId });
                    Console.WriteLine($"[Weekly] Player {accountId} earned a Progress Reward.");
                }

                // Return status to the watch
                return Results.Ok(new { objectiveGroupStatuses = new[] { new { group = 1, isCompleted = (completedCount >= 3) } } });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Objectives Error] {ex}");
                return Results.Problem("Failed to process objectives.");
            }
        });
        
        app.MapPost("/api/challenge/v2/updateProgress", async (HttpContext context, DatabaseManager dbManager) =>
        {
            try
            {
                using var db = dbManager.GetConnection();

                string authHeader = context.Request.Headers["Authorization"];
                string subId = ClientSecurity.GetIdFromToken(authHeader);
                if (!long.TryParse(subId, out long accountId)) accountId = 1;

                var request = await context.Request.ReadFromJsonAsync<UpdateProgressRequest>();
                if (request == null) return Results.BadRequest();

                int scheduleId = int.Parse(request.ChallengeMapId);
                int challengeId = int.Parse(request.ChallengeId);
                // Note: Rec Room sends "True" as a string, your existing logic handles this well
                bool isDone = request.Complete.Equals("True", StringComparison.OrdinalIgnoreCase);

                Console.WriteLine($"[Weekly Progress] Player {accountId} updated Challenge {challengeId}. Complete: {isDone}");

                await db.ExecuteAsync(@"
                    INSERT INTO PlayerWeeklyProgress (PlayerId, ScheduleId, ChallengeId, CurrentValue, IsCompleted)
                    VALUES (@Pid, @Sid, @Cid, 1, @Done)
                    ON DUPLICATE KEY UPDATE
                    CurrentValue = CurrentValue + 1,
                    IsCompleted = CASE WHEN @Done = 1 THEN 1 ELSE IsCompleted END", 
                    new { 
                        Pid = accountId, 
                        Sid = scheduleId, 
                        Cid = challengeId, 
                        Done = isDone ? 1 : 0 
                    });

                return Results.Ok(new { }); 
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Progress Error] {ex.Message}");
                return Results.Problem(ex.Message);
            }
        });

        app.MapPost("/api/objectives/v1/cleargroup", () => Results.Ok(new { }));
        app.MapPost("/api/objectives/v1/updateobjective", () => Results.Ok(new { }));
        
    }
    
}

public class WeeklyResponse
{
    public int ChallengeMapId { get; set; }
    public string ChallengeThemeString { get; set; }
    public List<ChallengeItem> Challenges { get; set; }
    public WeeklyGift Gift { get; set; }
    public string FallbackGiftName { get; set; } = "4-Star Box";
    public string StartAt { get; set; }
    public string EndAt { get; set; }
    public string ServerTime { get; set; } = DateTime.UtcNow.ToString("o");
    public bool CompletedRequired { get; set; } = false; 
}

public class ChallengeItem
{
    public int ChallengeId { get; set; }
    public string Name { get; set; }
    public string Config { get; set; }
    public string Description { get; set; }
    public string Tooltip { get; set; }
    public bool Complete { get; set; } = false;
}

public class WeeklyGift
{
    public int GiftDropId { get; set; }
    public string AvatarItemDesc { get; set; } = "";
    public int? AvatarItemType { get; set; }
    public int Currency { get; set; } = 0;
    public int CurrencyType { get; set; } = 0;
    public int Xp { get; set; } = 0;
    public int Level { get; set; } = 0;
    public string EquipmentPrefabName { get; set; }
    public string EquipmentModificationGuid { get; set; }
    public string ConsumableItemDesc { get; set; }
    public int GiftContext { get; set; }
    public int GiftRarity { get; set; }
}

public enum ChallengeType
{
    None = 0,
    QuestWin = 1,
    QuestParticipation = 2,
    GameParticipation = 3,
    GameWin = 4,
    Hitstreak = 5,
    Social = 6 // Not really gonna be used I think
}

public static class ChallengeTemplates
{
    public static string GetQuestWinConfig(string roomGuid)
    {
        return $"{{\"ct\":0,\"ipc\":false,\"wc\":[{{\"ct\":6,\"vs\":[2]}},{{\"ct\":9,\"vs\":[true],\"v\":\"won\"}},{{\"ct\":7,\"vs\":[{{\"l\":\"{roomGuid}\"}}]}}]}}";
    }
    public static string GetQuestEntryConfig(string roomGuid)
    {
        return $"{{\"ct\":0,\"ipc\":false,\"wc\":[{{\"ct\":6,\"vs\":[2]}},{{\"ct\":7,\"vs\":[{{\"l\":\"{roomGuid}\"}}]}}]}}";
    }

    public static string GetGameWinConfig(int count, string roomGuid)
    {
        //return $"{{\"ct\":1,\"t\":{count},\"ctc\":[{{\"ct\":0,\"wc\":[{{\"ct\":9,\"v\":\"won\"}},{{\"ct\":7,\"vs\":[{{\"l\":\"{roomGuid}\"}}]}}]}}]}}";
        return $"{{\"v\":0,\"s\":0,\"ct\":1,\"t\":{count},\"ctc\":[{{\"ct\":0,\"wc\":[{{\"ct\":9,\"v\":\"won\"}},{{\"ct\":7,\"vs\":[{{\"l\":\"{roomGuid}\"}}]}}]}}]}}";
    }
    public static string GetGameConfig(int count, string roomGuid)
    {
       // return $"{{\"ct\":1,\"ipc\":false,\"ctc\":[{{\"ct\":0,\"ipc\":false,\"wc\":[{{\"ct\":6,\"vs\":[2]}},{{\"ct\":7,\"vs\":[{{\"l\":\"{roomGuid}\"}}]}}]}}],\"t\":{count}}}";
        return $"{{\"v\":0,\"s\":0,\"ct\":1,\"ipc\":false,\"ctc\":[{{\"ct\":0,\"ipc\":false,\"wc\":[{{\"ct\":6,\"vs\":[2]}},{{\"ct\":7,\"vs\":[{{\"l\":\"{roomGuid}\"}}]}}]}}],\"t\":{count}}}";
        
    }


    /* ----Room Guids-----
    Dorm room - 76d98498-60a1-430c-ab76-b54a29b7a163
    Rec Center - cbad71af-0831-44d8-b8ef-69edafa841f6
    Lagacy Charades - 4078dfed-24bb-4db7-863f-578ba48d726b
    Lake (Disc Golf) - f6f7256c-e438-4299-b99e-d20bef8cf7e0
    Propulsion (Disc Golf) - d9378c9f-80bc-46fb-ad1e-1bed8a674f55
    Dodgeball - 3d474b26-26f7-45e9-9a36-9b02847d5e6f
    Lounge - a067557f-ca32-43e6-b6e5-daaec60b4f5a
    Paddleball - d89f74fa-d51e-477a-a425-025a891dd499
    River (Paintball) - e122fe98-e7db-49e8-a1b1-105424b6e1f0
    Headstead (Paintball) - a785267d-c579-42ea-be43-fec1992d1ca7
    Quarry (Paintball) - ff4c6427-7079-4f59-b22a-69b089420827
    Clearcut (Paintball) - 380d18b5-de9c-49f3-80f7-f4a95c1de161
    Spillway (Paintball) - 58763055-2dfb-4814-80b8-16fac5c85709
    Golden Trophy - 91e16e35-f48f-4700-ab8a-a1b79e50e51b
    Orientation - c79709d8-a31b-48aa-9eb8-cc31ba9505e8
    Jumbotron - acc06e66-c2d0-4361-b0cd-46246a4c455c
    Crimson - 949fa41f-4347-45c0-b7ac-489129174045
    Crescendo - 49cb8993-a956-43e2-86f4-1318f279b22a
    Isle - 7e01cfe0-820a-406f-b1b3-0a5bf575235c
    Soccer - 6d5eea4b-f069-4ed0-9916-0e2f07df0d03
    Park - 0a864c86-5a71-4e18-8041-8124e4dc9d98
    Warehouse (laser Tag?) - 239e676c-f12f-489f-bf3a-d4c383d692c3
    CyberJunkCity (Laser Tag) - 9d6456ce-6264-48b4-808d-2d96b3d91038
    Bowling - ae929543-9a07-41d5-8ee9-dbbee8c36800
    Stuntrunner - b7281665-a715-4051-826b-8e08e69c6172
    */
}

public class UpdateProgressRequest
{
    public string ChallengeMapId { get; set; }
    public string ChallengeId { get; set; }
    public string Complete { get; set; }
}