﻿using Carbon.Backend.Databasing;
using Carbon.Json;
using Carbon.Json.Notifications;
using Carbon.Utilities;
using JWT;
using JWT.Algorithms;
using JWT.Builder;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Linq;
using Openlabs.Mgcxm.Common;
using Openlabs.Mgcxm.Internal;
using OpenlabsSDKV1.Core;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.AccessTokens
{
    internal delegate void OnOneTimeTokenConsumed(OneTimeToken consumedToken);
    internal delegate void OnOneTimeTokenExpired(OneTimeToken expiredToken);

    internal sealed class OneTimeToken
    {
        static Dictionary<string, OneTimeToken> _oneTimeTokenRegister
            = new Dictionary<string, OneTimeToken>();

        private OneTimeToken(Duration expiryTime, string source, AccessToken accessToken, OnOneTimeTokenConsumed onConsumed, OnOneTimeTokenExpired onExpired)
        {
            _parent = accessToken;
            _source = source;
            _tokenString = UUID.CreateUnique().UuidValue;
            _expiresAt = DateTime.Now + expiryTime.TimeSpan;

            _onConsumed = onConsumed;
            _onExpired = onExpired;

            accessToken.AddOTT(this);
            Task.Run(async () => await CheckTokenStatus());
        }

        private OneTimeToken(Duration expiryTime, string source, AccessToken accessToken, string str, OnOneTimeTokenConsumed onConsumed, OnOneTimeTokenExpired onExpired)
        {
            var uuid = str.Replace("-", "");

            _parent = accessToken;
            _source = source;
            _tokenString = UUID.Create(uuid).GuidValue.ToString();
            _expiresAt = DateTime.Now + expiryTime.TimeSpan;

            _onConsumed = onConsumed;
            _onExpired = onExpired;

            accessToken.AddOTT(this);
            Task.Run(async () => await CheckTokenStatus());
        }

        private async Task CheckTokenStatus()
        {
            for (; ; )
            {
                if (!Consumed && Expired)
                {
                    InvokeExpired();
                    break;
                }
                else if (!Expired && Consumed)
                {
                    InvokeConsume();
                    break;
                }

                await Task.Delay(25);
            }
        }

        public static string Create(Duration expiryTime, string source, AccessToken parent, OnOneTimeTokenConsumed onConsumed, OnOneTimeTokenExpired onExpired)
        {
            var oneTimeToken = new OneTimeToken(expiryTime, source, parent, onConsumed, onExpired);
            _oneTimeTokenRegister.Add(oneTimeToken.TokenString, oneTimeToken);

            return oneTimeToken.TokenString;
        }

        public static string CreateForced(Duration expiryTime, string source, AccessToken parent, string str, OnOneTimeTokenConsumed onConsumed, OnOneTimeTokenExpired onExpired)
        {
            var oneTimeToken = new OneTimeToken(expiryTime, source, parent, str, onConsumed, onExpired);
            _oneTimeTokenRegister.Add(oneTimeToken.TokenString, oneTimeToken);

            return oneTimeToken.TokenString;
        }

        public static bool Consume(string tokenStr, out OneTimeToken oneTimeToken)
        {
            oneTimeToken = null; // init our token
            if (!_oneTimeTokenRegister.ContainsKey(tokenStr)) return false;

            var token = _oneTimeTokenRegister[tokenStr];
            if (!token.Expired) return false;

            oneTimeToken = token;
            token.Consume();

            return true;
        }

        private void InvokeConsume()
        {
            if (Invalidated) return;
            if (_onConsumed == null)
                return;

            _onConsumed(this);
        }

        private void InvokeExpired()
        {
            if (Invalidated) return;
            if (_onExpired == null)
                return;

            _onExpired(this);
        }

        private void Consume()
        {
            if (Invalidated) return;

            Consumed = true;
            ConsumedAt = DateTime.Now;
        }

        public void Invalidate()
        {
            Invalidated = true;
            _expiresAt = DateTime.Now;
        }

        public AccessToken ParentToken => _parent;
        public string Source => _source;

        public int ExpiresInSeconds => !Invalidated ? (int)(DateTime.Now - _expiresAt).TotalSeconds : 0;
        public bool Expired => DateTime.Now > _expiresAt;

        public string TokenString => _tokenString;

        public bool Consumed { get; private set; }
        public DateTime ConsumedAt { get; private set; }
        public bool Invalidated { get; private set; }

        private AccessToken _parent;
        private string _source;
        private DateTime _expiresAt;
        private string _tokenString;
        private OnOneTimeTokenConsumed _onConsumed;
        private OnOneTimeTokenExpired _onExpired;
    }

    internal sealed class AccessToken
    {
        public static readonly AccessToken Privledged = CreateFake(1, "999");

        static List<AccessToken> _allAccessTokens
             = new List<AccessToken>();

        private AccessToken() { }
        private AccessToken(string token) : this()
        {
            _id = Openlabs.Mgcxm.Common.Random.Range(1000, 1000000);
            _secToken = new JwtSecurityToken(token);
            _token = token;

            _playerId = long.Parse(GetClaim("sub"));
            _platformId = GetClaim("pid");
            if (!VerifyHashes(_secToken.Audiences.First(), _secToken.Subject, GetClaim("s1"), GetClaim("s2"), GetClaim("jti")))
                throw new Exception("Cannot use an invalid access token.");
        }

        private AccessToken(Profile profile) : this()
        {
            _id = Openlabs.Mgcxm.Common.Random.Range(1000, 1000000);
            _playerId = profile.Id;
            _platformId = profile.PlatformId.Id;

            const string sec = "7f0c7491fa986128f29dca92236d0f1b85a44ea06125d180748642ce7b6a9fe12616335b7a46ce5eeb9c161eaa9f040c29ec914f8fac823fea813353f70175dc";
            var securityKey = new SymmetricSecurityKey(Encoding.Default.GetBytes(sec));

            var signingCredentials = new SigningCredentials(
                securityKey,
                SecurityAlgorithms.HmacSha512);

            var notBefore = DateTime.Now.AddMinutes(-1);
            var expiresIn = DateTime.Now.AddDays(1);

            var aud = "rrclient";
            var sub = Profile.Id.ToString();
            CreateHashes(aud, sub, out var jti, out var s1, out var s2);

            var tokenHandler = new JwtSecurityTokenHandler();
            JwtSecurityToken securityToken = new JwtSecurityToken("openlabservercarbon", aud, new List<Claim>
            {
                new Claim("jti", jti),
                new Claim("s1", s1),
                new Claim("s2", s2),

                new Claim("sub", sub),
                new Claim("pid", profile.PlatformId.Id)
            }, notBefore, expiresIn, signingCredentials);

            _token = tokenHandler.WriteToken(securityToken);
            Constants.AccessTokenSink.Warning("Created access token: " + _token);
        }

        private void CreateHashes(string audience, string subject, out string jti, out string s1, out string s2)
        {
            if (_fakeToken)
            {
                jti = "None";
                s1 = "None";
                s2 = "None";

                Constants.AccessTokenSink.Warning("Tried to CreateHashes(string, string, string&, string&, string&) on a fake token.");
                return;
            }

            // Constants.AccessTokenSink.Warning("Creating hashes aud = " + audience + ", subject = " + subject);
            jti = Hashing.SHA256(audience + subject);
            s1 = Hashing.SHA384(jti + audience);
            s2 = Hashing.SHA384(jti + subject);
        }

        private bool VerifyHashes(string audience, string subject, string s1, string s2, string jti)
        {
            if (_fakeToken)
            {
                Constants.AccessTokenSink.Warning("Tried to VerifyHashes(string, string, string, string, string) on a fake token.");
                return false;
            }

            const string JTI_ERR = "JTI is incorrect! Got '{0}' but expected '{1}'. Subject = {2}, Audience = {3}";

            CreateHashes(audience, subject, out var eJti, out var eS1, out var eS2);
            bool isJtiExpected = eJti == jti;

            if (!isJtiExpected)
            {
                Constants.AccessTokenSink.Error(string.Format(JTI_ERR, jti, eJti, subject, audience));
                return false;
            }

            return true;
        }

        public string GetClaim(string key)
        {
            if (_fakeToken)
            {
                Constants.AccessTokenSink.Warning("Tried to GetClaim(string) on a fake token.");
                return null;
            }

            return _secToken.Claims.First(x => x.Type == key).Value; 
        }

        public void Invalidate()
        {
            if (_fakeToken)
            {
                Constants.AccessTokenSink.Warning("Tried to Invalidate() on a fake token.");
                return;
            }

            _allAccessTokens.Remove(this);
            Invalidated = true;

            foreach (var ott in _oneTimeTokens)
                ott.Invalidate();
        }

        public void AddOTT(OneTimeToken token)
        {
            if (_fakeToken)
            {
                Constants.AccessTokenSink.Warning("Tried to AddOTT() on a fake token.");
                return;
            }

            Constants.AccessTokenSink.Warning("Adding one time token! " + _id.ToString());
            _oneTimeTokens.Add(token);
        }

        public OneTimeToken GetOTT(string source)
        {
            if (_fakeToken)
            {
                Constants.AccessTokenSink.Warning("Tried to GetOTT(string) on a fake token.");
                return null;
            }

            Constants.AccessTokenSink.Warning(_id.ToString());
            foreach (var oneTimeToken in _oneTimeTokens)
            {
                Constants.AccessTokenSink.Warning(string.Format("Token found. Invalidated = {0}, Source = {1}", oneTimeToken.Invalidated.ToString(), oneTimeToken.Source));
                if (!oneTimeToken.Invalidated && oneTimeToken.Source == source)
                {
                    return oneTimeToken;
                }
            }
            return null;
        }

        public static AccessToken CreateFake(long playerId, string platformId)
        {
            var id = Openlabs.Mgcxm.Common.Random.Range(1000, 1000000);
            // Constants.AccessTokenSink.Warning("Creating fake token {0} for ({1}, {2})", id, playerId, playerId);
            return new AccessToken()
            {
                _fakeToken = true,
                _id = id,
                _platformId = platformId,
                _token = "None (Fake Token)",
                _secToken = null,
                _oneTimeTokens = null
            };
        }

        public static AccessToken GetCached(string token)
        {
            if (_allAccessTokens.Any(x => x.EncodedToken == token))
                return _allAccessTokens.Find(x => x.EncodedToken == token)!;

            var accessToken = CreateFromString(token);
            _allAccessTokens.Add(accessToken);

            return accessToken;
        }

        public static AccessToken GetFromPlayerId(long playerId) => _allAccessTokens.Find(x => x.PlayerId == playerId)!;
        public static AccessToken GetFromPlatformId(string platformId) => _allAccessTokens.Find(x => x.PlatformId == platformId)!;

        public static AccessToken CreateFromProfile(Profile profile) => new AccessToken(profile);
        public static AccessToken CreateFromPlatformId(string platformId) => new AccessToken(Singleton<Login>.Instance.GetCachedLogins(PlatformType.STEAM, platformId)[0]);
        public static AccessToken CreateFromString(string token) => new AccessToken(token);

        public int TokenId => _id;
        public Profile Profile => Database.ProfileDatabase.ReadGeneric<List<Profile>>(_platformId).Find(x => x.Id == _playerId)!;

        public long PlayerId => _playerId;
        public string PlatformId => _platformId;

        public string Username => Profile.Username;
        public string DisplayName => Profile.DisplayName;

        public int Level => Profile.Level;
        public int XP => Profile.XP;

        public bool Developer => Profile.Developer;

        public int ExpiresInSeconds => !Invalidated ? (int)(DateTime.Now - _secToken.ValidTo).TotalSeconds : 0;
        public bool Expired => DateTime.Now > _secToken.ValidTo;

        public string EncodedToken => _token;
        public bool Invalidated { get; private set; }

        private bool _fakeToken;
        private int _id;
        private long _playerId;
        private string _platformId;
        private string _token;
        private JwtSecurityToken _secToken;
        private List<OneTimeToken> _oneTimeTokens = new List<OneTimeToken>();
    }
}
