﻿using Carbon.Backend.AccessTokens;
using Openlabs.Mgcxm.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.Attributes
{
    internal class BackendMethodAttribute : Attribute
    {
        public static void Initialize()
        {
            var assembly = Assembly.GetAssembly(typeof(BackendMethodAttribute));
            foreach (var type in assembly.GetTypes())
                foreach (var method in type.GetMethods())
                {
                    BackendMethodAttribute attr = null;
                    if ((attr = method.GetCustomAttribute<BackendMethodAttribute>()!) != null)
                    {
                        var parameters = method.GetParameters();
                        if (attr.IsAuthorized && (parameters == null || parameters.Length == 0 || (parameters.Length > 0 && parameters[0].ParameterType.GUID != typeof(AccessToken).GUID)))
                        {
                            Constants.InitializationSink.Warning("The method '{0}.{1}' is an authorized backend method\n\t\t\t\t\t\tThis method does not have an AccessToken type as the first parameter. Is the BackendMethodAttribute misconfigured?",
                                type.GetSafeName(), method.Name);
                        }
                    }
                }
        }

        // does this require authentication
        public bool IsAuthorized { get; set; } = false;
        public bool IsDeveloper { get; set; } = false;
    }
}
