﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Databasing;
using Carbon.Backend.Interfaces;
using Carbon.Json;
using Carbon.Json.Notifications;
using Carbon.Utilities;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend
{
    internal class Avatars : IBackendProvider, IAvatarsBackend
    {
        public IPromise Initialize() => new Promise(action =>
        {
            Singleton.Allocate(this);
            action.Resolve();
        });

        public IPromise Cleanup() => new Promise(action =>
        {
            Singleton.Free<Avatars>();
            action.Resolve();
        });

        public IPromise<Avatar> GetCurrentAvatar(AccessToken accessToken) => new Promise<Avatar>(action =>
        {
            if (!Database.AvatarDatabase.Exists(accessToken.PlatformId))
            {
                var initializedAvatar = new Avatar
                {
                    OutfitSelections = "",
                    FaceFeatures = "",
                    HairColor = "",
                    SkinColor = ""
                };
                Database.AvatarDatabase.WriteGeneric(accessToken.PlatformId, initializedAvatar);

                action.Resolve(initializedAvatar);
            }
            else
                action.Resolve(Database.AvatarDatabase.ReadGeneric<Avatar>(accessToken.PlatformId));
        });

        public IPromise SetCurrentAvatar(AccessToken accessToken, Avatar avatar) => new Promise(action =>
        {
            Database.AvatarDatabase.WriteGeneric(accessToken.PlatformId, avatar);
            action.Resolve();
        });

        public IPromise<List<SavedOutfit>> GetSavedOutfits(AccessToken accessToken) => new Promise<List<SavedOutfit>>(action =>
        {
            if (!Database.SavedOutfitsDatabase.Exists(accessToken.PlatformId))
            {
                var initializedOutfits = new List<SavedOutfit>();
                Database.SavedOutfitsDatabase.WriteGeneric(accessToken.PlatformId, initializedOutfits);

                action.Resolve(initializedOutfits);
            }
            else
                action.Resolve(Database.SavedOutfitsDatabase.ReadGeneric<List<SavedOutfit>>(accessToken.PlatformId));
        });

        public IPromise<List<UnlockedAvatarItem>> GetItemWardrobe(AccessToken accessToken) => new Promise<List<UnlockedAvatarItem>>(action =>
        {
            if (!Database.WardrobeDatabase.Exists(accessToken.PlatformId))
            {
                var initializedItems = new List<UnlockedAvatarItem>();
                Database.WardrobeDatabase.WriteGeneric(accessToken.PlatformId, initializedItems);

                action.Resolve(initializedItems);
            }
            else
                action.Resolve(Database.WardrobeDatabase.ReadGeneric<List<UnlockedAvatarItem>>(accessToken.PlatformId));
        });

        public void NonBackend_AddAvatarItem(AccessToken accessToken, UnlockedAvatarItem avatarItem)
        {
            GetItemWardrobe(accessToken)
                .Then(items =>
                {
                    items.Add(avatarItem);
                    Database.WardrobeDatabase.WriteGeneric(accessToken.PlatformId, items);
                });
        }

        public string FriendlyName => "Avatars Backend";
    }
}
