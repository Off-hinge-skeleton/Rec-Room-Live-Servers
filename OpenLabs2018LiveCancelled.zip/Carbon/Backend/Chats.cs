﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Databasing;
using Carbon.Backend.Interfaces;

using Carbon.Json;
using Carbon.Json;
using Carbon.Json.Chats;
using Carbon.Json.Notifications;
using Carbon.Servers;
using Carbon.Utilities;

using OpenlabsSDKV1.Core.Async;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend
{
    internal class Chats : IBackendProvider, IChatsBackend
    {
        public IPromise Initialize() => new Promise(action =>
        {
            Singleton.Allocate(this);
            action.Resolve();
        });

        public IPromise Cleanup() => new Promise(action =>
        {
            Singleton.Free<Chats>();
            action.Resolve();
        });

        public IPromise<List<ChatThread>> GetMyChats(AccessToken accessToken, int take = 50) => new Promise<List<ChatThread>>(action =>
        {
            action.Resolve(NonBackend_GetChats(accessToken).Take(take).ToList());
        });

        public ChatThread NonBackend_CreateThread(AccessToken accessToken, List<int> playerIds, out long threadId)
        {
            threadId = Openlabs.Mgcxm.Common.Random.Range(10000, 100000000);
            var chatThread = new ChatThread
            {
                ChatThreadId = threadId,
                LastReadMessageId = 0,
                PlayerIds = playerIds,
                Messages = new List<ChatMessage>()
            };

            Database.ChatsDatabase.WriteGeneric(threadId.ToString(), chatThread);
            foreach (var playerId in playerIds)
            {
                var connectionNode = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(playerId);
                connectionNode.Handler.SendNotificationBulk(new PushNotificationDto<ChatThread>
                {
                    // no thread notification id?
                    Id = PushNotificationId.ChatMessageReceived,
                    Msg = null
                });
            }
            return chatThread;
        }

        public void NonBackend_DeleteThread(AccessToken accessToken, long threadId)
        {
            if (Database.ChatsDatabase.Exists(threadId.ToString()))
                Database.ChatsDatabase.Delete(threadId.ToString());
        }

        public List<ChatThread> NonBackend_GetChats(AccessToken accessToken)
        {
            List<ChatThread> chatThreads = new List<ChatThread>();
            foreach (var chatThread in Database.ChatsDatabase.ReadAllGeneric<ChatThread>())
            {
                if (chatThread.PlayerIds.Contains((int)accessToken.PlayerId))
                    chatThreads.Add(chatThread);
            }

            return chatThreads;
        }

        public string FriendlyName => "Chats Backend";
    }
}
