﻿using Carbon.Backend.Interfaces;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Carbon.Utilities;
using Carbon.Backend.AccessTokens;
using Carbon.Backend.Databasing;
using Carbon.Json;
using Carbon.Servers;
using Openlabs.Mgcxm.Internal;
using Carbon.Json.Notifications;

namespace Carbon.Backend
{
    internal class Consumables : IBackendProvider
    {
        public IPromise Initialize() => new Promise(action =>
        {
            Singleton.Allocate(this);
            action.Resolve();
        });

        public IPromise Cleanup() => new Promise(action =>
        {
            Singleton.Free<Relationships>();
            action.Resolve();
        });


        public List<Consumable> GetConsumables(AccessToken accessToken)
        {
            if (!Database.ConsumableDatabase.Exists(accessToken.PlatformId))
            {
                Database.ConsumableDatabase.WriteGeneric<List<Consumable>>(accessToken.PlatformId, new List<Consumable>());

                return new List<Consumable>();
            }
            else
            {
                return Database.ConsumableDatabase.ReadGeneric<List<Consumable>>(accessToken.PlatformId);
            }
        }



        public void addconsumable(AccessToken accessToken, Consumable consumable)
        {

            

            var inventory = GetConsumables(accessToken);

            if (inventory.Any(p => p.ConsumableItemDesc == consumable.ConsumableItemDesc))
            {
                foreach (var Item in inventory)
                {
                    if (Item.ConsumableItemDesc == consumable.ConsumableItemDesc)
                    {
                        Item.Count++;
                        Database.ConsumableDatabase.WriteGeneric<List<Consumable>>(accessToken.PlatformId, inventory);
                    }
                }
            }
            else
            {
                consumable.Count = 1;
                inventory.Add(consumable);
                Database.ConsumableDatabase.WriteGeneric<List<Consumable>>(accessToken.PlatformId, inventory);
            }

        }


        public void removeconsumable(AccessToken accessToken, Consumable consumable)
        {
            var connectionNode = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(accessToken.PlayerId);
            var inventory = GetConsumables(accessToken);

            if (inventory.Any(p => p.ConsumableItemDesc == consumable.ConsumableItemDesc))
            {
                foreach (var Item in inventory)
                {
                    if (Item.ConsumableItemDesc == consumable.ConsumableItemDesc)
                    {

                        if (Item.Count == 1 )
                        {

                            Logger.Info(inventory.ElementAt(inventory.IndexOf(Item)).ToString());

                            inventory.Remove(Item);
                            

                            if (connectionNode != null)
                            {
                                connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                                {
                                    Id = PushNotificationId.ConsumableMappingRemoved,
                                    Msg = Item
                                });
                            }
                            Database.ConsumableDatabase.WriteGeneric<List<Consumable>>(accessToken.PlatformId, inventory);
                        }
                        else
                        {
                            Item.Count -= 1;
                            if (connectionNode != null)
                            {
                                connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                                {
                                    Id = PushNotificationId.ConsumableMappingRemoved,
                                    Msg = consumable
                                });
                                  
                            }
                            Database.ConsumableDatabase.WriteGeneric<List<Consumable>>(accessToken.PlatformId, inventory);
                        }
                        
                    }
                }
            }
           

        }


        public string GetConsumableItemDesc(ConsumableType type)
        {
            if (type == ConsumableType.RootBeer)
            { 
                return "JfnVXFmilU6ysv-VbTAe3A";
            }
            else
            {
                return "";
            }
        }

        public string FriendlyName => "Consumable Backend";
    }
}
