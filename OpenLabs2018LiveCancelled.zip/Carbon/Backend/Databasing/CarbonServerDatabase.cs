﻿using Newtonsoft.Json;
using Openlabs.Mgcxm.Common;

using System;
using System.Collections.Generic;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.Databasing
{
    internal class CarbonServerDatabase : ServerDatabaseReader, IServerDatabase
    {
        private string _databaseType;
        const string DB_PATH = "database";

        public string GetBasePath()
        {
            var dbDirectory = Path.Combine(Environment.CurrentDirectory, DB_PATH);
            Directory.CreateDirectory(dbDirectory);

            var dbTypeDirectory = Path.Combine(dbDirectory, _databaseType);
            Directory.CreateDirectory(dbTypeDirectory);

            return dbTypeDirectory;
        }

        public string GetPath(string path)
        {
            return string.IsNullOrEmpty(path) ? GetBasePath() : Path.Combine(GetBasePath(), path);
        }

        public CarbonServerDatabase(string databaseType)
        {
            _databaseType = databaseType; 
        }

        public override void AppendString(string fileName, string content)
        {
            var path = GetPath(fileName);
            File.AppendAllText(path, content);
        }

        public override T ReadGeneric<T>(string fileName)
        {
            var path = GetPath(fileName);
            if (!File.Exists(path))
                throw new FileNotFoundException("The file '" + fileName + "' was not found in the database");

            return JsonConvert.DeserializeObject<T>(File.ReadAllText(path))!;
        }

        public override int ReadInt(string fileName)
        {
            return int.Parse(ReadString(fileName));
        }

        public override string ReadString(string fileName)
        {
            var path = GetPath(fileName);
            if (!File.Exists(path))
                throw new FileNotFoundException("The file '" + fileName + "' was not found in the database");

            return File.ReadAllText(path);
        }

        public byte[] ReadBytes(string fileName)
        {
            var path = GetPath(fileName);
            if (!File.Exists(path))
                throw new FileNotFoundException("The file '" + fileName + "' was not found in the database");

            return File.ReadAllBytes(path);
        }

        public override void WriteGeneric<T>(string fileName, T content)
        {
            var path = GetPath(fileName);
            File.WriteAllText(path, JsonConvert.SerializeObject(content));
        }

        public override void WriteInt(string fileName, int content)
        {
            WriteString(fileName, content.ToString());
        }

        public override void WriteString(string fileName, string content)
        {
            var path = GetPath(fileName);
            File.WriteAllText(path, content);
        }

        public void WriteBytes(string fileName, byte[] content)
        {
            var path = GetPath(fileName);
            File.WriteAllBytes(path, content);
        }

        public bool Exists(string fileName)
        {
            var path = GetPath(fileName);
            return File.Exists(path);
        }

        public T[] ReadAllGeneric<T>(string directory = "")
        {
            var path = GetPath(directory);
            var files = Directory.GetFiles(path, "*");

            T[] result = new T[files.Length];
            for (int iFile = 0; iFile < files.Length; iFile++)
            {
                var generic = JsonConvert.DeserializeObject<T>(File.ReadAllText(files[iFile]))!;
                result[iFile] = generic;
            }

            return result;
        }

        public int[] ReadAllInt(string directory = "")
        {
            var path = GetPath(directory);
            var files = Directory.GetFiles(path, "*");

            int[] result = new int[files.Length];
            for (int iFile = 0; iFile < files.Length; iFile++)
            {
                var strToInt = int.Parse(File.ReadAllText(files[iFile]));
                result[iFile] = strToInt;
            }

            return result;
        }

        public string[] ReadAllString(string directory = "")
        {
            var path = GetPath(directory);
            var files = Directory.GetFiles(path, "*");

            string[] result = new string[files.Length];
            for (int iFile = 0; iFile < files.Length; iFile++)
            {
                var str = File.ReadAllText(files[iFile]);
                result[iFile] = str;
            }

            return result;
        }

        public List<byte[]> ReadAllBytes(string directory = "")
        {
            var path = GetPath(directory);
            var files = Directory.GetFiles(path, "*");

            List<byte[]> result = new List<byte[]>(files.Length);
            for (int iFile = 0; iFile < files.Length; iFile++)
            {
                var bytes = File.ReadAllBytes(files[iFile]);
                result[iFile] = bytes;
            }

            return result;
        }

        public void Delete(string fileName)
        {
            var path = GetPath(fileName);
            if (Exists(fileName))
                File.Delete(path);
        }
    }
}
