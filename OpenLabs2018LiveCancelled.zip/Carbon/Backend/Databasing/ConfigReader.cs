﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.Databasing
{
    internal class ConfigReader
    {
        public ConfigReader(string content)
        {
            _list = new List<string>();
            _dictionary = new Dictionary<string, string>();

            _content = content;
            _reader = new StringReader(content);

            string line = "";
            while (!string.IsNullOrEmpty(line = _reader.ReadLine()))
            {
                _list.Add(line);
            }

            foreach (var cline in _list)
                _dictionary.Add(cline.Split("=")[0], cline.Split("=")[1]);
        }

        public string GetValue(string key)
        {
            foreach (var kvp in _dictionary)
            {
                if (kvp.Key == key)
                    return kvp.Value;
            }
            return null;
        }

        public void SetValue(string key, string value)
        {
            if (_dictionary.ContainsKey(key))
                _dictionary[key] = value;
            else
                _dictionary.Add(key, value);
        }

        public override string ToString()
        {
            StringBuilder stringBuilder = new StringBuilder();
            foreach (var kvp in _dictionary)
                stringBuilder.AppendLine(string.Format("{0}={1}", kvp.Key, kvp.Value));

            return stringBuilder.ToString();
        }

        public void WriteToDatabase(IServerDatabase database, string path)
        {
            database.WriteString(path, this.ToString());
        }

        private StringReader _reader;
        private string _content;
        private List<string> _list;
        private Dictionary<string, string> _dictionary;
    }
}
