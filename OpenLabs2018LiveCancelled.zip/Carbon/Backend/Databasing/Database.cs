﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.Databasing
{
    internal static class Database
    {
        //
        // Api
        //
        public static readonly IServerDatabase ProfileDatabase = new CarbonServerDatabase("profiles");
        public static readonly IServerDatabase GameSessionDatabase = new CarbonServerDatabase("game_session");
        public static readonly IServerDatabase RelationshipsDatabase = new CarbonServerDatabase("relationships");
        public static readonly IServerDatabase AvatarDatabase = new CarbonServerDatabase("avatar");
        public static readonly IServerDatabase SavedOutfitsDatabase = new CarbonServerDatabase("saved_outfits");
        public static readonly IServerDatabase WardrobeDatabase = new CarbonServerDatabase("wardrobe");
        public static readonly IServerDatabase NotificationsDatabase = new CarbonServerDatabase("notifications");
        public static readonly IServerDatabase ChatsDatabase = new CarbonServerDatabase("chats");
        public static readonly IServerDatabase LoginLockTokenDatabase = new CarbonServerDatabase("login_locks");
        public static readonly IServerDatabase BanishmentDatabase = new CarbonServerDatabase("banishments");
        public static readonly IServerDatabase SubscriptionsDatabase = new CarbonServerDatabase("subscriptions");
        public static readonly IServerDatabase PlayerSettingsDatabase = new CarbonServerDatabase("player_settings");
        public static readonly IServerDatabase EquipmentDatabase = new CarbonServerDatabase("equipment");
        public static readonly IServerDatabase GiftsDatabase = new CarbonServerDatabase("gifts");
        public static readonly IServerDatabase RoomsDatabase = new CarbonServerDatabase("rooms");
        public static readonly IServerDatabase RoomDetailsDatabase = new CarbonServerDatabase("room_details");
        public static readonly IServerDatabase ActivityDataDatabase = new CarbonServerDatabase("activity_data");
        public static readonly IServerDatabase EconDatabase = new CarbonServerDatabase("econ");
        public static readonly IServerDatabase StorefrontDatabase = new CarbonServerDatabase("storefront");
        public static readonly IServerDatabase ProgressionDatabase = new CarbonServerDatabase("challenges");
        public static readonly IServerDatabase ConsumableDatabase = new CarbonServerDatabase("consumables");
        public static readonly IServerDatabase GiftcapDatabase = new CarbonServerDatabase("giftcap");
        //
        // CDN / Images
        //
        public static readonly IServerDatabase ContentDatabase = new CarbonServerDatabase("cdn");
        public static readonly IServerDatabase ImagesDatabase = new CarbonServerDatabase("images");

        // 
        // Utils
        //
        public static readonly IServerDatabase CertificateDatabase = new CarbonServerDatabase("certificates");
        public static readonly IServerDatabase PhotonDatabase = new CarbonServerDatabase("photon");
    }
}
