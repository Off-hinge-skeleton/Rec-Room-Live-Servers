﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.Databasing
{
    internal interface IServerDatabase
    {
        string GetBasePath();
        string GetPath(string path);

        void AppendString(string fileName, string content);

        T ReadGeneric<T>(string fileName);
        int ReadInt(string fileName);
        string ReadString(string fileName);
        byte[] ReadBytes(string fileName);

        void WriteGeneric<T>(string fileName, T content);
        void WriteInt(string fileName, int content);
        void WriteString(string fileName, string content);
        void WriteBytes(string fileName, byte[] content);

        T[] ReadAllGeneric<T>(string directory = "");
        int[] ReadAllInt(string directory = "");
        string[] ReadAllString(string directory = "");
        List<byte[]> ReadAllBytes(string directory = "");

        void Delete(string fileName);
        bool Exists(string fileName);
    }
}
