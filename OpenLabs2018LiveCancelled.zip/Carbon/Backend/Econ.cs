﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Databasing;
using Carbon.Json;
using Carbon.Json.Storefronts;
using Openlabs.Mgcxm.Net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend
{
    internal class Econ
    {


        public static BalanceResponseDTO GetStorefrontBalance(CurrencyType type, AccessToken accessToken)
        {
            if (!Database.EconDatabase.Exists(accessToken.PlatformId))
            {


                var result = new BalanceResponseDTO()
                {
                    Balance = 0,
                    CurrencyType = type

                };

                Database.EconDatabase.WriteGeneric(accessToken.PlatformId, new List<BalanceResponseDTO>() { result });


                return result;
            }

            else
            {

                var currency = new BalanceResponseDTO();

                var result = Database.EconDatabase.ReadGeneric<List<BalanceResponseDTO>>(accessToken.PlatformId);

                if (result.Any(item => item.CurrencyType == type))
                {
                    currency = result.FirstOrDefault(item => item.CurrencyType == type);

                    if (currency.Balance < 0)
                    {
                        currency.Balance = 0;
                        Database.EconDatabase.WriteGeneric(accessToken.PlatformId, result);

                        return currency;
                    }
                }
                else
                {
                    currency = new BalanceResponseDTO
                    {
                        Balance = 0,
                        CurrencyType = type
                    };

                    result.Add(currency);

                    Database.EconDatabase.WriteGeneric(accessToken.PlatformId, result);
                }


                return currency;
            }


        }
    }
}
