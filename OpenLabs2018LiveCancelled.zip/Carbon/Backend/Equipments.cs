﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Databasing;
using Carbon.Backend.Interfaces;
using Carbon.Json;
using Carbon.Utilities;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend
{
    internal class Equipments : IBackendProvider, IEquipmentBackend
    {
        public IPromise Initialize() => new Promise(action =>
        {
            Singleton.Allocate(this);
            action.Resolve();
        });

        public IPromise Cleanup() => new Promise(action =>
        {
            Singleton.Free<Equipments>();
            action.Resolve();
        });

        public IPromise<List<Equipment>> GetEquipment(AccessToken accessToken) => new Promise<List<Equipment>>(action =>
        {
            if (!Database.EquipmentDatabase.Exists(accessToken.PlatformId))
            {
                var initializedList = new List<Equipment>();

                Database.EquipmentDatabase.WriteGeneric(accessToken.PlatformId, initializedList);
                action.Resolve(initializedList);
            }
            else
                action.Resolve(Database.EquipmentDatabase.ReadGeneric<List<Equipment>>(accessToken.PlatformId));
        });

        public IPromise UpdateEquipment(AccessToken accessToken, List<Equipment> equipments) => new Promise(action =>
        {
            GetEquipment(accessToken)
                .Then(equipment =>
                {
                    foreach (var equip in equipments)
                    {
                   
                        foreach (var equipItem in equipment)
                        {
                            if (equipItem.ModificationGuid == equip.ModificationGuid)
                            {
                                equipItem.Favorited = equip.Favorited;
                            }
                        }
                    }

                    Database.EquipmentDatabase.WriteGeneric(accessToken.PlatformId, equipment);
                    action.Resolve();
                })
                .Catch(action.Reject);
        });

        public string FriendlyName => "Equipment Backend";
    }
}
