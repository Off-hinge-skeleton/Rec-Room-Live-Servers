﻿using Carbon.Backend.Interfaces;
using Carbon.Json.Checklist;
using Carbon.Json;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Carbon.Utilities;
using Carbon.Json.Events;
using Carbon.Backend.AccessTokens;

namespace Carbon.Backend
{
    internal class Events : IBackendProvider, IEventsBackend
    {
        public IPromise Initialize() => new Promise(action =>
        {
            Singleton.Allocate(this);
            action.Resolve();
        });

        public IPromise Cleanup() => new Promise(action =>
        {
            Singleton.Free<Events>();
            action.Resolve();
        });

        public IPromise<PlayerEventList> GetEventList(AccessToken accessToken) => new Promise<PlayerEventList>(action =>
        {
            action.Resolve(new PlayerEventList
            {
                Created = new PlayerEventDetails[0],
                Responses = new PlayerEventResponseDetails[0]
            });
        });

        public IPromise<List<FeaturedEvent>> GetFeaturedEventList(AccessToken accessToken) => new Promise<List<FeaturedEvent>>(action =>
        {
            action.Resolve(new List<FeaturedEvent>());
        });

        public string FriendlyName => "Events Backend";
    }
}
