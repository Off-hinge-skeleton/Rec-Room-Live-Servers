﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Attributes;
using Carbon.Backend.Interfaces;
using Carbon.Backend.Statics;
using Carbon.Json;
using Carbon.Json.Matchmaking;
using Carbon.Json.Notifications;
using Carbon.Json.Rooms;
using Carbon.Servers;
using Carbon.Utilities;
using OpenlabsSDKV1.Core;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GameSession = Carbon.Json.Matchmaking.GameSession;

namespace Carbon.Backend
{
    internal class GameSessions : IBackendProvider, IGameSessionsBackend
    {
        public static string Region = "usw";

        public IReadOnlyList<GameSession> AllSessions => _sessions;
        [Cascaded] List<GameSession> _sessions = new List<GameSession>();

        public IPromise Initialize() => new Promise(action =>
        {
            Singleton.Allocate(this);
            Task.Run(async () => await Update());
            action.Resolve();
        });

        public IPromise Cleanup() => new Promise(action =>
        {
            Singleton.Free<GameSessions>();
            action.Resolve();
        });

        private async Task Update()
        {
            for (; ; )
            {
                await Task.Delay(500);
                ClearUnusedSessions();
            }
        }

        public void ClearUnusedSessions()
        {
            var sessionsToDelete = new List<long>();

            foreach (var session in _sessions)
            {
                if (!Singleton<Presence>.Instance.AllPresences.Any(
                        x => x.Value.GameSession != null &&
                             x.Value.GameSession.GameSessionId == session.GameSessionId))
                    sessionsToDelete.Add(session.GameSessionId);
            }

            foreach (var sessionId in sessionsToDelete)
                _sessions.RemoveAll(x => x.GameSessionId == sessionId);
        }

        public IPromise<MatchmakingJoinResult> JoinRandom(AccessToken accessToken, JoinRandomGameSessionRequest request) => new Promise<MatchmakingJoinResult>(action =>
        {
            var roomsBackend = BackendService.GetBackend<Rooms>();
            var presenceBackend = BackendService.GetBackend<Presence>();
            var messagesBackend = BackendService.GetBackend<Messages>();
            var notificationConnectionHandler = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(long.Parse(accessToken.PlayerId.ToString())).Handler;

            var joinResult = new MatchmakingJoinResult
            {
                Result = MatchmakingErrorCode.NoSuchRoom,
                GameSession = null
            };

            bool isDormRoom = request.ActivityLevelIds[0] == ActivityLevelIds.DormRoom.GuidString;
            var room = isDormRoom
                        ? roomsBackend.NonBackend_GetDormRoom(accessToken)
                        : RecRoomOriginalRooms.GetRoomFromActivityLevelId(request.ActivityLevelIds[0]);
            var roomDetail = roomsBackend.NonBackend_GetRoomDetails(accessToken, room.RoomId);

            if (room == null)
            {
                action.Resolve(joinResult);
                return;
            }

            GameSession gameSession;
            var gameSessionId = Openlabs.Mgcxm.Common.Random.Range(10000000, 1000000000);
            var photonRoomId = UUID.CreateUnique().GuidValue.ToString();
            try
            {
                if (!isDormRoom && _sessions.Any(x => x.ActivityLevelId == request.ActivityLevelIds[0]))
                {
                    gameSession = _sessions.Find(x => x.ActivityLevelId == request.ActivityLevelIds[0])!;

                    joinResult.Result = MatchmakingErrorCode.Success;
                    joinResult.GameSession = gameSession;
                }
                else
                {
                    gameSession = new GameSession
                    {
                        GameSessionId = gameSessionId,
                        RoomId = photonRoomId,
                        RegionId = Region,
                        RecRoomId = room.RoomId,
                        EventId = null,
                        Name = room.Name,
                        CreatorPlayerId = room.CreatorPlayerId,
                        ActivityLevelId = room.ActivityLevelId,
                        SupportsScreens = room.SupportsScreenMode(),
                        SupportsVR = room.SupportsVR(),
                        Sandbox = room.IsSandbox,
                        MaxCapacity = roomDetail.MaxPlayers,
                        Private = false,
                        GameInProgress = false,
                        IsFull = false
                    };

                    joinResult.Result = MatchmakingErrorCode.Success;
                    joinResult.GameSession = gameSession;
                    _sessions.Add(gameSession);
                }
            }
            catch
            {
                gameSession = new GameSession
                {
                    GameSessionId = gameSessionId,
                    RoomId = photonRoomId,
                    RegionId = Region,
                    RecRoomId = room.RoomId,
                    EventId = null,
                    Name = room.Name,
                    CreatorPlayerId = room.CreatorPlayerId,
                    ActivityLevelId = room.ActivityLevelId,
                    SupportsScreens = room.SupportsScreenMode(),
                    SupportsVR = room.SupportsVR(),
                    Sandbox = room.IsSandbox,
                    MaxCapacity = roomDetail.MaxPlayers,
                    Private = false,
                    GameInProgress = false,
                    IsFull = false
                };

                joinResult.Result = MatchmakingErrorCode.Success;
                joinResult.GameSession = gameSession;
                _sessions.Add(gameSession);
            }

            // check expected players
            foreach (var expectedPlayer in request.ExpectedPlayerIds)
            {
                var node = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(expectedPlayer);
                if (node != null)
                {
                    messagesBackend.NonBackend_AddMessage(AccessToken.GetFromPlayerId(expectedPlayer), NotificationMessage.Create(
                        long.Parse(accessToken.PlayerId.ToString()),
                        NotificationMessageType.GameInvite,
                        roomId: gameSession.RecRoomId));
                }
            }

            presenceBackend.NonBackend_SetPlayerPresenseOnline(accessToken, true);
            presenceBackend.NonBackend_SetPlayerPresenseGameSession(accessToken, gameSession);
            notificationConnectionHandler.SendNotificationBulk(new PushNotificationDto<GameSession>
            {
                Id = PushNotificationId.SubscriptionUpdateGameSession,
                Msg = gameSession
            }, new PushNotificationDto<PlayerPresence>
            {
                Id = PushNotificationId.SubscriptionUpdatePresence,
                Msg = presenceBackend.NonBackend_GetPlayerPresence(accessToken)
            });
            action.Resolve(joinResult);
        });

        public IPromise<MatchmakingJoinResult> JoinPlayer(AccessToken accessToken, JoinPlayerRequest request) => new Promise<MatchmakingJoinResult>(action =>
        {
            var roomsBackend = BackendService.GetBackend<Rooms>();
            var presenceBackend = BackendService.GetBackend<Presence>();
            var messagesBackend = BackendService.GetBackend<Messages>();
            var loginLockToken = accessToken.GetOTT("LoginLockToken").TokenString;
            var notificationConnectionHandler
                = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(loginLockToken).Handler;

            var joinResult = new MatchmakingJoinResult
            {
                Result = MatchmakingErrorCode.PlayerNotOnline,
                GameSession = null
            };

            var targetPlayerPresence = presenceBackend.NonBackend_GetPlayerPresence(AccessToken.GetFromPlayerId(request.PlayerId));
            if (targetPlayerPresence == null)
            {
                action.Resolve(joinResult);
                return;
            }

            var room = RecRoomOriginalRooms.GetRoomFromActivityLevelId(targetPlayerPresence.GameSession.ActivityLevelId);
            var roomDetail = roomsBackend.NonBackend_GetRoomDetails(accessToken, room.RoomId);

            if (room == null)
            {
                joinResult.Result = MatchmakingErrorCode.NoSuchRoom;
                action.Resolve(joinResult);
                return;
            }

            GameSession gameSession = _sessions.Find(x => x.GameSessionId == targetPlayerPresence.GameSession.GameSessionId)!;

            if (gameSession == null)
            {
                joinResult.Result = MatchmakingErrorCode.PlayerNotOnline;
                action.Resolve(joinResult);
                return;
            }

            joinResult.Result = MatchmakingErrorCode.Success;
            joinResult.GameSession = gameSession;

            presenceBackend.NonBackend_SetPlayerPresenseOnline(accessToken, true);
            presenceBackend.NonBackend_SetPlayerPresenseGameSession(accessToken, gameSession);
            notificationConnectionHandler.SendNotificationBulk(new PushNotificationDto<GameSession>
            {
                Id = PushNotificationId.SubscriptionUpdateGameSession,
                Msg = gameSession
            }, new PushNotificationDto<PlayerPresence>
            {
                Id = PushNotificationId.SubscriptionUpdatePresence,
                Msg = presenceBackend.NonBackend_GetPlayerPresence(accessToken)
            });
            action.Resolve(joinResult);
        });

        public IPromise<MatchmakingJoinResult> Create(AccessToken accessToken, CreateCustomGameSessionRequest request) => new Promise<MatchmakingJoinResult>(action =>
        {
            var roomsBackend = BackendService.GetBackend<Rooms>();
            var presenceBackend = BackendService.GetBackend<Presence>();
            var messagesBackend = BackendService.GetBackend<Messages>();
            var loginLockToken = accessToken.GetOTT("LoginLockToken").TokenString;
            var notificationConnectionHandler
                = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(loginLockToken).Handler;

            var joinResult = new MatchmakingJoinResult
            {
                Result = MatchmakingErrorCode.NoSuchGame,
                GameSession = null
            };

            var targetRoom = RecRoomOriginalRooms.GetRoomFromActivityLevelId(request.ActivityLevelId);
            GameSession gameSession = null;

            if (targetRoom == null)
            {
                joinResult.Result = MatchmakingErrorCode.NoSuchRoom;
                action.Resolve(joinResult);

                return;
            }

            var clonedRoom = ((ICloneable<Room>)targetRoom).Clone();
            clonedRoom.RoomId = Openlabs.Mgcxm.Common.Random.Range(1000000, 9999999);
            clonedRoom.Description = "";
            clonedRoom.CreatorPlayerId = accessToken.PlayerId;
            clonedRoom.Accessibility = RoomAccessibility.Private;
            clonedRoom.IsSandbox = true;

            roomsBackend.NonBackend_AddRoom(accessToken, clonedRoom);
            var roomDetail = roomsBackend.NonBackend_GetRoomDetails(accessToken, clonedRoom.RoomId);

            var gameSessionId = Openlabs.Mgcxm.Common.Random.Range(10000000, 1000000000);
            var photonRoomId = UUID.CreateUnique().GuidValue.ToString();
            gameSession = new GameSession
            {
                GameSessionId = gameSessionId,
                RoomId = photonRoomId,
                RegionId = Region,
                RecRoomId = clonedRoom.RoomId,
                EventId = null,
                Name = clonedRoom.Name,
                CreatorPlayerId = clonedRoom.CreatorPlayerId,
                ActivityLevelId = clonedRoom.ActivityLevelId,
                SupportsScreens = clonedRoom.SupportsScreenMode(),
                SupportsVR = clonedRoom.SupportsVR(),
                Sandbox = clonedRoom.IsSandbox,
                MaxCapacity = roomDetail.MaxPlayers,
                Private = clonedRoom.Accessibility == RoomAccessibility.Private,
                GameInProgress = false,
                IsFull = false
            };

            presenceBackend.NonBackend_SetPlayerPresenseOnline(accessToken, true);
            presenceBackend.NonBackend_SetPlayerPresenseGameSession(accessToken, gameSession);
            notificationConnectionHandler.SendNotificationBulk(new PushNotificationDto<GameSession>
            {
                Id = PushNotificationId.SubscriptionUpdateGameSession,
                Msg = gameSession
            }, new PushNotificationDto<PlayerPresence>
            {
                Id = PushNotificationId.SubscriptionUpdatePresence,
                Msg = presenceBackend.NonBackend_GetPlayerPresence(accessToken)
            });
            action.Resolve(joinResult);
        });

        public IPromise<MatchmakingJoinResult> JoinRoom(AccessToken accessToken, JoinRoomRequest request) => new Promise<MatchmakingJoinResult>(action =>
        {
            var roomsBackend = BackendService.GetBackend<Rooms>();
            var presenceBackend = BackendService.GetBackend<Presence>();
            var messagesBackend = BackendService.GetBackend<Messages>();
            var loginLockToken = accessToken.GetOTT("LoginLockToken").TokenString;
            var notificationConnectionHandler
                = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(loginLockToken).Handler;

            var joinResult = new MatchmakingJoinResult
            {
                Result = MatchmakingErrorCode.NoSuchGame,
                GameSession = null
            };

            var targetRoom = roomsBackend.NonBackend_GetRoom(accessToken, request.RoomId);
            GameSession gameSession = null;

            if (targetRoom == null)
            {
                joinResult.Result = MatchmakingErrorCode.NoSuchRoom;
                action.Resolve(joinResult);
                return;
            }

            var roomDetail = roomsBackend.NonBackend_GetRoomDetails(accessToken, targetRoom.RoomId);

            var gameSessionId = Openlabs.Mgcxm.Common.Random.Range(10000000, 1000000000);
            var photonRoomId = UUID.CreateUnique().GuidValue.ToString();
            if (_sessions.Any(x => x.RecRoomId == request.RoomId))
            {
                gameSession = _sessions.Find(x => x.RecRoomId == request.RoomId)!;

                joinResult.Result = MatchmakingErrorCode.Success;
                joinResult.GameSession = gameSession;
            }
            else
            {
                gameSession = new GameSession
                {
                    GameSessionId = gameSessionId,
                    RoomId = photonRoomId,
                    RegionId = Region,
                    RecRoomId = targetRoom.RoomId,
                    EventId = null,
                    Name = targetRoom.Name,
                    CreatorPlayerId = targetRoom.CreatorPlayerId,
                    ActivityLevelId = targetRoom.ActivityLevelId,
                    SupportsScreens = targetRoom.SupportsScreenMode(),
                    SupportsVR = targetRoom.SupportsVR(),
                    Sandbox = targetRoom.IsSandbox,
                    MaxCapacity = roomDetail.MaxPlayers,
                    Private = false,
                    GameInProgress = false,
                    IsFull = false
                };

                joinResult.Result = MatchmakingErrorCode.Success;
                joinResult.GameSession = gameSession;
                _sessions.Add(gameSession);
            }

            presenceBackend.NonBackend_SetPlayerPresenseOnline(accessToken, true);
            presenceBackend.NonBackend_SetPlayerPresenseGameSession(accessToken, gameSession);
            notificationConnectionHandler.SendNotificationBulk(new PushNotificationDto<GameSession>
            {
                Id = PushNotificationId.SubscriptionUpdateGameSession,
                Msg = gameSession
            }, new PushNotificationDto<PlayerPresence>
            {
                Id = PushNotificationId.SubscriptionUpdatePresence,
                Msg = presenceBackend.NonBackend_GetPlayerPresence(accessToken)
            });
            action.Resolve(joinResult);
        });

        public string FriendlyName => "Game Sessions Backend";
    }
}
