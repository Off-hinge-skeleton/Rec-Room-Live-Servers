﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Databasing;
using Carbon.Backend.Interfaces;
using Carbon.Backend.Statics;
using Carbon.Json;
using Carbon.Json.Notifications;
using Carbon.Servers;
using Carbon.Utilities;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend
{
    internal class Gifts : IBackendProvider, IGiftsBackend
    {
        public IPromise Initialize() => new Promise(action =>
        {
            Singleton.Allocate(this);
            action.Resolve();
        });

        public IPromise Cleanup() => new Promise(action =>
        {
            Singleton.Free<Gifts>();
            action.Resolve();
        });

        public IPromise<List<GiftPackage>> GetGifts(AccessToken accessToken) => new Promise<List<GiftPackage>>(action =>
        {
            if (!Database.GiftsDatabase.Exists(accessToken.PlatformId))
            {
                var initializedList = new List<GiftPackage>();

                Database.GiftsDatabase.WriteGeneric(accessToken.PlatformId, initializedList);
                action.Resolve(initializedList);
            }
            else
                action.Resolve(Database.GiftsDatabase.ReadGeneric<List<GiftPackage>>(accessToken.PlatformId));
        });

        public void NonBackend_AddGift(AccessToken accessToken, GiftPackage gift)
        {
            GetGifts(accessToken)
                .Then(gifts =>
                {
                    gifts.Add(gift);
                    var loginLockToken = accessToken.GetOTT("LoginLockToken").TokenString;

                    var connectionHandler = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(loginLockToken).Handler;

                    Database.GiftsDatabase.WriteGeneric(accessToken.PlatformId, gifts);
                    connectionHandler.SendNotificationBulk(new PushNotificationDto<GiftPackage>
                    {
                        Id = PushNotificationId.GiftPackageReceived,
                        Msg = gift
                    });
                });
        }

        public void NonBackend_ConsumeGift(AccessToken accessToken, long giftPackageId)
        {
            GetGifts(accessToken)
                .Then(gifts =>
                {
                    var gift = gifts.Find(x => x.Id == giftPackageId);
                    if (gift == null) return;

                    var avatarBackend = BackendService.GetBackend<Avatars>();
                    
                    if (gift.IsCurrency())
                    {

                    }
                    else if (gift.IsAvatarItem()) 
                    {
                        avatarBackend.NonBackend_AddAvatarItem(accessToken, new UnlockedAvatarItem
                        {
                            AvatarItemDesc = gift.AvatarItemDesc,
                            UnlockedLevel = gift.Level
                        });
                    }
                    else if (gift.IsConsumableItem())
                    {
                        // No support for consumable
                    }
                    else if (gift.IsEquipmentItem())
                    {
                        // No support for equipment
                    }
                });
        }

        public void NonBackend_RemoveGift(AccessToken accessToken, long giftPackageId)
        {
            GetGifts(accessToken)
                .Then(gifts =>
                {
                    gifts.RemoveAll(x => x.Id == giftPackageId);
                });
        }

        public string FriendlyName => "Gifts Backend";
    }
}
