﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Interfaces;
using Carbon.Json;
using Carbon.Utilities;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HttpMultipartParser;
using System.Reflection.Metadata.Ecma335;
using OpenlabsSDKV1.Core;
using Openlabs.Mgcxm.Internal;
using Carbon.Servers;
using Openlabs.Mgcxm.Assets;

namespace Carbon.Backend
{
    internal class Images : IBackendProvider, IImagesBackend
    {
        public IPromise Initialize() => new Promise(action =>
        {
            Singleton.Allocate(this);
            action.Resolve();
        });

        public IPromise Cleanup() => new Promise(action =>
        {
            Singleton.Free<Images>();
            action.Resolve();
        });

        public IPromise<List<NamedImage>> GetNamedImages(AccessToken accessToken) => new Promise<List<NamedImage>>(action =>
        {
            action.Resolve(new List<NamedImage>()
            {
                new NamedImage
                {
                    ImageName = "DormRoomBucket",
                    FriendlyImageName = "510155d49dd218213971f8c94f69eb41.png",
                    StartTime = DateTime.Now.AddDays(-5),
                    EndTime = DateTime.Now.AddDays(10)
                }
            });
        });

        public IPromise<ImageNameResponse> UploadSavedImage(AccessToken accessToken, byte[] formData) => new Promise<ImageNameResponse>(action =>
        {
            var parser = MultipartFormDataParser.Parse(new MemoryStream(formData));

            if (parser == null)
                action.Reject(Error.Create(14, "Cant upload image", "Failed to parse form data"));
            else 
            {
                var imageServer = Singleton<ImagesServer>.Instance;
                ImageFileAsset mainImage = null;

                foreach (var file in parser.Files)
                {
                    if (imageServer.IsImageSizeAgaisntGuidelines(file.Data.Length))
                    {
                        action.Reject(Error.Create(13, "Cant upload image", "File size against image guidelines"));
                        return;
                    }

                    if (!IsAltImage(file))
                    {
                        imageServer.UploadFile(file, out var imageData);

                        Logger.Info(string.Format("File Name = {0}, Byte Size = {1}, Image Size = ({2} x {3})", file.Name, file.Data.Length, imageData.Width, imageData.Height));
                        mainImage = imageData;
                    }
                }

                action.Resolve(new ImageNameResponse
                {
                    ImageName = mainImage.FileName
                });
            }
        });

        private bool IsAltImage(FilePart file) => file.Name.Contains("alt");

        public string FriendlyName => "Images Backend";
    }
}
