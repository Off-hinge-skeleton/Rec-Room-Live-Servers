﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Attributes;
using Carbon.Json;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.Interfaces
{
    internal interface IAvatarsBackend
    {
        [BackendMethod(IsAuthorized = true)]
        IPromise<Avatar> GetCurrentAvatar(AccessToken accessToken);

        [BackendMethod(IsAuthorized = true)]
        IPromise SetCurrentAvatar(AccessToken accessToken, Avatar avatar);

        [BackendMethod(IsAuthorized = true)]
        IPromise<List<SavedOutfit>> GetSavedOutfits(AccessToken accessToken);

        [BackendMethod(IsAuthorized = true)]
        IPromise<List<UnlockedAvatarItem>> GetItemWardrobe(AccessToken accessToken);

        void NonBackend_AddAvatarItem(AccessToken accessToken, UnlockedAvatarItem avatarItem);
    }
}
