﻿using OpenlabsSDKV1.Core;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Carbon.Backend.Interfaces
{
    internal interface IBackendProvider
    {
        IPromise Initialize();
        IPromise Cleanup();

        string FriendlyName { get; }
    }
}
