﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Attributes;
using Carbon.Json.Chats;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.Interfaces
{
    internal interface IChatsBackend
    {
        [BackendMethod(IsAuthorized = true)]
        IPromise<List<ChatThread>> GetMyChats(AccessToken accessToken, int take = 50);

        ChatThread NonBackend_CreateThread(AccessToken accessToken, List<int> playerIds, out long threadId);
        void NonBackend_DeleteThread(AccessToken accessToken, long threadId);
        List<ChatThread> NonBackend_GetChats(AccessToken accessToken);
    }
}
