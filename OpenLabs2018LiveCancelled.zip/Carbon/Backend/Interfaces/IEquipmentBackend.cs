﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Attributes;
using Carbon.Json;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.Interfaces
{
    internal interface IEquipmentBackend
    {
        [BackendMethod(IsAuthorized = true)]
        IPromise<List<Equipment>> GetEquipment(AccessToken accessToken);

        [BackendMethod(IsAuthorized = true)]
        IPromise UpdateEquipment(AccessToken accessToken, List<Equipment> equipments);
    }
}
