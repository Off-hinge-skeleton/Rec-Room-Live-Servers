﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Attributes;
using Carbon.Json.Events;

using OpenlabsSDKV1.Core.Async;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.Interfaces
{
    internal interface IEventsBackend
    {
        [BackendMethod(IsAuthorized = true)]
        IPromise<PlayerEventList> GetEventList(AccessToken accessToken);

        [BackendMethod(IsAuthorized = true)]
        IPromise<List<FeaturedEvent>> GetFeaturedEventList(AccessToken accessToken);
    }
}
