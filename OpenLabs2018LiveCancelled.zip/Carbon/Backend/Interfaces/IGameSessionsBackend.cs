﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Attributes;
using Carbon.Json.Matchmaking;

using OpenlabsSDKV1.Core.Async;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.Interfaces
{
    internal interface IGameSessionsBackend
    {
        [BackendMethod(IsAuthorized = true)]
        IPromise<MatchmakingJoinResult> JoinRandom(AccessToken accessToken, JoinRandomGameSessionRequest request);

        [BackendMethod(IsAuthorized = true)]
        IPromise<MatchmakingJoinResult> JoinPlayer(AccessToken accessToken, JoinPlayerRequest request);

        [BackendMethod(IsAuthorized = true)]
        IPromise<MatchmakingJoinResult> JoinRoom(AccessToken accessToken, JoinRoomRequest request);

        [BackendMethod(IsAuthorized = true)]
        IPromise<MatchmakingJoinResult> Create(AccessToken accessToken, CreateCustomGameSessionRequest request);
    }
}
