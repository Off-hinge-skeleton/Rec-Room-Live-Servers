﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Attributes;
using Carbon.Json;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.Interfaces
{
    internal interface IGiftsBackend
    {
        [BackendMethod(IsAuthorized = true)]
        IPromise<List<GiftPackage>> GetGifts(AccessToken accessToken);

        void NonBackend_AddGift(AccessToken accessToken, GiftPackage gift);
        void NonBackend_ConsumeGift(AccessToken accessToken, long giftPackageId);
        void NonBackend_RemoveGift(AccessToken accessToken, long giftPackageId);
    }
}
