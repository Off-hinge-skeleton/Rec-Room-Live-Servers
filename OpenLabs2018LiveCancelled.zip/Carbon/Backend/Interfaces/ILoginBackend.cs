﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Attributes;
using Carbon.Json;
using OpenlabsSDKV1.Core.Async;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.Interfaces
{
    internal interface ILoginBackend
    {
        [BackendMethod(IsAuthorized = false)]
        IReadOnlyList<Profile> GetCachedLogins(PlatformType platform, string platformId);

        [BackendMethod(IsAuthorized = false)]
        IPromise<LoginResponse> LoginToCachedAccount(LoginToCachedProfileRequest request);

        [BackendMethod(IsAuthorized = false)]
        IPromise Logout(AccessToken accessToken);

        [BackendMethod(IsAuthorized = false)]
        IPromise<Profile> GetProfile(AccessToken accessToken, long playerId);

        [BackendMethod(IsAuthorized = false)]
        IPromise UpdateProfile(AccessToken accessToken, Profile profile);

        [BackendMethod(IsAuthorized = false)]
        IPromise<List<Profile>> ListProfiles(AccessToken accessToken, long[] profileIds);
    }
}
