﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Attributes;
using Carbon.Json;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.Interfaces
{
    internal interface IMessagesBackend
    {
        [BackendMethod(IsAuthorized = true)]
        IPromise<List<NotificationMessage>> GetNotificationMessages(AccessToken accessToken);

        void NonBackend_AddMessage(AccessToken accessToken, NotificationMessage message);
        void NonBackend_RemoveMessagesBulk(AccessToken accessToken, long[] messageIds);
        void NonBackend_RemoveMessage(AccessToken accessToken, long messageId);
        List<NotificationMessage> NonBackend_GetMessages(AccessToken accessToken);
    }
}
