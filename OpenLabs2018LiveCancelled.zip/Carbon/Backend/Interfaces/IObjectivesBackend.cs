﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Attributes;
using Carbon.Json;
using Carbon.Json.Checklist;
using OpenlabsSDKV1.Core.Async;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.Interfaces
{
    internal interface IObjectivesBackend
    {
        [BackendMethod(IsAuthorized = true)]
        IPromise<ObjectiveProgress> GetProgress(AccessToken accessToken);

        [BackendMethod(IsAuthorized = true)]
        IPromise<List<ChecklistIndex>> GetChecklist(AccessToken accessToken);

        [BackendMethod(IsAuthorized = true)]
        IPromise<RecNetResult> GetWeeklyChallenge(AccessToken accessToken);
    }
}
