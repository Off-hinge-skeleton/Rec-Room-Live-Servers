﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Attributes;
using Carbon.Json;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.Interfaces
{
    internal interface IPlayerSubscriptionsBackend
    {
        [BackendMethod(IsAuthorized = true)]
        IPromise InitializeSubscriptions(AccessToken accessToken);

        [BackendMethod(IsAuthorized = true)]
        IPromise<List<PlayerSubscription>> GetSubscriptions(AccessToken accessToken);

        void NonBackend_SubscribeToPlayer(AccessToken accessToken, long playerId);
        void NonBackend_UnsubscribeFromPlayer(AccessToken accessToken, long playerId);
    }
}
