﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Attributes;
using Carbon.Json;
using Carbon.Json.Matchmaking;
using OpenlabsSDKV1.Core.Async;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.Interfaces
{
    internal interface IPresenceBackend
    {
        [BackendMethod(IsAuthorized = true)]
        IPromise SetScreenMode(AccessToken accessToken, bool screenMode);

        void NonBackend_SetPlayerPresenseOnline(AccessToken accessToken, bool isOnline);
        void NonBackend_SetPlayerPresenseScreenMode(AccessToken accessToken, bool inScreenMode);
        void NonBackend_SetPlayerPresenseGameSession(AccessToken accessToken, GameSession gameSession);
        PlayerPresence NonBackend_GetPlayerPresence(AccessToken accessToken);
        PlayerPresence NonBackend_GetPlayerPresence(long playerId);
        List<PlayerPresence> NonBackend_GetPlayerPresences(List<long> playerIds);
        void NonBackend_SetPlayerPresence(AccessToken accessToken, bool isOnline = false, bool inScreenMode = false, GameSession gameSession = null);
        void NonBackend_RemovePlayerPresence(AccessToken accessToken);
    }
}
