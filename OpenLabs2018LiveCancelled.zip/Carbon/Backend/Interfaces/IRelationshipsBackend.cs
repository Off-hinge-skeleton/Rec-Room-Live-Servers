﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Attributes;
using Carbon.Json;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.Interfaces
{
    internal interface IRelationshipsBackend
    {
        [BackendMethod(IsAuthorized = true)]
        IPromise<List<Relationship>> GetFriends(AccessToken accessToken);

        [BackendMethod(IsAuthorized = true)]
        IPromise SendFriendRequest(AccessToken accessToken, long toPlayerId);

        [BackendMethod(IsAuthorized = true)]
        IPromise AcceptFriendRequest(AccessToken accessToken, long toPlayerId);

        [BackendMethod(IsAuthorized = true)]
        IPromise AddFriend(AccessToken accessToken, long playerId);

        [BackendMethod(IsAuthorized = true)]
        IPromise RemoveFriend(AccessToken accessToken, long playerId);

        List<Relationship> NonBackend_GetRelationships(AccessToken accessToken);
        Relationship NonBackend_GetRelationship(AccessToken accessToken, long playerId);
        void NonBackend_AddRelationship(AccessToken accessToken, Relationship relationship);
        void NonBackend_ChangeRelationship(
            AccessToken accessToken,
            long playerId,
            RelationshipType? relationshipType = null,
            ReciprocalStatus? muted = null,
            ReciprocalStatus? ignored = null,
            ReciprocalStatus? favorited = null);
        void NonBackend_ChangeRelationshipType(AccessToken accessToken, long playerId, RelationshipType relationshipType);
        void NonBackend_ChangeRelationshipMuted(AccessToken accessToken, long playerId, ReciprocalStatus muted);
        void NonBackend_ChangeRelationshipIgnored(AccessToken accessToken, long playerId, ReciprocalStatus ignored);
        void NonBackend_ChangeRelationshipFavorited(AccessToken accessToken, long playerId, ReciprocalStatus favorited);

        void NonBackend_NotifyPlayerAboutRelationship(AccessToken accessToken, Relationship relationship);
    }
}
