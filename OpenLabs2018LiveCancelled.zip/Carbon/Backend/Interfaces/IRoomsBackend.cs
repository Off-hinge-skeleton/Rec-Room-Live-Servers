﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Attributes;
using Carbon.Json.Rooms;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.Interfaces
{
    public enum RoomSortType
    {
        Hot_Legacy,
        Visitors,
        Cheers,
        CurrentPlayerCount,
        MostRecentlyUpdated,
        Hot_Daily = 10
    }

    internal interface IRoomsBackend
    {
        [BackendMethod(IsAuthorized = true)]
        IPromise<List<Room>> GetMyRooms(AccessToken accessToken);

        [BackendMethod(IsAuthorized = true)]
        IPromise<RoomDetails> GetRoomDetails(AccessToken accessToken, long roomId);

        [BackendMethod(IsAuthorized = true)]
        IPromise<RoomDetailsCombine> GetRoomDetailsCombine(AccessToken accessToken, long roomId);

        [BackendMethod(IsAuthorized = true)]
        IPromise<List<Room>> BrowseRooms(AccessToken accessToken, RoomSortType sortType, int skip, int take);

        [BackendMethod(IsAuthorized = true)]
        IPromise<ModifyRoomDetailsResponse> ModifyRoomName(AccessToken accessToken, ModifyNameRequest request);

        [BackendMethod(IsAuthorized = true)]
        IPromise<ModifyRoomDetailsResponse> ModifyImageName(AccessToken accessToken, ModifyImageNameRequest request);

        [BackendMethod(IsAuthorized = true)]
        IPromise<ModifyRoomDetailsResponse> ModifyMaxPlayers(AccessToken accessToken, ModifyMaxPlayersRequest request);

        [BackendMethod(IsAuthorized = true)]
        IPromise<ModifyRoomDetailsResponse> ModifyDescription(AccessToken accessToken, ModifyDescriptionRequest request);

        [BackendMethod(IsAuthorized = true)]
        IPromise<ModifyRoomDetailsResponse> ModifyScreenMode(AccessToken accessToken, ModifyScreenModeRequest request);

        [BackendMethod(IsAuthorized = true)]
        IPromise<ModifyRoomDetailsResponse> ModifyInstanced(AccessToken accessToken, ModifyInstancedRequest request);

        [BackendMethod(IsAuthorized = true)]
        IPromise<ModifyRoomDetailsResponse> ModifyDataBlob(AccessToken accessToken, long roomId, string dataBlob);

        [BackendMethod(IsAuthorized = true)]
        IPromise<RoomDetailsCombine> SaveRoom(AccessToken accessToken, long roomId, byte[] formData);

        [BackendMethod(IsAuthorized = true)]
        IPromise InitializeDormRoom(AccessToken accessToken);

        [BackendMethod(IsAuthorized = true)]
        IPromise UpdateRoom(AccessToken accessToken, Room room);

        void NonBackend_AddRoom(AccessToken accessToken, Room room);
        List<Room> NonBackend_GetRooms(AccessToken accessToken);

        bool NonBackend_HasDormRoom(AccessToken accessToken);
        Room NonBackend_GetDormRoom(AccessToken accessToken);

        Room NonBackend_GetRoom(AccessToken accessToken, long roomId);
        RoomDetails NonBackend_GetRoomDetails(AccessToken accessToken, long roomId);
        RoomDetailsCombine NonBackend_GetRoomDetailsCombine(AccessToken accessToken, long roomId);
        List<Room> NonBackend_BrowseRooms(AccessToken accessToken, RoomSortType sortType, int skip, int take);
    }
}
