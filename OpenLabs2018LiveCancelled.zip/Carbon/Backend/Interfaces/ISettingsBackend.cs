﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Attributes;
using Carbon.Json;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.Interfaces
{
    internal interface ISettingsBackend
    {
        [BackendMethod(IsAuthorized = true)]
        IPromise<List<Setting>> GetSettings(AccessToken accessToken);

        [BackendMethod(IsAuthorized = true)]
        IPromise SetOrAddSetting(AccessToken accessToken, Setting setting);
    }
}
