﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Attributes;
using Carbon.Json.Storefronts;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.Interfaces
{
    internal interface IStorefrontsBackend
    {
        [BackendMethod(IsAuthorized = true)]
        IPromise<Storefront> GetStorefront(AccessToken accessToken, StorefrontType storefrontType);
    }
}
