﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Databasing;
using Carbon.Backend.Interfaces;
using Carbon.Backend.Statics;
using Carbon.Json;
using Carbon.Steam;
using Carbon.Utilities;
using Openlabs.Mgcxm.Common.JsonMapping;
using Openlabs.Mgcxm.Internal;
using OpenlabsSDKV1.Core;
using OpenlabsSDKV1.Core.Async;

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend
{
    internal sealed class Login : IBackendProvider, ILoginBackend
    {
        public IPromise Initialize() => new Promise(action =>
        {
            Singleton.Allocate(this);
            action.Resolve();
        });

        public IPromise Cleanup() => new Promise(action =>
        {
            Singleton.Free<Login>();
            action.Resolve();
        });

        public Profile getUserProfile(long id)
        {
            var Players = GetAllPlayers();
            foreach (var Player in Players)
            {
                if (Player.Id == id)
                {
                    return Player;
                }

            }
            return Profile.Empty;
        }

        public IReadOnlyList<Profile> GetCachedLogins(PlatformType platform, string platformId)
        {
            if (!Database.ProfileDatabase.Exists(platformId))
                return new List<Profile>(0);
            return Database.ProfileDatabase.ReadGeneric<List<Profile>>(platformId);
        }

        public IReadOnlyList<Profile> GetAllPlayers()
        {
            var playerLists = Database.ProfileDatabase.ReadAllGeneric<List<Profile>>();
            List<Profile> players = new List<Profile>();

            foreach (var playerList in playerLists)
                foreach (var player in playerList)
                    players.Add(player);

            return players;
        }

        public IPromise<LoginResponse> LoginToCachedAccount(LoginToCachedProfileRequest request) => new Promise<LoginResponse>(action =>
        {
            var cachedLogins = GetCachedLogins(request.Platform, request.PlatformId);
            Logger.Info(request.PlayerId.ToString());
            
            var cachedLogin = cachedLogins.FirstOrDefault(profile => profile.Id == request.PlayerId, Profile.Empty);

            Logger.Info(cachedLogin.ToJson());
            var accessToken = AccessToken.CreateFromProfile(cachedLogin);

            var presenceBackend = BackendService.GetBackend<Presence>();
            presenceBackend.NonBackend_SetPlayerPresence(accessToken, false, false, null);

            var loginResponse = new LoginResponse
            {
                Error = "",
                Player = accessToken.Profile,
                Token = accessToken.EncodedToken,
                FirstLoginOfTheDay = false,
                AnalyticsSessionId = 0,
                CanUseScreenMode = true
            };
            action.Resolve(loginResponse);
        });

        public IPromise Logout(AccessToken accessToken) => new Promise(action =>
        {
            var presenceBackend = BackendService.GetBackend<Presence>();
            presenceBackend.NonBackend_SetPlayerPresenseOnline(accessToken, false);
            presenceBackend.NonBackend_SetPlayerPresenseGameSession(accessToken, null);

            var playerSubscriptionsBackend = BackendService.GetBackend<PlayerSubscriptions>();
            playerSubscriptionsBackend.NonBackend_ReportStatusToSubscribers(accessToken);

            accessToken.Invalidate();
            action.Resolve();
        });

        public IPromise<Profile> GetProfile(AccessToken accessToken, long playerId) => new Promise<Profile>(action =>
        {
            try
            {
                ListProfiles(accessToken, new long[] { playerId }).Then(profiles =>
                {
                    if (profiles.Any())
                        action.Resolve(profiles[0]);
                    else
                        action.Reject(Error.Create(7, "Failed to get profile"));

                }).Catch(ex =>
                {
                    Logger.Exception("Failed to get profile", new Exception(ex.ToString()));
                    action.Resolve(null!);
                });
            }
            catch (Exception ex)
            {
                Logger.Exception("Failed to get profile", ex);
                action.Resolve(null!);
            }
        });

        public IPromise UpdateProfile(AccessToken accessToken, Profile profile) => new Promise(action =>
        {
            try
            {
                var cachedProfiles = (List<Profile>)GetCachedLogins(PlatformType.STEAM, profile.PlatformId.Id);
                for (int i = 0; i < cachedProfiles.Count; i++)
                {
                    if (cachedProfiles[i].Id == profile.Id)
                    {
                        cachedProfiles[i].ModifyProperties(profile);
                    }
                }
                Database.ProfileDatabase.WriteGeneric(profile.PlatformId.Id, cachedProfiles);

                action.Resolve();
            }
            catch (Exception ex)
            {
                Logger.Exception("Failed to update profile", ex);
                action.Reject(Error.Create(15, ex.Message, "TRY_CATCH_STATEMENT"));
            }
        });

        public IPromise<List<Profile>> ListProfiles(AccessToken accessToken, long[] profileIds) => new Promise<List<Profile>>(action =>
        {
            List<Profile> profiles = new List<Profile>();
            foreach (var profileList in Database.ProfileDatabase.ReadAllGeneric<List<Profile>>())
                foreach (var profile in profileList)
                    if (profileIds.Contains(profile.Id))
                        profiles.Add(profile);
            action.Resolve(profiles);
        });

        public string FriendlyName => "Login Backend";
    }
}
