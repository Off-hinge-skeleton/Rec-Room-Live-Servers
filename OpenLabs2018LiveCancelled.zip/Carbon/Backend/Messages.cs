﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Databasing;
using Carbon.Backend.Interfaces;
using Carbon.Json;
using Carbon.Json.Notifications;
using Carbon.Servers;
using Carbon.Utilities;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend
{
    internal class Messages : IBackendProvider, IMessagesBackend
    {
        public IPromise Initialize() => new Promise(action =>
        {
            Singleton.Allocate(this);
            action.Resolve();
        });

        public IPromise Cleanup() => new Promise(action =>
        {
            Singleton.Free<Messages>();
            action.Resolve();
        });

        public IPromise<List<NotificationMessage>> GetNotificationMessages(AccessToken accessToken) => new Promise<List<NotificationMessage>>(action =>
        {
            action.Resolve(NonBackend_GetMessages(accessToken));
        });

        public void NonBackend_AddMessage(AccessToken accessToken, NotificationMessage message)
        {
            var handler = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(accessToken.PlayerId).Handler;
            var messages = NonBackend_GetMessages(accessToken);
            messages.Add(message);

            Database.NotificationsDatabase.WriteGeneric(accessToken.PlatformId, messages);
            handler.SendNotificationBulk(new PushNotificationDto<NotificationMessage>
            {
                Id = PushNotificationId.MessageReceived,
                Msg = message
            });
        }

        public void NonBackend_RemoveMessagesBulk(AccessToken accessToken, long[] messageIds)
        {
            var handler = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(accessToken.PlayerId).Handler;
            var messages = NonBackend_GetMessages(accessToken);
            foreach (var messageId in messageIds)
            {
                messages.RemoveAll(x => x.Id == messageId);
                handler.SendNotificationBulk(new PushNotificationObject
                {
                    Id = PushNotificationId.MessageReceived,
                    Msg = new { Id = messageId }
                });
            }

            Database.NotificationsDatabase.WriteGeneric(accessToken.PlatformId, messages);
        }

        public void NonBackend_RemoveMessage(AccessToken accessToken, long messageId)
        {
            var messages = NonBackend_GetMessages(accessToken);
            messages.RemoveAll(x => x.Id == messageId);

            Database.NotificationsDatabase.WriteGeneric(accessToken.PlatformId, messages);
        }

        public List<NotificationMessage> NonBackend_GetMessages(AccessToken accessToken)
        {
            if (!Database.NotificationsDatabase.Exists(accessToken.PlatformId))
            {
                var initializedList = new List<NotificationMessage>()
                {
                    NotificationMessage.Create(
                            fromPlayerId: 1,
                            messageType: NotificationMessageType.CoachMessage,
                            data: "Welcome to Openlabs! We hope you have fun playing on our servers!"
                        )
                };

                Database.NotificationsDatabase.WriteGeneric(accessToken.PlatformId, initializedList);
                return initializedList;
            }
            else
                return Database.NotificationsDatabase.ReadGeneric<List<NotificationMessage>>(accessToken.PlatformId);
        }

        public string FriendlyName => "Messages Backend";
    }
}
