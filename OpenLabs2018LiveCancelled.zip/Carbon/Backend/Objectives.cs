﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Interfaces;
using Carbon.Json;
using Carbon.Json.Challenges;
using Carbon.Json.Checklist;
using Carbon.Utilities;
using Newtonsoft.Json;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend
{
    internal class Objectives : IBackendProvider, IObjectivesBackend
    {
        public IPromise Initialize() => new Promise(action =>
        {
            Singleton.Allocate(this);
            action.Resolve();
        });

        public IPromise Cleanup() => new Promise(action =>
        {
            Singleton.Free<Objectives>();
            action.Resolve();
        });

        public IPromise<ObjectiveProgress> GetProgress(AccessToken accessToken) => new Promise<ObjectiveProgress>(action =>
        {
            action.Resolve(new ObjectiveProgress
            {
                Objectives = new List<ObjectiveProgressIndex>(),
                ObjectiveGroups = new List<ObjectiveProgressGroup>()
            });
        });

        public IPromise<List<ChecklistIndex>> GetChecklist(AccessToken accessToken) => new Promise<List<ChecklistIndex>>(action =>
        {
            action.Resolve(new List<ChecklistIndex>() { });
        });

        public IPromise<RecNetResult> GetWeeklyChallenge(AccessToken accessToken) => new Promise<RecNetResult>(action =>
        {
            var serverTime = DateTime.Now;
            var challengeMap = new ChallengeMap
            {
                ChallengeMapId = 1,
                CompleteAll = false,
                StartAt = serverTime.AddDays(-2),
                EndAt = serverTime.AddDays(5),
                ServerTime = serverTime,

                Challenges = new RecNetChallenge[3] {
                    new RecNetChallenge { ChallengeId = 0, Complete = false, Name = "Complete Objective 1", Config = "", Description = "", Tooltip = "" },
                    new RecNetChallenge { ChallengeId = 1, Complete = false, Name = "Complete Objective 2", Config = "", Description = "", Tooltip = "" },
                    new RecNetChallenge { ChallengeId = 2, Complete = false, Name = "Complete Objective 3", Config = "", Description = "", Tooltip = "" } },
                
                Gifts = new RecNetGiftDrop[1] {
                    new RecNetGiftDrop 
                    { GiftDropId = 1023,
                    GiftContext = GiftContext.All_Weekly_Challenge_Complete,
                    EquipmentModificationGuid = "",
                    EquipmentPrefabName = "",
                    GiftRarity = GiftRarity.Legendary,
                    AvatarItemDesc = "",
                    ConsumableItemDesc = "",
                    Level = 1,
                    StorefrontType = Json.Storefronts.StorefrontType.RecCenter,
                    Xp = 0
                    } },

                ChallengeThemeId = 1,
                ChallengeThemeString = "Default"
            };

            action.Resolve(new RecNetResult
            {
                Success = true,
                Message = JsonConvert.SerializeObject(challengeMap)
            });
        });

        public bool checkTime(DateTime time, int interval)
        {
            var nextTime = time.AddDays(interval);
            
            if (DateTime.UtcNow > nextTime)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        

        public string FriendlyName => "Objectives Backend";
    }
}
