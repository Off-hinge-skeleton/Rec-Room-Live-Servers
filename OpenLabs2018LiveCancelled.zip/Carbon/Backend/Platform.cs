﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend
{
    internal static class Platform
    {
    }

    public enum PlatformType
    {
        STEAM,
        OCULUS,
        PS4,
        MICROSOFT,
        LINUX_HEADLESS_BOT
    }
}
