﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Databasing;
using Carbon.Backend.Interfaces;
using Carbon.Json;
using Carbon.Utilities;
using Openlabs.Mgcxm.Common.JsonMapping;
using Openlabs.Mgcxm.Net;
using OpenlabsSDKV1.Cloud.Json;
using OpenlabsSDKV1.Core;
using OpenlabsSDKV1.Core.Async;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend
{
    internal class PlayerReporting : IBackendProvider, IPlayerReportingBackend
    {
        public IPromise Initialize() => new Promise(action =>
        {
            Singleton.Allocate(this);
            action.Resolve();
        });

        public IPromise Cleanup() => new Promise(action =>
        {
            Singleton.Free<PlayerReporting>();
            action.Resolve();
        });


        
        public ModerationBlockDetail GetModerationBlockDetail(AccessToken accessToken)
        {
            var details = new ModerationBlockDetail();

            if (!Database.BanishmentDatabase.Exists(accessToken.PlatformId))
            {

                details = new ModerationBlockDetail
                {
                    Duration = 0,
                    GameSessionId = -1,
                    Message = "",
                    ReportCategory = ReportCategory.Unknown,
                    EndTime = null
                };

                Database.BanishmentDatabase.WriteGeneric<ModerationBlockDetail>(accessToken.PlatformId, details);

                return details;
            }

            else
            {
                details = Database.BanishmentDatabase.ReadGeneric<ModerationBlockDetail>(accessToken.PlatformId);

                if (details.EndTime != null)
                {
                    TimeSpan timeSpan = details.EndTime.Value.Subtract(DateTime.UtcNow);
                    int new_duration = Convert.ToInt32(timeSpan.TotalSeconds);


                    if (details.EndTime.Value < DateTime.UtcNow)
                    {
                        details = new ModerationBlockDetail()
                        {
                            Duration = 0,
                            EndTime = null,
                            ReportCategory = ReportCategory.Unknown,
                            GameSessionId = -1,
                            Message = ""
                        };

                        Database.BanishmentDatabase.WriteGeneric<ModerationBlockDetail>(accessToken.PlatformId, details);
                    }
                    else
                    {
                        details.Duration = int.Parse(new_duration.ToString());
                        Database.BanishmentDatabase.WriteGeneric<ModerationBlockDetail>(accessToken.PlatformId, details);
                    }
                }

            }
            
            return details;
        }
       

        public void SetBlockDetails(AccessToken accessToken, ModerationBlockDetail blockDetail)
        {
            
          Database.BanishmentDatabase.WriteGeneric<ModerationBlockDetail>(accessToken.PlatformId, blockDetail);

        }

        public IPromise CreateReport(AccessToken accessToken)
        {
            throw new NotImplementedException();
        }

        public string FriendlyName => "Player Reporting Backend";
    }

    public class VoteKickResponse
    {
        public long PlayerId { get; set; }
        public bool Response { get; set; }
        public long GameSessionId { get; set; }
    }
}
