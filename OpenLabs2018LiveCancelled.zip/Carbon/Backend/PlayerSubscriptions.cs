﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Attributes;
using Carbon.Backend.Databasing;
using Carbon.Backend.Interfaces;
using Carbon.Backend.Statics;
using Carbon.Json;
using Carbon.Json.Notifications;
using Carbon.Servers;
using Carbon.Utilities;
using Newtonsoft.Json;
using Openlabs.Mgcxm.Internal;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend
{
    internal class PlayerSubscriptions : IBackendProvider, IPlayerSubscriptionsBackend
    {
        public IPromise Initialize() => new Promise(action =>
        {
            Singleton.Allocate(this);
            action.Resolve();
        });

        public IPromise Cleanup() => new Promise(action =>
        {
            Singleton.Free<PlayerSubscriptions>();
            action.Resolve();
        });

        public IPromise InitializeSubscriptions(AccessToken accessToken) => new Promise(action =>
        {
            if (!_subscriptions.ContainsKey(accessToken.PlayerId))
                _subscriptions.Add(accessToken.PlayerId, new List<PlayerSubscription>());
            else _subscriptions[accessToken.PlayerId] = new List<PlayerSubscription>();
        });

        public IPromise<List<PlayerSubscription>> GetSubscriptions(AccessToken accessToken) => new Promise<List<PlayerSubscription>>(action =>
        {
            if (!Database.SubscriptionsDatabase.Exists(accessToken.PlatformId))
            {
                var initializedList = new List<PlayerSubscription>();

                Database.SubscriptionsDatabase.WriteGeneric(accessToken.PlatformId, initializedList);
                action.Resolve(initializedList);
            }
            else
                action.Resolve(Database.SubscriptionsDatabase.ReadGeneric<List<PlayerSubscription>>(accessToken.PlatformId));
        });

        public void NonBackend_ReportStatusToSubscribers(AccessToken accessToken)
        {
            var presenceBackend = BackendService.GetBackend<Presence>();
            var loginBackend = BackendService.GetBackend<Login>();

            GetSubscriptions(accessToken).Then(subscriptions =>
            {
                var notificationsServer = Singleton<NotificationsServer>.Instance;
                foreach (var subscription in subscriptions)
                {
                    var connectionNode = notificationsServer.NotificationConnectionTree.GetNode(subscription.PlayerId);
                    if (connectionNode.Handler != null)
                    {
                        var presence = presenceBackend.NonBackend_GetPlayerPresence(subscription.PlayerId);
                        Logger.Warning("Sending notification to " + subscription.PlayerId + ": " + JsonConvert.SerializeObject(presence));

                        connectionNode.Handler.SendNotificationBulk(new PushNotificationDto<PlayerPresence>
                        {
                            Id = PushNotificationId.SubscriptionUpdatePresence,
                            Msg = presence
                        }, new PushNotificationDto<Profile>
                        {
                            Id = PushNotificationId.SubscriptionUpdateProfile,
                            Msg = accessToken.Profile
                        });
                    }
                }
            });
        }

        public void NonBackend_SubscribeToPlayer(AccessToken accessToken, long playerId)
        {
            GetSubscriptions(accessToken)
                .Then(subscriptions =>
                {
                    if (subscriptions.Any(x => x.PlayerId == playerId)) return;

                    subscriptions.Add(new PlayerSubscription
                    {
                        PlayerId = playerId,
                    });
                    var loginLockToken = accessToken.GetOTT("LoginLockToken").TokenString;

                    var connectionHandler = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(loginLockToken).Handler;
                    connectionHandler.SendNotificationBulk(new PushNotificationDto<PlayerSubscriptionList>
                    {
                        Id = PushNotificationId.SubscriptionListUpdated,
                        Msg = new PlayerSubscriptionList
                        {
                            PlayerIds = (from x in subscriptions
                                         select x.PlayerId).ToList(),
                        }
                    });
                });
        }

        public void NonBackend_UnsubscribeFromPlayer(AccessToken accessToken, long playerId)
        {
            GetSubscriptions(accessToken)
                .Then(subscriptions =>
                {
                    if (!subscriptions.Any(x => x.PlayerId == playerId)) return;

                    subscriptions.RemoveAll(x => x.PlayerId == playerId);
                    var loginLockToken = accessToken.GetOTT("LoginLockToken").TokenString;

                    var connectionHandler = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(loginLockToken).Handler;
                    connectionHandler.SendNotificationBulk(new PushNotificationDto<PlayerSubscriptionList>
                    {
                        Id = PushNotificationId.SubscriptionListUpdated,
                        Msg = new PlayerSubscriptionList
                        {
                            PlayerIds = (from x in subscriptions
                                         select x.PlayerId).ToList(),
                        }
                    });
                });
        }

        public IReadOnlyDictionary<long, List<PlayerSubscription>> Subscriptions => _subscriptions;
        [Cascaded] private Dictionary<long, List<PlayerSubscription>> _subscriptions = new Dictionary<long, List<PlayerSubscription>>();
        public string FriendlyName => "Player Subscriptions Backend";
    }
}
