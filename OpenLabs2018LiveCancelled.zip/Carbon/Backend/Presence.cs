﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Interfaces;
using Carbon.Json;
using Carbon.Json.Matchmaking;
using Carbon.Utilities;
using Openlabs.Mgcxm.Assets;
using OpenlabsSDKV1.Core;
using OpenlabsSDKV1.Core.Async;
using Steamworks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend
{
    internal class Presence : IBackendProvider, IPresenceBackend
    {
        public IPromise Initialize() => new Promise(action =>
        {
            Singleton.Allocate(this);
            action.Resolve();
        });

        public IPromise Cleanup() => new Promise(action =>
        {
            Singleton.Free<Presence>();
            action.Resolve();
        });

        public IPromise SetScreenMode(AccessToken accessToken, bool screenMode) => new Promise(action =>
        {
            NonBackend_SetPlayerPresenseScreenMode(accessToken, screenMode);
            action.Resolve();
        });

        public void NonBackend_SetPlayerPresenseOnline(AccessToken accessToken, bool isOnline)
        {
            var presence = NonBackend_GetPlayerPresence(accessToken);
            NonBackend_SetPlayerPresence(accessToken, isOnline, presence.InScreenMode, presence.GameSession);
        }

        public void NonBackend_SetPlayerPresenseScreenMode(AccessToken accessToken, bool inScreenMode)
        {
            var presence = NonBackend_GetPlayerPresence(accessToken);
            NonBackend_SetPlayerPresence(accessToken, presence.IsOnline, inScreenMode, presence.GameSession);
        }

        public void NonBackend_SetPlayerPresenseGameSession(AccessToken accessToken, GameSession gameSession)
        {
            var presence = NonBackend_GetPlayerPresence(accessToken);
            NonBackend_SetPlayerPresence(accessToken, presence.IsOnline, presence.InScreenMode, gameSession);
        }

        public void NonBackend_SetPlayerPresence(
            AccessToken accessToken, 
            [Optional] bool isOnline, 
            [Optional] bool inScreenMode, 
            [Optional] GameSession gameSession)
        {
            if (_presences.Any(x => x.Key == accessToken.Profile.Id))
            {
                var currentPresence = _presences[accessToken.PlayerId];
                currentPresence.IsOnline = isOnline;
                currentPresence.InScreenMode = inScreenMode;
                currentPresence.GameSession = gameSession;

                _presences[accessToken.PlayerId] = currentPresence;
            }
            else
            {
                _presences.Add(accessToken.PlayerId, new PlayerPresence
                {
                    PlayerId = accessToken.PlayerId,
                    IsOnline = isOnline,
                    InScreenMode = inScreenMode,
                    GameSession = gameSession
                });
            }
        }

        public PlayerPresence NonBackend_GetPlayerPresence(AccessToken accessToken)
        {
            if (_presences.Any(x => x.Key == accessToken.Profile.Id))
                return _presences[accessToken.PlayerId];
            return null;
        }

        public PlayerPresence NonBackend_GetPlayerPresence(long playerId)
        {
            if (_presences.Any(x => x.Key == playerId))
                return _presences[playerId];
            return null;
        }

        public List<PlayerPresence> NonBackend_GetPlayerPresences(List<long> playerIds)
        {
            List<PlayerPresence> presences = new List<PlayerPresence>();
            foreach (var playerId in playerIds)
            {
                if (_presences.Any(x => x.Key == playerId))
                    presences.Add(_presences[playerId]);
            }
            return presences;
        }

        public void NonBackend_RemovePlayerPresence(AccessToken accessToken)
        {
            if (_presences.Any(x => x.Key == accessToken.Profile.Id))
                _presences.Remove(accessToken.Profile.Id);
        }

        public IReadOnlyDictionary<long, PlayerPresence> AllPresences => _presences;
        private Dictionary<long, PlayerPresence> _presences = new Dictionary<long, PlayerPresence>();

        public string FriendlyName => "Presence Backend";
    }
}
