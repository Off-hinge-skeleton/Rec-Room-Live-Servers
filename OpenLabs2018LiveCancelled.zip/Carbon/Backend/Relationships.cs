﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Databasing;
using Carbon.Backend.Interfaces;
using Carbon.Json;
using Carbon.Json.Notifications;
using Carbon.Servers;
using Carbon.Utilities;
using OpenlabsSDKV1.Core;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend
{
    internal class Relationships : IBackendProvider, IRelationshipsBackend
    {
        public IPromise Initialize() => new Promise(action =>
        {
            Singleton.Allocate(this);
            action.Resolve();
        });

        public IPromise Cleanup() => new Promise(action =>
        {
            Singleton.Free<Relationships>();
            action.Resolve();
        });

        public IPromise<List<Relationship>> GetFriends(AccessToken accessToken) => new Promise<List<Relationship>>(action =>
        {
            action.Resolve(NonBackend_GetRelationships(accessToken));
        });

        public IPromise SendFriendRequest(AccessToken accessToken, long toPlayerId) => new Promise(action =>
        {
            if (accessToken.PlayerId == toPlayerId)
            {
                action.Reject(Error.Create(5, "You cannot friend yourself."));
                return;
            }

            Singleton<Login>.Instance.GetProfile(accessToken, toPlayerId).Then(profile =>
            {
                var toPlayerIdAccessToken = AccessToken.CreateFake(profile.Id, profile.PlatformId.Id);

                NonBackend_ChangeRelationship(toPlayerIdAccessToken,
                    accessToken.PlayerId,
                    RelationshipType.FriendRequestReceived);

                NonBackend_ChangeRelationship(accessToken,
                    toPlayerIdAccessToken.PlayerId,
                    RelationshipType.FriendRequestSent);

                Singleton<Messages>.Instance.NonBackend_AddMessage(toPlayerIdAccessToken, NotificationMessage.Create(accessToken.PlayerId, NotificationMessageType.FriendInvite));
                action.Resolve();
            }).Catch(action.Reject);
        });

        

        public IPromise AcceptFriendRequest(AccessToken accessToken, long toPlayerId) => new Promise(action =>
        {
            if (accessToken.PlayerId == toPlayerId)
            {
                action.Reject(Error.Create(5, "You cannot friend yourself."));
                return;
            }

            Singleton<Login>.Instance.GetProfile(accessToken, toPlayerId).Then(profile =>
            {
                var toPlayerIdAccessToken = AccessToken.CreateFake(profile.Id, profile.PlatformId.Id);
                var friendRelationship = NonBackend_GetRelationship(accessToken, toPlayerIdAccessToken.PlayerId);
                var myRelationship = NonBackend_GetRelationship(toPlayerIdAccessToken, accessToken.PlayerId);

                bool bothPartiesHaveRequest = (friendRelationship != null && friendRelationship.RelationshipType != RelationshipType.FriendRequestSent) &&
                                              (myRelationship != null && myRelationship.RelationshipType != RelationshipType.FriendRequestReceived);

                if (!bothPartiesHaveRequest)
                {
                    action.Reject(Error.Create(5, "Cannot send friend request"));
                    return;
                }

                NonBackend_ChangeRelationship(toPlayerIdAccessToken,
                    accessToken.PlayerId,
                    RelationshipType.Friend);

                NonBackend_ChangeRelationship(accessToken,
                    toPlayerId,
                    RelationshipType.Friend);

                Singleton<Messages>.Instance.NonBackend_AddMessage(accessToken, NotificationMessage.Create(toPlayerIdAccessToken.PlayerId, NotificationMessageType.FriendRequestAccepted));
                action.Resolve();
            }).Catch(action.Reject);
        });

        public IPromise AddFriend(AccessToken accessToken, long playerId) => new Promise(action =>
        {
            if (accessToken.PlayerId == playerId)
            {
                action.Reject(Error.Create(5, "You cannot friend yourself."));
                return;
            }

            Singleton<Login>.Instance.GetProfile(accessToken, accessToken.PlayerId).Then(localProfile =>
            {
                Singleton<Login>.Instance.GetProfile(accessToken, playerId).Then(friendProfile =>
                {
                    var friendAccessToken = AccessToken.CreateFake(friendProfile.Id, friendProfile.PlatformId.Id);

                    var friendRelationship = NonBackend_GetRelationship(accessToken, friendAccessToken.PlayerId);
                    var myRelationship = NonBackend_GetRelationship(friendAccessToken, accessToken.PlayerId);

                    bool bothPartiesFriended = (friendRelationship != null && friendRelationship.RelationshipType == RelationshipType.Friend) &&
                                               (myRelationship != null && myRelationship.RelationshipType == RelationshipType.Friend);

                    if (bothPartiesFriended)
                    {
                        action.Reject(Error.Create(5, "Cannot add friend"));
                        return;
                    }

                    NonBackend_ChangeRelationship(friendAccessToken,
                        accessToken.PlayerId,
                        RelationshipType.Friend);

                    NonBackend_ChangeRelationship(accessToken,
                        friendAccessToken.PlayerId,
                        RelationshipType.Friend);

                    action.Resolve();
                }).Catch(action.Reject);
            }).Catch(action.Reject);
        });

        public IPromise RemoveFriend(AccessToken accessToken, long playerId) => new Promise(action =>
        {
            if (accessToken.PlayerId == playerId)
            {
                action.Reject(Error.Create(5, "You cannot friend yourself."));
                return;
            }

            Singleton<Login>.Instance.GetProfile(accessToken, accessToken.PlayerId).Then(localProfile =>
            {
                Singleton<Login>.Instance.GetProfile(accessToken, playerId).Then(friendProfile =>
                {
                    var friendAccessToken = AccessToken.CreateFake(friendProfile.Id, friendProfile.PlatformId.Id);

                    var friendRelationship = NonBackend_GetRelationship(accessToken, friendAccessToken.PlayerId);
                    var myRelationship = NonBackend_GetRelationship(friendAccessToken, accessToken.PlayerId);

                    bool bothPartiesFriended = (friendRelationship != null && friendRelationship.RelationshipType == RelationshipType.Friend) &&
                                               (myRelationship != null && myRelationship.RelationshipType == RelationshipType.Friend);

                    if (!bothPartiesFriended)
                    {
                        action.Reject(Error.Create(5, "Cannot remove friend"));
                        return;
                    }

                    NonBackend_ChangeRelationship(friendAccessToken,
                        accessToken.PlayerId,
                        RelationshipType.None);

                    NonBackend_ChangeRelationship(accessToken,
                        friendAccessToken.PlayerId,
                        RelationshipType.None);

                    action.Resolve();
                }).Catch(action.Reject);
            }).Catch(action.Reject);
        });

        public List<Relationship> NonBackend_GetRelationships(AccessToken accessToken)
        {
            if (!Database.RelationshipsDatabase.Exists(accessToken.PlatformId))
            {
                var initializedList = new List<Relationship>();

                Database.RelationshipsDatabase.WriteGeneric(accessToken.PlatformId, initializedList);
                return initializedList;
            }
            else
               return Database.RelationshipsDatabase.ReadGeneric<List<Relationship>>(accessToken.PlatformId);
        }

        public Relationship NonBackend_GetRelationship(AccessToken accessToken, long playerId)
        {
            var relationships = NonBackend_GetRelationships(accessToken);
            var relationship = relationships.FirstOrDefault(x => x.PlayerID == playerId);

            if (relationship != null)
                return relationship;
            else return null!;
        }

        public void NonBackend_AddRelationship(AccessToken accessToken, Relationship relationship)
        {
            var relationships = NonBackend_GetRelationships(accessToken);
            relationships.Add(relationship);

            Database.RelationshipsDatabase.WriteGeneric(accessToken.PlatformId, relationships);
            NonBackend_NotifyPlayerAboutRelationship(accessToken, relationship);
        }

        public void NonBackend_ChangeRelationshipType(AccessToken accessToken, long playerId, RelationshipType relationshipType)
        {
            var relationships = NonBackend_GetRelationships(accessToken);
            var relationship = relationships.FirstOrDefault(x => x.PlayerID == playerId, null)!;
            var index = relationships.IndexOf(relationship);

            if (relationship != null && index > -1)
            {
                relationship.RelationshipType = relationshipType;
                Database.RelationshipsDatabase.WriteGeneric(accessToken.PlatformId, relationships);
                NonBackend_NotifyPlayerAboutRelationship(accessToken, relationship);
            }
        }

        public void NonBackend_ChangeRelationshipMuted(AccessToken accessToken, long playerId, ReciprocalStatus muted)
        {
            var relationships = NonBackend_GetRelationships(accessToken);
            var relationship = relationships.FirstOrDefault(x => x.PlayerID == playerId, null)!;
            var index = relationships.IndexOf(relationship);

            if (relationship != null && index > -1)
            {
                relationship.Mute(accessToken, muted == ReciprocalStatus.Local);
                Database.RelationshipsDatabase.WriteGeneric(accessToken.PlatformId, relationships);
                NonBackend_NotifyPlayerAboutRelationship(accessToken, relationship);
            }
        }

        public void NonBackend_ChangeRelationshipIgnored(AccessToken accessToken, long playerId, ReciprocalStatus ignored)
        {
            var relationships = NonBackend_GetRelationships(accessToken);
            var relationship = relationships.FirstOrDefault(x => x.PlayerID == playerId, null)!;
            var index = relationships.IndexOf(relationship);

            if (relationship != null && index > -1)
            {
                relationship.Block(accessToken, ignored == ReciprocalStatus.Local);
                Database.RelationshipsDatabase.WriteGeneric(accessToken.PlatformId, relationships);
                NonBackend_NotifyPlayerAboutRelationship(accessToken, relationship);
            }
        }

        public void NonBackend_ChangeRelationshipFavorited(AccessToken accessToken, long playerId, ReciprocalStatus favorited)
        {
            var relationships = NonBackend_GetRelationships(accessToken);
            var relationship = relationships.FirstOrDefault(x => x.PlayerID == playerId, null)!;
            var index = relationships.IndexOf(relationship);

            if (relationship != null && index > -1)
            {
                relationship.Favorite(accessToken, favorited == ReciprocalStatus.Local);
                Database.RelationshipsDatabase.WriteGeneric(accessToken.PlatformId, relationships);
                NonBackend_NotifyPlayerAboutRelationship(accessToken, relationship);
            }
        }

        public void NonBackend_ChangeRelationship(
            AccessToken accessToken,
            long playerId, 
            RelationshipType? relationshipType = null, 
            ReciprocalStatus? muted = null, 
            ReciprocalStatus? ignored = null, 
            ReciprocalStatus? favorited = null)
        {
            var relationships = NonBackend_GetRelationships(accessToken);
            var relationship = relationships.FirstOrDefault(x => x.PlayerID == playerId, null)!;
            var index = relationships.IndexOf(relationship);

            if (relationship != null && index > -1)
            {
                if (relationshipType.HasValue)
                    relationship.RelationshipType = relationshipType.Value;
                if (muted.HasValue)
                    relationship.Mute(accessToken, muted == ReciprocalStatus.Local);
                if (ignored.HasValue)
                    relationship.Block(accessToken, ignored == ReciprocalStatus.Local);
                if (favorited.HasValue)
                    relationship.Favorite(accessToken, favorited == ReciprocalStatus.Local);
            }
            else
            {
                if (relationshipType == null)
                    return;

                relationships.Add(new Relationship
                {
                    PlayerID = playerId,
                    RelationshipType = relationshipType.Value,
                    Muted = muted.HasValue ? muted.Value : ReciprocalStatus.None,
                    Ignored = ignored.HasValue ? ignored.Value : ReciprocalStatus.None,
                    Favorited = favorited.HasValue ? favorited.Value : ReciprocalStatus.None
                });
            }

            Database.RelationshipsDatabase.WriteGeneric(accessToken.PlatformId, relationships);
            NonBackend_NotifyPlayerAboutRelationship(accessToken, relationship);
        }

        public void NonBackend_NotifyPlayerAboutRelationship(AccessToken accessToken, Relationship relationship)
        {
            var connectionHandler = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(accessToken.PlayerId).Handler;

            // this basically means if our player is online
            if (connectionHandler != null)
            {
                connectionHandler.SendNotificationBulk(new PushNotificationDto<Relationship>
                {
                    Id = PushNotificationId.RelationshipChanged,
                    Msg = relationship
                });
            }
        }

        public string FriendlyName => "Relationships Backend";
    }
}
