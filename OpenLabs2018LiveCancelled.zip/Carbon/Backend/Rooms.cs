﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Databasing;
using Carbon.Backend.Interfaces;
using Carbon.Backend.Statics;
using Carbon.Json;
using Carbon.Json.Notifications;
using Carbon.Json.Rooms;
using Carbon.Servers;
using Carbon.Utilities;
using HttpMultipartParser;

using Openlabs.Mgcxm.Assets;
using Openlabs.Mgcxm.Common;
using Openlabs.Mgcxm.Internal;
using Openlabs.Mgcxm.Net;
using OpenlabsSDKV1.Core;
using OpenlabsSDKV1.Core.Async;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend
{
    internal class Rooms : IBackendProvider, IRoomsBackend
    {
        public IPromise Initialize() => new Promise(action =>
        {
            Singleton.Allocate(this);
            action.Resolve();
        });

        public IPromise Cleanup() => new Promise(action =>
        {
            Singleton.Free<Rooms>();
            action.Resolve();
        });

        public IPromise<List<Room>> GetMyRooms(AccessToken accessToken) => new Promise<List<Room>>(action =>
        {
            InitializeDormRoom(accessToken)
                .Then(() => action.Resolve(NonBackend_GetRooms(accessToken)))
                .Catch(action.Reject);
        });

        public IPromise<RoomDetails> GetRoomDetails(AccessToken accessToken, long roomId) => new Promise<RoomDetails>(action =>
        {
            if (Database.RoomsDatabase.Exists(roomId.ToString()))
                action.Resolve(NonBackend_GetRoomDetails(accessToken, roomId));
            else
                action.Reject(Error.Create(15, "No room found"));
        });

        public IPromise<RoomDetailsCombine> GetRoomDetailsCombine(AccessToken accessToken, long roomId) => new Promise<RoomDetailsCombine>(action =>
        {
            if (Database.RoomsDatabase.Exists(roomId.ToString()))
                action.Resolve(NonBackend_GetRoomDetailsCombine(accessToken, roomId));
            else
                action.Reject(Error.Create(15, "No room found"));
        });

        public IPromise<List<Room>> BrowseRooms(AccessToken accessToken, RoomSortType sortType, int skip, int take) => new Promise<List<Room>>(action =>
        {
            action.Resolve(NonBackend_BrowseRooms(accessToken, sortType, skip, take));
        });

        public IPromise<ModifyRoomDetailsResponse> ModifyRoomName(AccessToken accessToken, ModifyNameRequest request) => new Promise<ModifyRoomDetailsResponse>(action =>
        {
            var room = NonBackend_GetRoom(accessToken, request.RoomId);
            var roomDetails = NonBackend_GetRoomDetails(accessToken, room.RoomId);
            var connectionHandler = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(accessToken.PlayerId).Handler;

            if (room == null || roomDetails == null)
            {
                action.Reject(Error.Create(8, "Failed to modify room"));
                return;
            }

            room.Name = request.Name;
            roomDetails.ModifiedAt = DateTime.Now;

            Database.RoomDetailsDatabase.WriteGeneric(room.RoomId.ToString(), roomDetails);
            Database.RoomsDatabase.WriteGeneric(room.RoomId.ToString(), room);

            action.Resolve(new ModifyRoomDetailsResponse
            {
                Result = ModifyRoomResultCode.Success,
                Room = new RoomDetailsCombine(room, roomDetails)
            });

            connectionHandler.SendNotificationBulk(new PushNotificationDto<RoomDetails>
            {
                Id = PushNotificationId.SubscriptionUpdateRoom,
                Msg = roomDetails
            });
        });

        public IPromise<ModifyRoomDetailsResponse> ModifyImageName(AccessToken accessToken, ModifyImageNameRequest request) => new Promise<ModifyRoomDetailsResponse>(action =>
        {
            var room = NonBackend_GetRoom(accessToken, request.RoomId);
            var roomDetails = NonBackend_GetRoomDetails(accessToken, room.RoomId);
            var connectionHandler = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(accessToken.PlayerId).Handler;

            if (room == null || roomDetails == null)
            {
                action.Reject(Error.Create(8, "Failed to modify room"));
                return;
            }

            room.ImageName = request.ImageName;
            roomDetails.ModifiedAt = DateTime.Now;

            Database.RoomDetailsDatabase.WriteGeneric(room.RoomId.ToString(), roomDetails);
            Database.RoomsDatabase.WriteGeneric(room.RoomId.ToString(), room);

            action.Resolve(new ModifyRoomDetailsResponse
            {
                Result = ModifyRoomResultCode.Success,
                Room = new RoomDetailsCombine(room, roomDetails)
            });

            connectionHandler.SendNotificationBulk(new PushNotificationDto<RoomDetails>
            {
                Id = PushNotificationId.SubscriptionUpdateRoom,
                Msg = roomDetails
            });
        });

        public IPromise<ModifyRoomDetailsResponse> ModifyMaxPlayers(AccessToken accessToken, ModifyMaxPlayersRequest request) => new Promise<ModifyRoomDetailsResponse>(action =>
        {
            var room = NonBackend_GetRoom(accessToken, request.RoomId);
            var roomDetails = NonBackend_GetRoomDetails(accessToken, room.RoomId);
            var connectionHandler = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(accessToken.PlayerId).Handler;

            if (room == null || roomDetails == null)
            {
                action.Reject(Error.Create(8, "Failed to modify room"));
                return;
            }

            roomDetails.MaxPlayers = request.MaxPlayers;
            roomDetails.ModifiedAt = DateTime.Now;

            Database.RoomDetailsDatabase.WriteGeneric(room.RoomId.ToString(), roomDetails);
            Database.RoomsDatabase.WriteGeneric(room.RoomId.ToString(), room);

            action.Resolve(new ModifyRoomDetailsResponse
            {
                Result = ModifyRoomResultCode.Success,
                Room = new RoomDetailsCombine(room, roomDetails)
            });

            connectionHandler.SendNotificationBulk(new PushNotificationDto<RoomDetails>
            {
                Id = PushNotificationId.SubscriptionUpdateRoom,
                Msg = roomDetails
            });
        });

        public IPromise<ModifyRoomDetailsResponse> ModifyDescription(AccessToken accessToken, ModifyDescriptionRequest request) => new Promise<ModifyRoomDetailsResponse>(action =>
        {
            var room = NonBackend_GetRoom(accessToken, request.RoomId);
            var roomDetails = NonBackend_GetRoomDetails(accessToken, room.RoomId);
            var connectionHandler = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(accessToken.PlayerId).Handler;

            if (room == null || roomDetails == null)
            {
                action.Reject(Error.Create(8, "Failed to modify room"));
                return;
            }

            room.Description = request.Description;
            roomDetails.ModifiedAt = DateTime.Now;

            Database.RoomDetailsDatabase.WriteGeneric(room.RoomId.ToString(), roomDetails);
            Database.RoomsDatabase.WriteGeneric(room.RoomId.ToString(), room);

            action.Resolve(new ModifyRoomDetailsResponse
            {
                Result = ModifyRoomResultCode.Success,
                Room = new RoomDetailsCombine(room, roomDetails)
            });

            connectionHandler.SendNotificationBulk(new PushNotificationDto<RoomDetails>
            {
                Id = PushNotificationId.SubscriptionUpdateRoom,
                Msg = roomDetails
            });
        });

        public IPromise<ModifyRoomDetailsResponse> ModifyScreenMode(AccessToken accessToken, ModifyScreenModeRequest request) => new Promise<ModifyRoomDetailsResponse>(action =>
        {
            var room = NonBackend_GetRoom(accessToken, request.RoomId);
            var roomDetails = NonBackend_GetRoomDetails(accessToken, room.RoomId);
            var connectionHandler = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(accessToken.PlayerId).Handler;

            if (room == null || roomDetails == null)
            {
                action.Reject(Error.Create(8, "Failed to modify room"));
                return;
            }

            room.ScreenModeSupport = request.ScreenModeSupport;
            roomDetails.ModifiedAt = DateTime.Now;

            Database.RoomDetailsDatabase.WriteGeneric(room.RoomId.ToString(), roomDetails);
            Database.RoomsDatabase.WriteGeneric(room.RoomId.ToString(), room);

            action.Resolve(new ModifyRoomDetailsResponse
            {
                Result = ModifyRoomResultCode.Success,
                Room = new RoomDetailsCombine(room, roomDetails)
            });

            connectionHandler.SendNotificationBulk(new PushNotificationDto<RoomDetails>
            {
                Id = PushNotificationId.SubscriptionUpdateRoom,
                Msg = roomDetails
            });
        });

        public IPromise<ModifyRoomDetailsResponse> ModifyInstanced(AccessToken accessToken, ModifyInstancedRequest request) => new Promise<ModifyRoomDetailsResponse>(action =>
        {
            var room = NonBackend_GetRoom(accessToken, request.RoomId);
            var roomDetails = NonBackend_GetRoomDetails(accessToken, room.RoomId);
            var connectionHandler = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(accessToken.PlayerId).Handler;

            if (room == null || roomDetails == null)
            {
                action.Reject(Error.Create(8, "Failed to modify room"));
                return;
            }

            room.Instanced = request.Instanced;
            roomDetails.ModifiedAt = DateTime.Now;

            Database.RoomDetailsDatabase.WriteGeneric(room.RoomId.ToString(), roomDetails);
            Database.RoomsDatabase.WriteGeneric(room.RoomId.ToString(), room);

            action.Resolve(new ModifyRoomDetailsResponse
            {
                Result = ModifyRoomResultCode.Success,
                Room = new RoomDetailsCombine(room, roomDetails)
            });

            connectionHandler.SendNotificationBulk(new PushNotificationDto<RoomDetails>
            {
                Id = PushNotificationId.SubscriptionUpdateRoom,
                Msg = roomDetails
            });
        });

    

        public IPromise<ModifyRoomDetailsResponse> ModifyDataBlob(AccessToken accessToken, long roomId, string dataBlob) => new Promise<ModifyRoomDetailsResponse>(action =>
        {
            var room = NonBackend_GetRoom(accessToken, roomId);
            var roomDetails = NonBackend_GetRoomDetails(accessToken, room.RoomId);
            var connectionHandler = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(accessToken.PlayerId).Handler;

            if (room == null || roomDetails == null)
            {
                action.Reject(Error.Create(8, "Failed to modify room"));
                return;
            }

            roomDetails.DataBlobName = dataBlob;
            roomDetails.DataModifiedAt = DateTime.Now;
            roomDetails.ModifiedAt = DateTime.Now;

            Database.RoomDetailsDatabase.WriteGeneric(room.RoomId.ToString(), roomDetails);
            Database.RoomsDatabase.WriteGeneric(room.RoomId.ToString(), room);

            action.Resolve(new ModifyRoomDetailsResponse
            {
                Result = ModifyRoomResultCode.Success,
                Room = new RoomDetailsCombine(room, roomDetails)
            });

            connectionHandler.SendNotificationBulk(new PushNotificationDto<RoomDetails>
            {
                Id = PushNotificationId.SubscriptionUpdateRoom,
                Msg = roomDetails
            });
        });

        public IPromise<RoomDetailsCombine> SaveRoom(AccessToken accessToken, long roomId, byte[] formData) => new Promise<RoomDetailsCombine>(action =>
        {
            var parser = MultipartFormDataParser.Parse(new MemoryStream(formData));

            if (parser == null)
                action.Reject(Error.Create(14, "Cant upload room save file", "Failed to parse form data"));
            else
            {
                var cdnServer = Singleton<CdnServer>.Instance;
                var saveFilePart = parser.Files.First();

                cdnServer.UploadFile(saveFilePart, out string fileName);
                ModifyDataBlob(accessToken, roomId, fileName).Then((response) =>
                {
                    action.Resolve(response.Room);
                }).Catch(action.Reject);
            }
        });

        public IPromise InitializeDormRoom(AccessToken accessToken) => new Promise(action =>
        {
            if (!NonBackend_HasDormRoom(accessToken))
            {
                var dormRoom = Room.Create(
                        accessToken,
                        "Dorm Room",
                        "Your private room",
                        ActivityLevelIds.DormRoom.GuidString,
                        false, false,
                        RoomAccessibility.Unlisted
                    );
                NonBackend_AddRoom(accessToken, dormRoom);
            }
            else
                action.Resolve();
        });

        public IPromise UpdateRoom(AccessToken accessToken, Room room) => new Promise(action =>
        {
            var originalRoom = NonBackend_GetRoom(accessToken, room.RoomId);
            originalRoom.ModifyProperties(room);

            Database.RoomsDatabase.WriteGeneric(room.RoomId.ToString(), room);
            action.Resolve();
        });

        public void NonBackend_AddRoom(AccessToken accessToken, Room room)
        {
            if (!Database.RoomsDatabase.Exists(room.RoomId.ToString()))
            {
                RoomDetails roomDetails = new RoomDetails
                {
                    DataBlobName = "",
                    MaxPlayers = 12,
                    AccessibilityLocked = true,
                    CreatedAt = DateTime.Now,
                    ModifiedAt = DateTime.Now,
                    StateModifiedAt = DateTime.MinValue,
                    DataModifiedAt = DateTime.Now,
                    LastVisitedAt = DateTime.MinValue,
                    VisitorCount = 0,
                    VisitCount = 0,
                    CheerCount = 0,
                    ReportCount = 0,
                    CoOwners = new List<long>(),
                    Hosts = new List<long>()
                };

                Database.RoomDetailsDatabase.WriteGeneric(room.RoomId.ToString(), roomDetails);
                Database.RoomsDatabase.WriteGeneric(room.RoomId.ToString(), room);
            }
        }

        public List<Room> NonBackend_GetRooms(AccessToken accessToken)
        {
            List<Room> rooms = new List<Room>();
            foreach (var room in Database.RoomsDatabase.ReadAllGeneric<Room>())
            {
                if (room.CreatorPlayerId == accessToken.PlayerId)
                    rooms.Add(room);
            }

            return rooms;
        }

        public List<Room> NonBackend_GetAllRooms()
        {
            List<Room> rooms = new List<Room>();
            foreach (var room in Database.RoomsDatabase.ReadAllGeneric<Room>())
            {
                rooms.Add(room);
            }

            return rooms;
        }

        public bool NonBackend_HasDormRoom(AccessToken accessToken)
        {
            var rooms = NonBackend_GetRooms(accessToken);
            return rooms.Any(x => x.ActivityLevelId == ActivityLevelIds.DormRoom.GuidString);
        }

        public Room NonBackend_GetDormRoom(AccessToken accessToken)
        {
            var rooms = NonBackend_GetRooms(accessToken);
            return rooms.Find(x => x.ActivityLevelId == ActivityLevelIds.DormRoom.GuidString);
        }

        public Room NonBackend_GetRoom(AccessToken accessToken, long roomId)
        {
            foreach (var room in Database.RoomsDatabase.ReadAllGeneric<Room>())
            {
                if (room.RoomId == roomId)
                    return room;
            }
            return null;
        }

        public RoomDetails NonBackend_GetRoomDetails(AccessToken accessToken, long roomId)
        {
            if (Database.RoomsDatabase.Exists(roomId.ToString()))
            {
                var room = Database.RoomsDatabase.ReadGeneric<Room>(roomId.ToString());
                var roomDetails = Database.RoomDetailsDatabase.ReadGeneric<RoomDetails>(roomId.ToString());
                roomDetails.Initialize(accessToken, room);

                return roomDetails;
            }
            return null;
        }

        public RoomDetailsCombine NonBackend_GetRoomDetailsCombine(AccessToken accessToken, long roomId)
        {
            if (Database.RoomsDatabase.Exists(roomId.ToString()))
            {
                var room = Database.RoomsDatabase.ReadGeneric<Room>(roomId.ToString());
                var roomDetails = Database.RoomDetailsDatabase.ReadGeneric<RoomDetails>(roomId.ToString());
                roomDetails.Initialize(accessToken, room);

                return new RoomDetailsCombine(room, roomDetails);
            }
            return null;
        }

        public List<Room> NonBackend_BrowseRooms(AccessToken accessToken, RoomSortType sortType, int skip, int take)
        {
            List<Room> rooms = new List<Room>();
            foreach (var room in Database.RoomsDatabase.ReadAllGeneric<Room>())
            {
                if (room.CanSeeRoomOnBrowsePage(accessToken))
                    rooms.Add(room);
            }

            return rooms.Skip(skip).Take(take)
                        .ToList();
        }

        public string FriendlyName => "Rooms Backend";
    }

    [Serializable]
    public class CloneRoomRequest
    {
        public CloneRoomRequest()
        {
        }

        public string Name;

        public long RoomId;
    }

    [Obsolete("4-18-2018")]
    [Serializable]
    public class RoomPermissionRequest
    {
        public RoomPermissionRequest()
        {
        }

        public long RoomId;

        public int PlayerId;
    }

    [Serializable]
    public class RoomPermissionRequestV2
    {
        public RoomPermissionRequestV2()
        {
        }

        public long RoomId;

        public int PlayerId;

        public bool IsHost;

        public bool IsOwner;
    }

    [Serializable]
    public class ModifyNameRequest
    {
        public ModifyNameRequest()
        {
        }

        public long RoomId;

        public string Name;
    }

    [Serializable]
    public class ModifyImageNameRequest
    {
        public ModifyImageNameRequest()
        {
        }

        public long RoomId;

        public string ImageName;
    }

    [Serializable]
    public class ModifyDescriptionRequest
    {
        public ModifyDescriptionRequest()
        {
        }

        public long RoomId;

        public string Description;
    }

    [Serializable]
    public class ModifyAccessibilityRequest
    {
        public ModifyAccessibilityRequest()
        {
        }

        public long RoomId;

        public RoomAccessibility Accessibility;
    }

    [Serializable]
    public class ModifyInstancedRequest
    {
        public ModifyInstancedRequest()
        {
        }

        public long RoomId;

        public long GameSessionId;

        public bool Instanced;
    }

    [Serializable]
    public class ModifyScreenModeRequest
    {
        public ModifyScreenModeRequest()
        {
        }

        public long RoomId;

        public ScreenModeSupportType ScreenModeSupport;
    }

    [Serializable]
    public class ModifyMaxPlayersRequest
    {
        public ModifyMaxPlayersRequest()
        {
        }

        public long RoomId;

        public int MaxPlayers;
    }

    [Serializable]
    public class RestoreDataHistoryRequest
    {
        public RestoreDataHistoryRequest()
        {
        }

        public long RoomDataHistoryId;
    }

    [Serializable]
    public class SearchRoomRequest
    {
        public SearchRoomRequest()
        {
        }

        public string Name;
    }

    public class CheerData
    {
        public long PlayerIdTo { get; set; }
        public int CheerCategory { get; set; }
        public string ActivityLevelId { get; set; }
        public bool Anonymous { get; set; }
    }

    public class CheerResponse
    {

    }


    [Serializable]
    public class CheerRequest
    {
        public CheerRequest()
        {
        }

        public long RoomId;

        public bool Cheer;
    }

    [Serializable]
    public class BookmarkRequest
    {
        public BookmarkRequest()
        {
        }

        public long RoomId;

        public bool Bookmark;
    }

    [Serializable]
    public class ReportRequest
    {
        public ReportRequest()
        {
        }

        public long RoomId;

        public string Details;
    }

    [Serializable]
    public class RoomImageListDTO
    {
        public RoomImageListDTO()
        {
        }

        public List<string> roomImageList;
    }

    [Serializable]
    public class DataBlobListDTO
    {
        public DataBlobListDTO()
        {
        }

        public List<string> dataBlobList;
 
    }
}
