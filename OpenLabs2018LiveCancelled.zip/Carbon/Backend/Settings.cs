﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Databasing;
using Carbon.Backend.Interfaces;
using Carbon.Json;
using Carbon.Utilities;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend
{
    internal class Settings : IBackendProvider, ISettingsBackend
    {
        public IPromise Initialize() => new Promise(action =>
        {
            Singleton.Allocate(this);
            action.Resolve();
        });

        public IPromise Cleanup() => new Promise(action =>
        {
            Singleton.Free<Settings>();
            action.Resolve();
        });

        public IPromise<List<Setting>> GetSettings(AccessToken accessToken) => new Promise<List<Setting>>(action =>
        {
            if (!Database.PlayerSettingsDatabase.Exists(accessToken.PlatformId))
            {
                var initializedList = new List<Setting>();

                Database.PlayerSettingsDatabase.WriteGeneric(accessToken.PlatformId, initializedList);
                action.Resolve(initializedList);
            }
            else
                action.Resolve(Database.PlayerSettingsDatabase.ReadGeneric<List<Setting>>(accessToken.PlatformId));
        });

        public IPromise SetOrAddSetting(AccessToken accessToken, Setting setting) => new Promise(action =>
        {
            GetSettings(accessToken)
                .Then(playerSettings =>
                {
                    bool settingsDebounce = false;

                    foreach (var playerSetting in playerSettings)
                    {
                        if (playerSetting.Key == setting.Key && !settingsDebounce)
                        {
                            playerSetting.Value = setting.Value;
                            settingsDebounce = true;
                        }
                    }    

                    if (!settingsDebounce)
                        playerSettings.Add(setting);

                    Database.PlayerSettingsDatabase.WriteGeneric(accessToken.PlatformId, playerSettings);
                    action.Resolve();
                });
        });

        public string FriendlyName => "Settings Backend";
    }
}
