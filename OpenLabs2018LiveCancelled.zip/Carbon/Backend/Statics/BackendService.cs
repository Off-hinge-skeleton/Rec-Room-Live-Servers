﻿using Carbon.Backend.Interfaces;
using Openlabs.Mgcxm.Internal;
using OpenlabsSDKV1.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.Statics
{
    internal static class BackendService
    {
        public static void Initialize()
        {
            var assembly = Assembly.GetAssembly(typeof(BackendService));

            foreach (var type in assembly.GetTypes())
                if (!type.IsInterface && !type.IsAbstract && type.InheritsOrImplements(typeof(IBackendProvider)))
                {
                    Constants.BackendProviderSink.Warning("Adding {0} to backend list.", type.GetSafeName());
                    Internal_AddService((IBackendProvider)Activator.CreateInstance(type)!);
                }
        }

        public static void Deinitialize()
        {
            foreach (var backend in _providers)
                backend.Cleanup();
        }

        public static void Add<T>()
            where T : IBackendProvider, new()
        {
            Internal_AddService(Activator.CreateInstance<T>());
        }

        private static void Internal_AddService(IBackendProvider backend)
        {
            if (backend == null)
            {
                Logger.Error("Failed to add service because 'backend' is null!");
                return;
            }

            backend.Initialize().Then(() =>
            {
                _providers.Add(backend);
            });
        }

        public static void Remove<T>()
            where T : IBackendProvider, new()
        {
            Internal_RemoveService<T>();
        }

        private static void Internal_RemoveService<T>()
            where T : IBackendProvider, new()
        {
            var provider = _providers.FirstOrDefault(x => x.GetType().GUID == typeof(T).GUID, null);
            if (provider == null) return;

            provider.Cleanup().Then(() =>
            {
                _providers.Remove(provider);
            });
        }

        public static T GetBackend<T>()
            where T : IBackendProvider, new()
        {
            return (T)_providers.FirstOrDefault(x =>
            {
                if (x == null)
                    return false;

                return x.GetType().GUID == typeof(T).GUID;
            }, null)!;
        }

        static HashSet<IBackendProvider> _providers = new HashSet<IBackendProvider>();
    }
}
