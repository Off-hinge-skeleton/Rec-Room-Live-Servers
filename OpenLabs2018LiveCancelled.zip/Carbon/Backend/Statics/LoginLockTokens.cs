﻿using Carbon.Backend.AccessTokens;
using Openlabs.Mgcxm.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.Statics
{
    internal static class LoginLockTokens
    {
        public static string CreateToken(AccessToken accessToken, string requestedToken)
        {
            Constants.LoginLockTokenSink.Warning("Creating token: {0}", requestedToken);
            return OneTimeToken.CreateForced(Duration.Hours(5), "LoginLockToken", accessToken, requestedToken, null!, OnLoginLockTokenExpired);
        }

        private static void OnLoginLockTokenExpired(OneTimeToken expiredToken)
        {
            Constants.LoginLockTokenSink.Warning("Token expired: {0}", expiredToken.TokenString);
        }
    }
}
