﻿using Carbon.Backend.Databasing;
using Carbon.Json.Rooms;
using Openlabs.Mgcxm.Internal;
using OpenlabsSDKV1.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Backend.Statics
{
    internal static class RecRoomOriginalRooms
    {
        public static void Initialize()
        {
            var date = new DateTime(2018, 08, 11);
            long roomId = 35172;
            foreach (var activityId in ActivityLevelIds.AllRoomSceneIds)
            {
                if (!(activityId == ActivityLevelIds.Invalid || activityId == ActivityLevelIds.DormRoom))
                {
                    var room = new Room(
                        roomId,
                        activityId.FriendlyName,
                        "", 1,
                        activityId.FriendlyName.Replace(" ", "").Replace("(", "").Replace(")", "") + ".png",
                        activityId.GuidString, RoomState.Active,
                        RoomAccessibility.Public, false,
                        true, ScreenModeSupportType.Mixed);
                    var roomDetails = new RoomDetails
                    {
                        DataBlobName = "",
                        MaxPlayers = activityId.MaxCapacity,
                        AccessibilityLocked = false,
                        CreatedAt = date,
                        ModifiedAt = date,
                        StateModifiedAt = date,
                        DataModifiedAt = date,
                        LastVisitedAt = DateTime.MinValue,
                        VisitorCount = 0,
                        VisitCount = 0,
                        CheerCount = 0,
                        ReportCount = 0,
                        CoOwners = new List<long>(),
                        Hosts = new List<long>()
                    };
                    var roomDetailsCombine = new RoomDetailsCombine(room, roomDetails);

                    try
                    {
                        _allRooms.Add(room);
                        _allRoomDetails.Add(roomDetails);

                        //Database.RoomDetailsDatabase.WriteGeneric(roomId.ToString(), roomDetailsCombine);
                        Database.RoomsDatabase.WriteGeneric(roomId.ToString(), room);
                        roomId++;
                    }
                    catch 
                    {
                        Logger.Error(string.Format("Cannot write to ^{0} file. Is the server open as admin?", room.Name));
                    }
                }
            }
        }

        public static Room GetRoomFromActivityLevelId(string activityLevelId)
        {
            return _allRooms.Find(x => x.ActivityLevelId == activityLevelId);
        }

        static List<Room> _allRooms = new List<Room>();
        static List<RoomDetails> _allRoomDetails = new List<RoomDetails>();
    }
}
