﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Databasing;
using Carbon.Backend.Interfaces;
using Carbon.Json;
using Carbon.Json.Storefronts;
using Carbon.Utilities;
using Newtonsoft.Json;
using Openlabs.Mgcxm.Common.JsonMapping;
using OpenlabsSDKV1.Core.Async;
using SixLabors.ImageSharp.ColorSpaces;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace Carbon.Backend
{
    internal class Storefronts : IBackendProvider, IStorefrontsBackend
    {
        public IPromise Initialize() => new Promise(action =>
        {
            Singleton.Allocate(this);
            action.Resolve();
        });

        public IPromise Cleanup() => new Promise(action =>
        {
            Singleton.Free<Storefronts>();
            action.Resolve();
        });

        public IPromise<Storefront> GetStorefront(AccessToken accessToken, StorefrontType storefrontType) => new Promise<Storefront>(action =>
        {

            if (!Database.StorefrontDatabase.Exists("storefront"))
            {
                var storefront = new Storefront
                {


                    StorefrontType = storefrontType,
                    NextUpdate = DateTime.Now.AddDays(7),
                    StoreItems = new StoreItem[] {
                new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 1,
                            AvatarItemDesc = "4308da04-af84-40bb-845a-7a9e1a2726ec,,,",
                            ConsumableItemDesc = "",
                            FriendlyName = "Mobster Shirt",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Epic,
                            Tooltip = "Mobster Shirt",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 4000 } },
                PurchasableItemId = 1,
                Type = PurchasableItemType.GiftDrop
            },

                new StoreItem
                { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 2,
                            AvatarItemDesc = "76369aef-aeda-46d2-996a-cd00594d0543,,,",
                            ConsumableItemDesc = "",
                            FriendlyName = "Mobster Hat",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Epic,
                            Tooltip = "Mobster Hat",
                            Unique = false
                        },

                    },

                    IsFeatured = false,
                    Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 3000 } },
                    PurchasableItemId = 2,
                    Type = PurchasableItemType.GiftDrop
                },

                new StoreItem
                { GiftDrops =
                     new StorefrontGiftDrop[] {
                         new StorefrontGiftDrop
                         {
                             GiftDropId = 3,
                             AvatarItemDesc = "08d56627-4500-4724-8692-a23c96ddb3ec,,,",
                             ConsumableItemDesc = "",
                             FriendlyName = "Mobster Cuffs",
                             Context = Json.GiftContext.Default,
                             EquipmentModificationGuid = "",
                             EquipmentPrefabName = "",
                             IsQuery = false,
                             Rarity = Json.GiftRarity.Epic,
                             Tooltip = "Mobster Cuffs",
                             Unique = false
                         },

                     },

                     IsFeatured = false,
                     Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 2500 } },
                     PurchasableItemId = 3,
                     Type = PurchasableItemType.GiftDrop
                 },

                new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 4,
                            AvatarItemDesc = "6427bd57-fcb2-420f-8b3e-d1da43470b84,,,",
                            ConsumableItemDesc = "",
                            FriendlyName = "Sun Glasses",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Rare,
                            Tooltip = "Sun Glasses",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 1500 } },
                PurchasableItemId = 4,
                Type = PurchasableItemType.GiftDrop
            },

                new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 5,
                            AvatarItemDesc = "e60fccda-8711-463d-b8a3-7cd5e76903b2,,,",
                            ConsumableItemDesc = "",
                            FriendlyName = "Conductor Shirt",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Rare,
                            Tooltip = "Conductor Shirt",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 2500 } },
                PurchasableItemId = 5,
                Type = PurchasableItemType.GiftDrop
            },

                new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 6,
                            AvatarItemDesc = "07205057-0804-41de-abe4-bd4027fee1df,,,",
                            ConsumableItemDesc = "",
                            FriendlyName = "Conductor Hat",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Legendary,
                            Tooltip = "Conductor Hat",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 1500 } },
                PurchasableItemId = 6,
                Type = PurchasableItemType.GiftDrop
            },

                new StoreItem
                { GiftDrops =
                        new StorefrontGiftDrop[] {
                            new StorefrontGiftDrop
                            {
                                GiftDropId = 7,
                                AvatarItemDesc = "8fc7aaef-adec-4534-8f91-445e4e7095d5,,,",
                                ConsumableItemDesc = "",
                                FriendlyName = "Conductor Cuffs",
                                Context = Json.GiftContext.Default,
                                EquipmentModificationGuid = "",
                                EquipmentPrefabName = "",
                                IsQuery = false,
                                Rarity = Json.GiftRarity.Rare,
                                Tooltip = "Conductor Cuffs",
                                Unique = false
                            },

                        },

                    IsFeatured = false,
                    Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 500 } },
                    PurchasableItemId = 7,
                    Type = PurchasableItemType.GiftDrop
                },

                new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 8,
                            AvatarItemDesc = "b89be768-a169-4b24-8022-751e7b817865,,,",
                            ConsumableItemDesc = "",
                            FriendlyName = "SciFi Visor",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Legendary,
                            Tooltip = "SciFi Visor",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 9000 } },
                PurchasableItemId = 8,
                Type = PurchasableItemType.GiftDrop
            },

                new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 9,
                            AvatarItemDesc = "350c5c1e-318b-4233-a7e5-1f49909d8e65,,,",
                            ConsumableItemDesc = "",
                            FriendlyName = "Lumberjack Shirt",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Epic,
                            Tooltip = "Lumberjack Shirt",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 4000 } },
                PurchasableItemId = 9,
                Type = PurchasableItemType.GiftDrop
            },

            new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 10,
                            AvatarItemDesc = "b537c30c-faef-4649-9a1f-be3985936f93,,,",
                            ConsumableItemDesc = "",
                            FriendlyName = "Lumberjack Hat",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Epic,
                            Tooltip = "Lumberjack Hat",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 2500} },
                PurchasableItemId = 10,
                Type = PurchasableItemType.GiftDrop
            },

                new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 11,
                            AvatarItemDesc = "61ba3c90-c81e-4deb-bc79-50c0f1fe3e83,,,",
                            ConsumableItemDesc = "",
                            FriendlyName = "Lumberjack Beard",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Rare,
                            Tooltip = "Lumberjack Beard",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 1000 } },
                PurchasableItemId = 11,
                Type = PurchasableItemType.GiftDrop
            },

             new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 12,
                            AvatarItemDesc = "587ca2bb-dd42-42bf-833f-4e2a97349866,,,",
                            ConsumableItemDesc = "",
                            FriendlyName = "Doctor Stethoscope",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Legendary,
                            Tooltip = "Doctor Stethoscope",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 9000 } },
                PurchasableItemId = 12,
                Type = PurchasableItemType.GiftDrop
            },

             new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 13,
                            AvatarItemDesc = "40734c4d-e1fe-426c-8921-930f7463d8e8,,,",
                            ConsumableItemDesc = "",
                            FriendlyName = "Royal Crown",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Legendary,
                            Tooltip = "Royal Crown",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 6500 } },
                PurchasableItemId = 13,
                Type = PurchasableItemType.GiftDrop
            },

              new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 14,
                            AvatarItemDesc = "",
                            ConsumableItemDesc = "JfnVXFmilU6ysv-VbTAe3A",
                            FriendlyName = "Root Beer",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Legendary,
                            Tooltip = "Root Beer",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 50 } },
                PurchasableItemId = 14,
                Type = PurchasableItemType.GiftDrop
            },

               new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 15,
                            AvatarItemDesc = "",
                            ConsumableItemDesc = "mq23W-RSP0G8iGNLdrcpUw",
                            FriendlyName = "Pepperoni Pizza",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Legendary,
                            Tooltip = "",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 50000 } },
                PurchasableItemId = 15,
                Type = PurchasableItemType.GiftDrop
            },
        }

                };
                Database.StorefrontDatabase.WriteGeneric("storefront", storefront);
            }
            var Gifts = Database.StorefrontDatabase.ReadGeneric<Storefront>("storefront");



            if (storefrontType == StorefrontType.RecCenter || storefrontType == StorefrontType.Watch)
            {
                var storefront = new Storefront
                {


                    StorefrontType = storefrontType,
                    NextUpdate = DateTime.Now.AddDays(7),
                    StoreItems = new StoreItem[] {
                new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 1,
                            AvatarItemDesc = "4308da04-af84-40bb-845a-7a9e1a2726ec,,,",
                            ConsumableItemDesc = "",
                            FriendlyName = "Mobster Shirt",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Epic,
                            Tooltip = "Mobster Shirt",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 4000 } },
                PurchasableItemId = 1,
                Type = PurchasableItemType.GiftDrop
            },

                new StoreItem
                { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 2,
                            AvatarItemDesc = "76369aef-aeda-46d2-996a-cd00594d0543,,,",
                            ConsumableItemDesc = "",
                            FriendlyName = "Mobster Hat",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Epic,
                            Tooltip = "Mobster Hat",
                            Unique = false
                        },

                    },

                    IsFeatured = false,
                    Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 3000 } },
                    PurchasableItemId = 2,
                    Type = PurchasableItemType.GiftDrop
                },

                new StoreItem
                { GiftDrops =
                     new StorefrontGiftDrop[] {
                         new StorefrontGiftDrop
                         {
                             GiftDropId = 3,
                             AvatarItemDesc = "08d56627-4500-4724-8692-a23c96ddb3ec,,,",
                             ConsumableItemDesc = "",
                             FriendlyName = "Mobster Cuffs",
                             Context = Json.GiftContext.Default,
                             EquipmentModificationGuid = "",
                             EquipmentPrefabName = "",
                             IsQuery = false,
                             Rarity = Json.GiftRarity.Epic,
                             Tooltip = "Mobster Cuffs",
                             Unique = false
                         },

                     },

                     IsFeatured = false,
                     Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 2500 } },
                     PurchasableItemId = 3,
                     Type = PurchasableItemType.GiftDrop
                 },

                new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 4,
                            AvatarItemDesc = "6427bd57-fcb2-420f-8b3e-d1da43470b84,,,",
                            ConsumableItemDesc = "",
                            FriendlyName = "Sun Glasses",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Rare,
                            Tooltip = "Sun Glasses",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 1500 } },
                PurchasableItemId = 4,
                Type = PurchasableItemType.GiftDrop
            },

                new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 5,
                            AvatarItemDesc = "e60fccda-8711-463d-b8a3-7cd5e76903b2,,,",
                            ConsumableItemDesc = "",
                            FriendlyName = "Conductor Shirt",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Rare,
                            Tooltip = "Conductor Shirt",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 2500 } },
                PurchasableItemId = 5,
                Type = PurchasableItemType.GiftDrop
            },

                new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 6,
                            AvatarItemDesc = "07205057-0804-41de-abe4-bd4027fee1df,,,",
                            ConsumableItemDesc = "",
                            FriendlyName = "Conductor Hat",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Legendary,
                            Tooltip = "Conductor Hat",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 1500 } },
                PurchasableItemId = 6,
                Type = PurchasableItemType.GiftDrop
            },

                new StoreItem
                { GiftDrops =
                        new StorefrontGiftDrop[] {
                            new StorefrontGiftDrop
                            {
                                GiftDropId = 7,
                                AvatarItemDesc = "8fc7aaef-adec-4534-8f91-445e4e7095d5,,,",
                                ConsumableItemDesc = "",
                                FriendlyName = "Conductor Cuffs",
                                Context = Json.GiftContext.Default,
                                EquipmentModificationGuid = "",
                                EquipmentPrefabName = "",
                                IsQuery = false,
                                Rarity = Json.GiftRarity.Rare,
                                Tooltip = "Conductor Cuffs",
                                Unique = false
                            },

                        },

                    IsFeatured = false,
                    Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 500 } },
                    PurchasableItemId = 7,
                    Type = PurchasableItemType.GiftDrop
                },

                new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 8,
                            AvatarItemDesc = "b89be768-a169-4b24-8022-751e7b817865,,,",
                            ConsumableItemDesc = "",
                            FriendlyName = "SciFi Visor",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Legendary,
                            Tooltip = "SciFi Visor",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 9000 } },
                PurchasableItemId = 8,
                Type = PurchasableItemType.GiftDrop
            },

                new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 9,
                            AvatarItemDesc = "350c5c1e-318b-4233-a7e5-1f49909d8e65,,,",
                            ConsumableItemDesc = "",
                            FriendlyName = "Lumberjack Shirt",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Epic,
                            Tooltip = "Lumberjack Shirt",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 4000 } },
                PurchasableItemId = 9,
                Type = PurchasableItemType.GiftDrop
            },

            new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 10,
                            AvatarItemDesc = "b537c30c-faef-4649-9a1f-be3985936f93,,,",
                            ConsumableItemDesc = "",
                            FriendlyName = "Lumberjack Hat",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Epic,
                            Tooltip = "Lumberjack Hat",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 2500} },
                PurchasableItemId = 10,
                Type = PurchasableItemType.GiftDrop
            },

                new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 11,
                            AvatarItemDesc = "61ba3c90-c81e-4deb-bc79-50c0f1fe3e83,,,",
                            ConsumableItemDesc = "",
                            FriendlyName = "Lumberjack Beard",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Rare,
                            Tooltip = "Lumberjack Beard",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 1000 } },
                PurchasableItemId = 11,
                Type = PurchasableItemType.GiftDrop
            },

             new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 12,
                            AvatarItemDesc = "587ca2bb-dd42-42bf-833f-4e2a97349866,,,",
                            ConsumableItemDesc = "",
                            FriendlyName = "Doctor Stethoscope",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Legendary,
                            Tooltip = "Doctor Stethoscope",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 9000 } },
                PurchasableItemId = 12,
                Type = PurchasableItemType.GiftDrop
            },

             new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 13,
                            AvatarItemDesc = "40734c4d-e1fe-426c-8921-930f7463d8e8,,,",
                            ConsumableItemDesc = "",
                            FriendlyName = "Royal Crown",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Legendary,
                            Tooltip = "Royal Crown",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 6500 } },
                PurchasableItemId = 13,
                Type = PurchasableItemType.GiftDrop
            },

              new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 14,
                            AvatarItemDesc = "",
                            ConsumableItemDesc = "JfnVXFmilU6ysv-VbTAe3A",
                            FriendlyName = "Root Beer",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Legendary,
                            Tooltip = "Root Beer",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 50 } },
                PurchasableItemId = 14,
                Type = PurchasableItemType.GiftDrop
            },

               new StoreItem
            { GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 15,
                            AvatarItemDesc = "",
                            ConsumableItemDesc = "mq23W-RSP0G8iGNLdrcpUw",
                            FriendlyName = "Pepperoni Pizza",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Legendary,
                            Tooltip = "",
                            Unique = false
                        },

                    },

                IsFeatured = false,
                Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.RecCenterTokens, Price = 150 } },
                PurchasableItemId = 15,
                Type = PurchasableItemType.GiftDrop
            },
        }

                };
                Database.StorefrontDatabase.WriteGeneric("storefront", storefront);
                action.Resolve(storefront);
            }
            else
            {
                var storefront = new Storefront
                {


                    StorefrontType = storefrontType,
                    NextUpdate = DateTime.Now.AddDays(7),
                    StoreItems = new StoreItem[] {
                        new StoreItem
                        {
                            GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 1,
                            AvatarItemDesc = "123de433-a005-4994-8a11-d2d84ad66b11,4e378419-d043-4e86-ad0e-66288ac21cf4,-e6bmXnwZU2EVwZ8RupKbg,",
                            ConsumableItemDesc = "",
                            FriendlyName = "LaserTag Visor Red",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Epic,
                            Tooltip = "LaserTag Visor Red",
                            Unique = false
                        },

                    },

                            IsFeatured = false,
                            Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.LaserTagTickets, Price = 2500 } },
                            PurchasableItemId = 1,
                            Type = PurchasableItemType.GiftDrop
                        },


                        new StoreItem
                        {
                            GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 2,
                            AvatarItemDesc = "24d94673-f394-42e6-a3c8-276f8b8aa722,959ed05b-0215-4bbe-bb3d-64e4448d676b,jkuw9EhCpEKn-2lKJXWd3Q,",
                            ConsumableItemDesc = "",
                            FriendlyName = "LaserTag Vest Red",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Epic,
                            Tooltip = "LaserTag Vest Red",
                            Unique = false
                        },

                    },

                            IsFeatured = false,
                            Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.LaserTagTickets, Price = 5000 } },
                            PurchasableItemId = 2,
                            Type = PurchasableItemType.GiftDrop
                        },

                        new StoreItem
                        {
                            GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 3,
                            AvatarItemDesc = "3044adce-90c0-4f66-81f5-39c4fca86fdf,3b825377-d2eb-41e4-a736-b107f88f62d6,mhsglVEtREmElF5wuLw3NQ,",
                            ConsumableItemDesc = "",
                            FriendlyName = "LaserTag Gloves Red",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Epic,
                            Tooltip = "LaserTag Gloves Red",
                            Unique = false
                        },

                    },

                            IsFeatured = false,
                            Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.LaserTagTickets, Price = 1500 } },
                            PurchasableItemId = 3,
                            Type = PurchasableItemType.GiftDrop
                        },


                         new StoreItem
                        {
                            GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 4,
                            AvatarItemDesc = "d0a9262f-5504-46a7-bb10-7507503db58e,941c046e-4e95-49f8-a7d7-19071fcc3c94,0440f08f-ef1d-49d8-942b-523056e8bb45,e38294cf-6279-4863-9aea-1a19aeaf8476",
                            ConsumableItemDesc = "",
                            FriendlyName = "Laser Tag Alpha Shirt",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Epic,
                            Tooltip = "Laser Tag Alpha Shirt",
                            Unique = false
                        },

                    },

                            IsFeatured = false,
                            Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.LaserTagTickets, Price = 3000 } },
                            PurchasableItemId = 4,
                            Type = PurchasableItemType.GiftDrop
                        },


                    new StoreItem
                        {
                            GiftDrops =
                    new StorefrontGiftDrop[] {
                        new StorefrontGiftDrop
                        {
                            GiftDropId = 5,
                            AvatarItemDesc = "d0a9262f-5504-46a7-bb10-7507503db58e,bda7a57e-5227-49f4-a119-e3f166604738,0440f08f-ef1d-49d8-942b-523056e8bb45,703ff56b-560d-4ff4-8c63-d195e879a328",
                            ConsumableItemDesc = "",
                            FriendlyName = "Laser Tag Alpaca Shirt",
                            Context = Json.GiftContext.Default,
                            EquipmentModificationGuid = "",
                            EquipmentPrefabName = "",
                            IsQuery = false,
                            Rarity = Json.GiftRarity.Epic,
                            Tooltip = "Laser Tag Alpaca Shirt",
                            Unique = false
                        },

                    },


                            IsFeatured = false,
                            Prices = new PurchasableItemPrice[] { new PurchasableItemPrice { CurrencyType = CurrencyType.LaserTagTickets, Price = 3000 } },
                            PurchasableItemId = 5,
                            Type = PurchasableItemType.GiftDrop
                        },

                    },

                    
                };
                Database.StorefrontDatabase.WriteGeneric("storefront2", storefront);
                action.Resolve(storefront);
            }
            
        });


        public StorefrontGiftDrop GetStoreFrontGift(int id)
        {
            var storefront = Database.StorefrontDatabase.ReadGeneric<Storefront>("storefront");

            return storefront.StoreItems.ElementAt(id - 1).GiftDrops.ElementAt(0);

        }


        public int getStoreFrontGiftPrice(int id)

        {
            var storefront = Database.StorefrontDatabase.ReadGeneric<Storefront>("storefront");
            var price = 0;

            return JsonConvert.DeserializeObject<PurchasableItemPrice>(storefront.StoreItems.ElementAt(id - 1).Prices.ToJson()).Price;

        }
        public string FriendlyName => "Storefronts Backend";
    }
}
