﻿using OpenlabsSDKV1.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Configs
{
    public static class Config
    {
        private static bool IsConfig<T>(CarbonConfigBase config) where T : CarbonConfigBase, new() 
            => config.GetType().GUID == typeof(T).GUID;

        public static T Get<T>() where T : CarbonConfigBase, new()
        {
            if (!_configs.Any(x => IsConfig<T>(x)))
                _configs.Add(new T());

            var foundConfig = _configs.TryGetValue(
                _configs.First(x => IsConfig<T>(x)), 
                out var config);

            if (!foundConfig)
                return null!;
            return (T)config!;
        }

        static HashSet<CarbonConfigBase> _configs = new HashSet<CarbonConfigBase>();
    }

    public abstract class CarbonConfigBase
    {
        public abstract UUID GUID { get; }
        public abstract string Name { get; }
    }
}
