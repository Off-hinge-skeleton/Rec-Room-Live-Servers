﻿using Carbon.Json;
using OpenlabsSDKV1.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Configs
{
    public enum ConsumableFoodType
    {
        NONE,
        ROOT_BEER,
        PIZZA
    }

    public enum ConsumablePotionType
    {
        INVALID,
        DKMode
    }

    public enum ConsumableFilterType
    {
        NONE,
        BLACK_WHITE,
        DAWN,
        SEPIA,
        GOBLIN1,
        JUMBOTRON,
        CRIMSONCAULDRON,
        GHOSTBEARD
    }



    public enum ConsumableDataLimitType
    {
        Invalid = -1,
        Usage,
        Time
    }

    public enum ConsumableDataType
    {
        Invalid = -1,
        CameraFilter,
        Potion_Head = 2,
        Potion_Hand,
        Food,
        KO_Customization
    }

    internal class ConsumeResponse
    {
        public long Id { get; set; }
        public int DeltaCount { get; set; }
    }

    internal class ConsumableData
    {
        public string friendlyName;
        public ConsumableDataType category;
        public string guidString;
        public int limitCount;
        public ConsumableDataLimitType limitType;
    }

    internal class FoodConsumableData : ConsumableData
    {
        public ConsumableFoodType foodType;
    }

    internal class CameraFilterConsumableData : ConsumableData
    {
        public ConsumableFilterType filterType;
    }

    internal class HandPotionConsumableData : ConsumableData
    {
    }

    internal class HeadPotionConsumableData : ConsumableData
    {
        public ConsumablePotionType potionType;
    }

    internal class KOConsumableData : ConsumableData
    {
    }

    internal class ConsumableDataConfig : CarbonConfigBase
    {
        public override UUID GUID => (UUID)"f3086dc27e1849078856947fdec7d1af";
        public override string Name => "Consumable Data Config";

        public List<Consumable> ToDTO()
        {
            List<Consumable> consumables = new List<Consumable>();
            foreach (var data in ConsumableData)
            {
                consumables.Add(new Consumable
                {
                    Id = Openlabs.Mgcxm.Common.Random.Range(1000, 100000),
                    ConsumableItemDesc = data.guidString,
                    CreatedAt = DateTime.Now,
                    IsActive = false,
                    UnlockedLevel = 1,
                    Count = 99
                });
            }

            return consumables;
        }

        public ConsumableData[] ConsumableData { get; set; } = new ConsumableData[]
        {
            //
            // Food Data
            //
            new FoodConsumableData
            {
                friendlyName = "Root Beer",
                category = ConsumableDataType.Food,
                guidString = "JfnVXFmilU6ysv-VbTAe3A",
                limitCount = 1,
                limitType = ConsumableDataLimitType.Usage,
                foodType = ConsumableFoodType.ROOT_BEER
            },
            new FoodConsumableData
            {
                friendlyName = "Pepperoni Pizza",
                category = ConsumableDataType.Food,
                guidString = "mq23W-RSP0G8iGNLdrcpUw",
                limitCount = 1,
                limitType = ConsumableDataLimitType.Usage,
                foodType = ConsumableFoodType.PIZZA
            },
            new FoodConsumableData
            {
                friendlyName = "Cheese Pizza",
                category = ConsumableDataType.Food,
                guidString = "5hIAZ9wg5EyG1cILf4FS2A",
                limitCount = 1,
                limitType = ConsumableDataLimitType.Usage,
                foodType = ConsumableFoodType.PIZZA
            },
            new FoodConsumableData
            {
                friendlyName = "Supreme Pizza",
                category = ConsumableDataType.Food,
                guidString = "wUCIKdJSvEmiQHYMyx4X4w",
                limitCount = 1,
                limitType = ConsumableDataLimitType.Usage,
                foodType = ConsumableFoodType.PIZZA
            },

            // 
            // Filter Data
            //
            new CameraFilterConsumableData
            {
                friendlyName = "Dawn Camera Film",
                category = ConsumableDataType.CameraFilter,
                guidString = "m0bVLwWGj0GuIBSb6wCk6Q",
                limitCount = 3,
                limitType = ConsumableDataLimitType.Usage,
                filterType = ConsumableFilterType.DAWN
            },
            new CameraFilterConsumableData
            {
                friendlyName = "Ghost Beard Film",
                category = ConsumableDataType.CameraFilter,
                guidString = "1c0Djlp090uBDczEobYNQw",
                limitCount = 3,
                limitType = ConsumableDataLimitType.Usage,
                filterType = ConsumableFilterType.GHOSTBEARD
            },
            new CameraFilterConsumableData
            {
                friendlyName = "Witch Film",
                category = ConsumableDataType.CameraFilter,
                guidString = "mL3zCEuy2UWZxAV4V-OsMA",
                limitCount = 3,
                limitType = ConsumableDataLimitType.Usage,
                filterType = ConsumableFilterType.CRIMSONCAULDRON
            },
            new CameraFilterConsumableData
            {
                friendlyName = "Jumbotron Film",
                category = ConsumableDataType.CameraFilter,
                guidString = "Il4VmrnjDkqjmjzddqoIEw",
                limitCount = 3,
                limitType = ConsumableDataLimitType.Usage,
                filterType = ConsumableFilterType.JUMBOTRON
            },
            new CameraFilterConsumableData
            {
                friendlyName = "Goblin King Film",
                category = ConsumableDataType.CameraFilter,
                guidString = "6SyCoJCgo0Wd6qlPlnMOtg",
                limitCount = 3,
                limitType = ConsumableDataLimitType.Usage,
                filterType = ConsumableFilterType.GOBLIN1
            },
            new CameraFilterConsumableData
            {
                friendlyName = "Sepia Camera Film",
                category = ConsumableDataType.CameraFilter,
                guidString = "A5M-yf9tgUihq1uab3v58g",
                limitCount = 3,
                limitType = ConsumableDataLimitType.Usage,
                filterType = ConsumableFilterType.SEPIA
            },
            new CameraFilterConsumableData
            {
                friendlyName = "Black & White Camera Film",
                category = ConsumableDataType.CameraFilter,
                guidString = "frOMH6WxDEG1fBqC4_83vg",
                limitCount = 3,
                limitType = ConsumableDataLimitType.Usage,
                filterType = ConsumableFilterType.BLACK_WHITE
            },

            //
            // Hand Potion Data
            //
            new HandPotionConsumableData
            {
                friendlyName = "High Five O'Spells",
                category = ConsumableDataType.Potion_Hand,
                guidString = "VQSgL2pTLkWx4B3kwYG7UA",
                limitCount = 120,
                limitType = ConsumableDataLimitType.Time
            },
            new HandPotionConsumableData
            {
                friendlyName = "High Five O'Gunpowder",
                category = ConsumableDataType.Potion_Hand,
                guidString = "YEfbJTnsR0yT_p7e7tb_kQ",
                limitCount = 120,
                limitType = ConsumableDataLimitType.Time
            },
            new HandPotionConsumableData
            {
                friendlyName = "High Five O'Lasers",
                category = ConsumableDataType.Potion_Hand,
                guidString = "xHOwjwpXd0GDkvBz2VqieA",
                limitCount = 120,
                limitType = ConsumableDataLimitType.Time
            },
            new HandPotionConsumableData
            {
                friendlyName = "High Five O'Gold",
                category = ConsumableDataType.Potion_Hand,
                guidString = "-hy0qD-iUk-v4NHxNzanmg",
                limitCount = 120,
                limitType = ConsumableDataLimitType.Time
            },

            // 
            // Head Potion Data
            //
            new HeadPotionConsumableData
            {
                friendlyName = "Ego Potion",
                category = ConsumableDataType.Potion_Head,
                guidString = "Tpxqe_lycUelySRHM8B0Vw",
                limitCount = 120,
                limitType = ConsumableDataLimitType.Time,
                potionType = ConsumablePotionType.DKMode
            },

            //
            // KO Consumable Data
            //
            new KOConsumableData
            {
                friendlyName = "KO - Skull Wings",
                category = ConsumableDataType.KO_Customization,
                guidString = "Tpxqe_lycUelySRHM8B0Vw",
                limitCount = 100,
                limitType = ConsumableDataLimitType.Usage
            },
            new KOConsumableData
            {
                friendlyName = "KO - Bear Claw",
                category = ConsumableDataType.KO_Customization,
                guidString = "ZtZnYBpKkECJlhHmkj4MiA",
                limitCount = 100,
                limitType = ConsumableDataLimitType.Usage
            },
            new KOConsumableData
            {
                friendlyName = "KO - Bees",
                category = ConsumableDataType.KO_Customization,
                guidString = "g3kxdlJv5kO8PuBXveM48w",
                limitCount = 100,
                limitType = ConsumableDataLimitType.Usage
            },
            new KOConsumableData
            {
                friendlyName = "KO - Cola",
                category = ConsumableDataType.KO_Customization,
                guidString = "wx--2TPTdEuGAqLCjs9Qag",
                limitCount = 100,
                limitType = ConsumableDataLimitType.Usage
            },
            new KOConsumableData
            {
                friendlyName = "KO - Frying Pan",
                category = ConsumableDataType.KO_Customization,
                guidString = "uGVFydNSokCXFAmXu3aceQ",
                limitCount = 100,
                limitType = ConsumableDataLimitType.Usage
            },
            new KOConsumableData
            {
                friendlyName = "KO - Fangs",
                category = ConsumableDataType.KO_Customization,
                guidString = "XOZcxx-Klkyhe-MDbTqiwA",
                limitCount = 100,
                limitType = ConsumableDataLimitType.Usage
            },
            new KOConsumableData
            {
                friendlyName = "KO - Grenade",
                category = ConsumableDataType.KO_Customization,
                guidString = "EAhk3ZZdXEmH5wRAXXT24Q",
                limitCount = 100,
                limitType = ConsumableDataLimitType.Usage
            },
            new KOConsumableData
            {
                friendlyName = "KO - Shield",
                category = ConsumableDataType.KO_Customization,
                guidString = "5AJin8T2iEG7BzOPOgx2HA",
                limitCount = 100,
                limitType = ConsumableDataLimitType.Usage
            },
            new KOConsumableData
            {
                friendlyName = "KO - Star Power",
                category = ConsumableDataType.KO_Customization,
                guidString = "yvqSbK2czkS2sUCRdrGaEw",
                limitCount = 100,
                limitType = ConsumableDataLimitType.Usage
            },
            new KOConsumableData
            {
                friendlyName = "KO - Ranger",
                category = ConsumableDataType.KO_Customization,
                guidString = "Av-wvjXvvkmNVSz7ZZnTiA",
                limitCount = 100,
                limitType = ConsumableDataLimitType.Usage
            }
        };
    }
}
