﻿using Carbon.Backend.Databasing;
using OpenlabsSDKV1.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Configs
{
    internal class SslConfig : CarbonConfigBase
    {
        public static readonly SslConfig Instance = Config.Get<SslConfig>();

        public X509Certificate2 GetCertificate() => new X509Certificate2(Database.CertificateDatabase.ReadBytes("origin.cert"));

        public override UUID GUID => (UUID)"7d3ba4934262466a8ee458923160b210";
        public override string Name => "Origin Server SSL Config";
    }
}
