﻿using Openlabs.Mgcxm.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon
{
    internal static class Constants
    {
        static Constants()
        {
            HOSTNAME = "localhost";
            HOSTNAME_SEPERATOR = ":";

            LOCAL_NAME_SERVER_HOSTNAME = HOSTNAME + HOSTNAME_SEPERATOR + NAME_SERVER_PORT;
            LOCAL_AUTH_SERVER_HOSTNAME = HOSTNAME + HOSTNAME_SEPERATOR + AUTH_SERVER_PORT;
            LOCAL_API_SERVER_HOSTNAME = HOSTNAME + HOSTNAME_SEPERATOR + API_SERVER_PORT;
            LOCAL_NOTIFICATIONS_SERVER_HOSTNAME = HOSTNAME + HOSTNAME_SEPERATOR + NOTIFICATIONS_SERVER_PORT;
            LOCAL_IMAGES_SERVER_HOSTNAME = HOSTNAME + HOSTNAME_SEPERATOR + IMAGES_SERVER_PORT;
            LOCAL_CDN_SERVER_HOSTNAME = HOSTNAME + HOSTNAME_SEPERATOR + CDN_SERVER_PORT;
            LOCAL_ADMIN_SERVER_HOSTNAME = HOSTNAME + HOSTNAME_SEPERATOR + ADMIN_SERVER_PORT;

            SELFHOST_NAME_SERVER_HOSTNAME = "ns.devtest.openlabs.live";
            SELFHOST_AUTH_SERVER_HOSTNAME = "auth.devtest.openlabs.live";
            SELFHOST_API_SERVER_HOSTNAME = "api.devtest.openlabs.live";
            SELFHOST_NOTIFICATIONS_SERVER_HOSTNAME = "notify.devtest.openlabs.live";
            SELFHOST_IMAGES_SERVER_HOSTNAME = "img.devtest.openlabs.live";
            SELFHOST_CDN_SERVER_HOSTNAME = "cdn.devtest.openlabs.live";
            SELFHOST_ADMIN_SERVER_HOSTNAME = "admin.devtest.openlabs.live";
        }

        public static string CreateUrl(bool https, string hostname, int port) 
            => string.Format("{0}://{1}:{2}/", https ? "https" : "http", hostname, port);

        public static string CreateUrlNoPort(bool https, string hostname)
            => string.Format("{0}://{1}/", https ? "https" : "http", hostname);

        public static string CreateNameServerUrl(bool https, string hostname, int port)
        {
            if (!Program.SELFHOST)
                return CreateUrl(https, HOSTNAME, port);
            return CreateUrlNoPort(https, hostname);
        }

        //
        // Sinks
        //
        public static readonly LoggerSink ApiSink = new LoggerSink("API");
        public static readonly LoggerSink AuthSink = new LoggerSink("Auth");
        public static readonly LoggerSink ImagesSink = new LoggerSink("Images");
        public static readonly LoggerSink NameSink = new LoggerSink("Name");
        public static readonly LoggerSink NotifySink = new LoggerSink("Notify");
        public static readonly LoggerSink AccessTokenSink = new LoggerSink("AcsTkn");
        public static readonly LoggerSink OneTimeTokenSink = new LoggerSink("OtTkn");
        public static readonly LoggerSink BackendProviderSink = new LoggerSink("BckPrv");
        public static readonly LoggerSink InitializationSink = new LoggerSink("Init");
        public static readonly LoggerSink LoginLockTokenSink = new LoggerSink("LgnTkn");

        //
        // Server Info
        //
        public static readonly bool SSL = false;

        public static readonly string HOSTNAME;
        public static readonly string HOSTNAME_SEPERATOR;

        public static readonly string LOCAL_NAME_SERVER_HOSTNAME;
        public static readonly string LOCAL_AUTH_SERVER_HOSTNAME ;
        public static readonly string LOCAL_API_SERVER_HOSTNAME;
        public static readonly string LOCAL_NOTIFICATIONS_SERVER_HOSTNAME;
        public static readonly string LOCAL_IMAGES_SERVER_HOSTNAME;
        public static readonly string LOCAL_CDN_SERVER_HOSTNAME;
        public static readonly string LOCAL_ADMIN_SERVER_HOSTNAME;

        public static readonly string SELFHOST_NAME_SERVER_HOSTNAME;
        public static readonly string SELFHOST_AUTH_SERVER_HOSTNAME;
        public static readonly string SELFHOST_API_SERVER_HOSTNAME;
        public static readonly string SELFHOST_NOTIFICATIONS_SERVER_HOSTNAME;
        public static readonly string SELFHOST_IMAGES_SERVER_HOSTNAME;
        public static readonly string SELFHOST_CDN_SERVER_HOSTNAME;
        public static readonly string SELFHOST_ADMIN_SERVER_HOSTNAME;

        public static readonly int NAME_SERVER_PORT = 2000;
        public static readonly int AUTH_SERVER_PORT = 2001;
        public static readonly int API_SERVER_PORT = 2002;
        public static readonly int NOTIFICATIONS_SERVER_PORT = 2003;
        public static readonly int IMAGES_SERVER_PORT = 2004;
        public static readonly int CDN_SERVER_PORT = 2005;
        public static readonly int ADMIN_SERVER_PORT = 2006;
    }
}
