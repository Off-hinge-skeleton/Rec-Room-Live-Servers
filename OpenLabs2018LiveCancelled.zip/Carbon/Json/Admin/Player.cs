﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json.Admin
{
    internal class Player : ObjectDTO
    {
        public int id;
        public string username;
        public string displayName;
        public int xp;
        public int level;
        public bool developer;
    }
}
