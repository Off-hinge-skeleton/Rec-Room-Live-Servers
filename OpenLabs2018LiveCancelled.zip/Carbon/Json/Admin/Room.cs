﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json.Admin
{
    internal class Room : ObjectDTO
    {
        public int roomId;
        public string name;
        public int accessibility;
        public int state;
        public string imageUrl;
        public int maxPlayers;
    }
}
