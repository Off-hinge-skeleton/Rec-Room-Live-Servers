﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json.Admin
{
    internal class Session : ObjectDTO
    {
        public long gameSessionId;
        public string activityName;
        public string activityId;
        public string imageUrl;
        public int maxPlayers;
    }
}
