﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json
{
    internal class Avatar : ObjectDTO
    {
        public string OutfitSelections { get; set; }
        public string HairColor { get; set; }
        public string SkinColor { get; set; }
        public string FaceFeatures { get; set; }
    }
}
