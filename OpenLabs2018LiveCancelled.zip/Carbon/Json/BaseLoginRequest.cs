﻿using Carbon.Backend;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json
{
    public class BaseLoginRequest
    {
        public string AppVersion;

        public PlatformType Platform;

        public string PlatformId;

        public long ClientTimestamp;

        public long BuildTimestamp;

        public string DeviceId;

        public string LoginLockToken;

        public string AuthParams;

        public string Verify;
    }

    public class CreateProfileRequest : BaseLoginRequest
    {
        public long Birthday;

        public string Email;
    }

    public class LoginToProfileRequest : BaseLoginRequest
    {
        public string Username;

        public string Password;

        public bool CacheLogin;
    }

    public class LoginToCachedProfileRequest : BaseLoginRequest
    {
        public long PlayerId;
    }
}
