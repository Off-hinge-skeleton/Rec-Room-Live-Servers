﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json.Challenges
{
    internal class ChallengeMap : ObjectDTO
    {
        public int ChallengeMapId { get; set; }
        public bool CompleteAll { get; set; }
        public DateTime StartAt { get; set; }
        public DateTime EndAt { get; set; }
        public DateTime ServerTime { get; set; }
        public RecNetChallenge[] Challenges { get; set; }
        public RecNetGiftDrop[] Gifts { get; set; }
        public string ChallengeThemeString { get; set; }
        public int ChallengeThemeId { get; set; }
    }
}
