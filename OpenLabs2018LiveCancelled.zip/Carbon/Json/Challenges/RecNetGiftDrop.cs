﻿using Carbon.Json.Storefronts;
using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json.Challenges
{
    internal class RecNetGiftDrop : ObjectDTO
    {
        public long GiftDropId { get; set; }
        public string AvatarItemDesc { get; set; }
        public string ConsumableItemDesc { get; set; }
        public string EquipmentPrefabName { get; set; }
        public string EquipmentModificationGuid { get; set; }
        public StorefrontType StorefrontType { get; set; }
        public int Xp { get; set; }
        public int Level { get; set; }
        public GiftContext GiftContext { get; set; }
        public GiftRarity GiftRarity { get; set; }
    }
}
