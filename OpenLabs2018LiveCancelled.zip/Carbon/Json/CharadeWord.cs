﻿using Newtonsoft.Json;
using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json
{
    internal class CharadeWord : ObjectDTO
    {
        [JsonProperty("EN_US")] public string Word { get; set; }
        public int Difficulty { get; set; }
    }
}
