﻿using Carbon.Json.Chats;
using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json

{
    public class MessageContent
    {
        public int Type { get; set; }
        public int Version { get; set; }
        public string Data { get; set; }
    }
    public class ChatCreateInfo
    {
        public List<int> PlayerIds { get; set; }
        public string MessageContents { get; set; }

    }

    public enum ChatResults
    {
        Success,

        InvalidArguments,

        ThreadNotFound,

        MembershipNotFound,

        PlayerAlreadyOnThread,

        CannotMessagePlayer
    }

    public class ChatCreateResponse
    {
        public ChatThread ChatThread { get; set; }
        public ChatResults ChatResult { get; set; }
    }
    public class ChatMessage : ObjectDTO
    {
        public long ChatMessageId { get; set; }
        public long ChatThreadId { get; set; }
        public int SenderPlayerId { get; set; }
        public DateTime TimeSent { get; set; }
        public string Contents { get; set; }
    }


    public class ChatSendData
    {
        public long ChatId { get; set; }
        public string MessageContents { get; set; }
    }

    public class ChatSendResponse
    {
        public ChatResults ChatResult { get; set; }
        public ChatMessage ChatMessage { get; set; }

    }


    public class ChatReadData
    {
        public long ChatId { get; set; }
        public long MessageId { get; set; }
    }

}
