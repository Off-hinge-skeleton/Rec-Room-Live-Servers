﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json.Chats
{
    public class ChatThread : ObjectDTO
    {
        public long ChatThreadId { get; set; }
        public long LastReadMessageId { get; set; }
        public List<ChatMessage>? Messages { get; set; }
        public List<int>? PlayerIds { get; set; }
        
    }
}
