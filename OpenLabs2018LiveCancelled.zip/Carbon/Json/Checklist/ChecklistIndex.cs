﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json.Checklist
{
    internal class ChecklistIndex : ObjectDTO
    {
        public int Order { get; set; }
        public ObjectiveType Objective { get; set; }
        public int Count { get; set; }
        public int CreditAmount { get; set; }
    }
}
