﻿using Openlabs.Mgcxm.Assets;
using Steamworks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json
{
    internal class Consumable : ObjectDTO
    {
        public long Id { get; set; }
        public string ConsumableItemDesc { get; set; }
        public DateTime CreatedAt { get; set; }
        public int Count { get; set; }
        public int UnlockedLevel { get; set; }
        public bool IsActive { get; set; }
    }

    public enum ConsumableType
    {
        RootBeer = 1,
        Pizza = 2,
        Film = 3,
        
    }

    

}
