﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json
{
    internal class Equipment : ObjectDTO
    {
        public string PrefabName { get; set; }
        public string ModificationGuid { get; set; }
        public int UnlockedLevel { get; set; }
        public bool? Favorited { get; set; }
    }
}
