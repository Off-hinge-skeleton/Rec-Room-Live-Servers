﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json.Events
{
    internal class FeaturedEvent : ObjectDTO
    {
        public long EventId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public string PosterImageName { get; set; }
        public long CreatorPlayerId { get; set; }
    }
}
