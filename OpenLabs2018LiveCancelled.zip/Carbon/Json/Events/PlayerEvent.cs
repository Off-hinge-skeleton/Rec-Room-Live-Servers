﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json.Events
{
    public enum PlayerEventResponseType
    {
        Yes,
        Maybe,
        No,
        Pending
    }

    internal class PlayerEventResponse : ObjectDTO
    {
        public long PlayerEventResponseId { get; set; }
        public long PlayerEventId { get; set; }
        public long PlayerId { get; set; }
        public DateTime CreatedAt { get; set; }
        public PlayerEventResponseType Type { get; set; }
    }

    internal class PlayerEventDetails : ObjectDTO
    {
        public long PlayerEventId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime StartTime { get; set; }
        public long CreatorPlayerId { get; set; }
        public int AttendeeCount { get; set; }
        public long RoomId { get; set; }
    }

    internal class PlayerEventResponseDetails
    {
        public PlayerEventDetails PlayerEvent { get; set; }
        public PlayerEventResponse PlayerEventResponse { get; set; }
    }

    internal class PlayerEventList : ObjectDTO
    {
        public PlayerEventDetails[] Created { get; set; }
        public PlayerEventResponseDetails[] Responses { get; set; }
    }
}
