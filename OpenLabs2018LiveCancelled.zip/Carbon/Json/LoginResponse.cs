﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json
{
    internal class LoginResponse : ObjectDTO
    {
        public string Error { get; set; }
        public Profile Player { get; set; }
        public string Token { get; set; }
        public bool FirstLoginOfTheDay { get; set; }
        public long AnalyticsSessionId { get; set; }
        public bool CanUseScreenMode { get; set; }
    }
}
