﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json.Matchmaking
{
    public enum PhotonRegionId
    {
        eu,
        us,
        asia,
        jp,
        au = 5,
        usw,
        sa,
        cae,
        kr,
        @in,
        ru,
        rue,
        none = 4
    }

    public abstract class BaseGameSessionRequest
    {
        public long[] ExpectedPlayerIds;
        public List<CloudRegionPing> RegionPings;
    }

    public class CloudRegionPing
    {
        public CloudRegionPing(PhotonRegionId regionId, int ping)
        {
            this.RegionId = regionId.ToString();
            this.Ping = ping;
        }

        private string RegionId;
        private int Ping;
    }

    public class CreateCustomGameSessionRequest : BaseGameSessionRequest
    {
        public bool IsSandbox;
        public string ActivityLevelId;
    }

    public class JoinEventRequest : BaseGameSessionRequest
    {
        public long EventId;
    }

    public class JoinRoomRequest : BaseGameSessionRequest
    {
        public long RoomId;
        public bool Private;
    }

    public class JoinGameSessionRequest : BaseGameSessionRequest
    {
        public long GameSessionId;
    }

    public class JoinPlayerRequest : BaseGameSessionRequest
    {
        public long PlayerId;
    }

    public class JoinRandomGameSessionRequest : BaseGameSessionRequest
    {
        public string[] ActivityLevelIds;
    }

    public class ChangeActivityRequest
    {
        public long GameSessionId;
        public string ActivityId;
        public string ActivityLevelId;
    }

    public class ChangeNameRequest
    {
        public long GameSessionId;
        public string Name;
    }

    public class ChangeMaxCapacityRequest
    {
        public long GameSessionId;
        public int MaxCapacity;
    }

    public class SetInProgressRequest
    {
        public long GameSessionId;
        public bool InProgress;
    }

    public class SetPrivateRequest
    {
        public long GameSessionId;
        public bool Private;
    }

    public enum GameSessionJoinResult
    {
        Success,
        FailedToConnectToRegion,
        FailedToConnectToRoom,
        FailedToSpawnPlayer
    }

    public class ReportGameJoinResultRequest
    {
        public long GameSessionId;
        public string RegionId;
        public string RoomId;
        public GameSessionJoinResult Result;
        public long? RecRoomId;
        public long MasterPlayerId;
    }

    public class AddBlockedGameSessionRequest
    {
        public long GameSessionId;
    }
}
