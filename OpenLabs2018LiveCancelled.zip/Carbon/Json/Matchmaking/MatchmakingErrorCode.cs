﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json.Matchmaking
{
    public enum MatchmakingErrorCode
    {
        Success,
        NoSuchGame,
        PlayerNotOnline,
        InsufficientSpace,
        EventNotStarted,
        EventAlreadyFinished,
        EventCreatorNotReady,
        BlockedFromRoom,
        ProfileLocked,
        NoBirthday,
        MarkedForDelete,
        JuniorNotAllowed,
        Banned,
        AlreadyInBestGameSession,
        ScreenModeNotAllowed,
        VRModeNotAllowed,
        UpdateRequired,
        NoSuchRoom = 20,
        RoomCreatorNotReady,
        RoomIsNotActive,
        RoomBlockedByCreator,
        RoomBlockingCreator,
        RoomIsPrivate
    }
}
