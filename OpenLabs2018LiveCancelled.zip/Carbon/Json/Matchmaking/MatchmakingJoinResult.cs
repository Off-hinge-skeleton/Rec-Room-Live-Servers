﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json.Matchmaking
{
    internal class MatchmakingJoinResult : ObjectDTO
    {
        public MatchmakingErrorCode Result { get; set; }
        public GameSession GameSession { get; set; }
    }
}
