﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json
{
    internal class MatchmakingParams : ObjectDTO
    {
        public float PreferFullRoomsFrequency { get; set; }
        public float PreferEmptyRoomsFrequency { get; set; }
    }
}
