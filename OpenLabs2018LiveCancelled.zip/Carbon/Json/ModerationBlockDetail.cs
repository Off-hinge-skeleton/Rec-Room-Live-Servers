﻿using Carbon.Json.Matchmaking;
using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json
{
    public enum ReportCategory
    {
        Moderator = -1,
        Unknown,
        DEPRECATED_MicrophoneAbuse,
        Harassment,
        Cheating,
        DEPRECATED_ImmatureBehavior,
        AFK,
        Misc,
        Underage,
        VoteKick = 10,
        CoC_Underage = 100,
        CoC_Sexual,
        CoC_Discrimination,
        CoC_Trolling,
        CoC_NameOrProfile,
        IssuingInaccurateReports = 1000
    }

    internal class ModerationBlockDetail : ObjectDTO
    {
        public static readonly ModerationBlockDetail None = new ModerationBlockDetail
        {
            ReportCategory = ReportCategory.Unknown,
            Duration = 0,
            GameSessionId = -1,
            Message = ""
        };

        public ReportCategory ReportCategory { get; set; }
        public int Duration { get; set; }
        public long GameSessionId { get; set; }
        public string Message { get; set; }

        public DateTime? EndTime { get; set; }
    }

    public enum ResultType
    {
        Success,
        NoSuchGame,
        PlayerNotOnline,
        InsufficientSpace,
        EventNotStarted,
        EventAlreadyFinished,
        EventCreatorNotReady,
        BlockedFromRoom,
        ProfileLocked,
        NoBirthday,
        MarkedForDelete,
        JuniorNotAllowed,
        Banned,
        AlreadyInBestGameSession,
        ScreenModeNotAllowed,
        VRModeNotAllowed,
        UpdateRequired,
        NoSuchRoom = 20,
        RoomCreatorNotReady,
        RoomIsNotActive,
        RoomBlockedByCreator,
        RoomBlockingCreator,
        RoomIsPrivate
    }


    internal class ModerationResult
    {
        public ResultType Result { get; set; }
        public GameSession? GameSession { get; set; }
    }

    internal class reportdetails
    {
        public long PlayerIdReported { get; set; }
        public ReportCategory ReportCategory { get; set; }
        public string Details { get; set; }

        public float HeightReporter { get; set; }

        public float HeightReported { get; set; }

        public long RoomId {  get; set; }

    }

    internal class baninfo
    {

        public ReportCategory banType { get; set; }
        public int duration { get; set; }


    }
}
