﻿using Openlabs.Mgcxm.Assets;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json
{
    internal class NameServerResponse : ObjectDTO
    {
        public string Auth { get; set; }
        public string API { get; set; }
        public string WWW { get; set; }
        public string Notifications { get; set; }
        public string Images { get; set; }
    }
}
