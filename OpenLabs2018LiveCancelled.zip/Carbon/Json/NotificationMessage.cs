﻿using Newtonsoft.Json;
using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json
{
    internal class NotificationMessage : ObjectDTO
    {
        public static NotificationMessage Create(long fromPlayerId, NotificationMessageType messageType, string data = "", long? roomId = null, long? playerEventId = null)
        {
            return new NotificationMessage
            {
                Id = Openlabs.Mgcxm.Common.Random.Range(10000, 100000000),
                FromPlayerId = fromPlayerId,
                SentTime = DateTime.Now,
                Type = messageType,
                Data = data,
                RoomId = roomId,
                PlayerEventId = playerEventId
            };
        }

        public long Id { get; set; }
        public long FromPlayerId { get; set; }
        public DateTime SentTime { get; set; }
        public NotificationMessageType Type { get; set; }
        public string Data { get; set; }
        public long? RoomId { get; set; }
        public long? PlayerEventId { get; set; }

        [JsonIgnore]
        public object ExtraData
        {
            get
            {
                if (IsIntDataType())
                    return int.Parse(Data);
                else if (IsLongDataType())
                    return long.Parse(Data);

                return null!;
            }
        }

        public bool IsIntDataType()
        {
            return Type == NotificationMessageType.GameJoinFailed ||
                   Type == NotificationMessageType.PlayerCheer ||
                   Type == NotificationMessageType.PlayerCheerAnonymous;
        }

        public bool IsLongDataType()
        {
            return Type == NotificationMessageType.RoomCoOwnerRemoved ||
                   Type == NotificationMessageType.RoomCoOwnerAdded;
        }
    }

    public enum NotificationMessageType
    {
        GameInvite,
        GameInviteDeclined,
        GameJoinFailed,
        PartyActivitySwitch,
        FriendInvite,
        VoteToKick,
        RequestGameInvite = 10,
        RequestGameInviteDeclined,
        FriendStatusOnline = 20,
        TextMessage = 30,
        FriendRequestAccepted = 40,
        PlayerCheer = 50,
        PlayerCheerAnonymous,
        RoomCoOwnerAdded = 60,
        RoomCoOwnerRemoved,
        CreatorPublishedNewRoom = 70,
        PlayerEventInvitation = 81,
        CoachMessage = 100
    }
}
