﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json.Notifications
{
    internal class ApiRequestPushNotification : PushNotificationBase
    {
        [JsonProperty("api")] public string Api { get; set; }
        [JsonProperty("param")] public object[] Parameters { get; set; }
    }
}
