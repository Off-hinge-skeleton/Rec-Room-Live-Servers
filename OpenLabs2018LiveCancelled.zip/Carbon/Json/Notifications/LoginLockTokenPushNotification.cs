﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json.Notifications
{
    internal class LoginLockTokenPushNotification : PushNotificationBase
    {
        public long SessionId { get; set; }
        public string LoginLockToken { get; set; }
    }
}
