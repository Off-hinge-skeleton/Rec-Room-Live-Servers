﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json.Notifications
{
    internal class PlayerSubscriptionList : ObjectDTO
    {
        public List<long> PlayerIds { get; set; }
    }
}
