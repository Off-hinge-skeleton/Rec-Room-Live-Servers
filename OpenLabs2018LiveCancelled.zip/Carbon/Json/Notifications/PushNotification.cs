﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json.Notifications
{
    public enum PushNotificationId
    {
        RelationshipChanged = 1,
        MessageReceived,
        MessageDeleted,
        PresenceHeartbeatResponse,
        SubscriptionListUpdated = 9,
        SubscriptionUpdateProfile = 11,
        SubscriptionUpdatePresence,
        SubscriptionUpdateGameSession,
        SubscriptionUpdateRoom,
        ModerationQuitGame = 20,
        ModerationUpdateRequired,
        ModerationKick,
        ModerationKickAttemptFailed,
        ServerMaintenance = 25,
        GiftPackageReceived = 30,
        ProfileJuniorStatusUpdate = 40,
        RelationshipsInvalid = 50,
        StorefrontBalanceAdd = 60,
        ConsumableMappingAdded = 70,
        ConsumableMappingRemoved,
        PlayerEventCreated = 80,
        PlayerEventUpdated,
        PlayerEventDeleted,
        PlayerEventResponseChanged,
        PlayerEventResponseDeleted,
        ChatMessageReceived = 90
    }


    internal abstract class PushNotificationBase
    {

    }

    internal class PushNotificationObject : PushNotificationBase
    {
        public PushNotificationId Id { get; set; }
        public object Msg { get; set; }
    }

    internal class PushNotificationDto<T> : PushNotificationBase
        where T : ObjectDTO
    {
        public PushNotificationId Id { get; set; }
        public T Msg { get; set; }
    }
}
