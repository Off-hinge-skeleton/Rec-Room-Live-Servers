﻿using Newtonsoft.Json;
using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json
{
    public class Objective : ObjectDTO
    {
        [JsonProperty("type")] public ObjectiveType ObjectiveType { get; set; } = ObjectiveType.Default;
        [JsonProperty("score")] public int RequiredScore { get; set; }
    }
    public class GameObjective
    {
        public ObjectiveType objectiveType { get; set; }
        public int additionalXp { get; set; }
        public bool inParty { get; set; }

    }
    public enum ObjectiveType
    {
        Default = -1,
        FirstSessionOfDay = 1,
        AddAFriend,
        PartyUp,
        AllOtherChallenges,
        LevelUp,
        CheerAPlayer,
        PointedAtPlayer,
        CheerARoom,
        SubscribeToPlayer,
        DailyObjective1,
        DailyObjective2,
        DailyObjective3,
        AllDailyObjectives,
        CompleteAnyDaily,
        CompleteAnyWeekly,
        OOBE_GoToLockerRoom = 20,
        OOBE_GoToActivity,
        OOBE_FinishActivity,
        NUX_PunchcardObjective = 25,
        NUX_AllPunchcardObjectives,
        GoToRecCenter = 30,
        FinishActivity,
        VisitACustomRoom,
        CreateACustomRoom,
        ScoreBasketInRecCenter = 35,
        UploadPhotoToRecNet,
        UpdatePlayerBio,
        SaveOutfitSlot,
        PurchaseClothingItem,
        PurchaseNonClothingItem,
        CharadesGames = 100,
        CharadesWinsPerformer,
        CharadesWinsGuesser,
        DiscGolfWins = 200,
        DiscGolfGames,
        DiscGolfHolesUnderPar,
        DodgeballWins = 300,
        DodgeballGames,
        DodgeballHits,
        PaddleballGames = 400,
        PaddleballWins,
        PaddleballScores,
        PaintballAnyModeGames = 500,
        PaintballAnyModeWins,
        PaintballAnyModeHits,
        PaintballCTFWins = 600,
        PaintballCTFGames,
        PaintballCTFHits,
        PaintballFlagCaptures,
        PaintballTeamBattleWins = 700,
        PaintballTeamBattleGames,
        PaintballTeamBattleHits,
        PaintballFreeForAllWins = 710,
        PaintballFreeForAllGames,
        PaintballFreeForAllHits,
        SoccerWins = 800,
        SoccerGames,
        SoccerGoals,
        QuestGames = 1000,
        QuestWins,
        QuestPlayerRevives,
        QuestEnemyKills,
        QuestGames_Goblin1 = 1010,
        QuestWins_Goblin1,
        QuestPlayerRevives_Goblin1,
        QuestEnemyKills_Goblin1,
        QuestGames_Goblin2 = 1020,
        QuestWins_Goblin2,
        QuestPlayerRevives_Goblin2,
        QuestEnemyKills_Goblin2,
        QuestGames_Scifi1 = 1030,
        QuestWins_Scifi1,
        QuestPlayerRevives_Scifi1,
        QuestEnemyKills_Scifi1,
        QuestGames_Pirate1 = 1040,
        QuestWins_Pirate1,
        QuestPlayerRevives_Pirate1,
        QuestEnemyKills_Pirate1,
        ArenaGames = 2000,
        ArenaWins,
        ArenaPlayerRevives,
        ArenaHeroTags,
        ArenaBotTags,
        RecRoyaleGames = 3000,
        RecRoyaleWins,
        RecRoyaleTags
    }


    public class GiftDropCap
    {
        public int GiftDrops { get; set; }
        public DateTime TimeUntilReset { get; set; }

    }
}
