﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json
{
    internal class ObjectiveProgressIndex : ObjectDTO
    {
        public int Index { get; set; }
        public int Group { get; set; }
        public float Progress { get; set; }
        public float VisualProgress { get; set; }
        public bool IsCompleted { get; set; }
        public bool IsRewarded { get; set; }
    }

    internal class ObjectiveProgressGroup : ObjectDTO
    {
        public int Group { get; set; }
        public bool IsCompleted { get; set; }
        public DateTime ClearedAt { get; set; }
    }

    internal class ObjectiveProgress : ObjectDTO
    {
        public List<ObjectiveProgressIndex> Objectives { get; set; }
        public List<ObjectiveProgressGroup> ObjectiveGroups { get; set; }
    }

    

   
}
