﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json
{
    internal class PhotonServer : ObjectDTO
    {
        public string PunAppId { get; set; }
        public string VoiceAppId { get; set; }
    }
}
