﻿using Carbon.Backend;
using Newtonsoft.Json;
using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json
{
    internal class PlatformId : ObjectDTO
    {
        public PlatformType Platform { get; set; }
        [JsonProperty("PlatformId")] public string Id { get; set; }
    }

    public class platformId
    {
        public PlatformType Platform { get; set; }
        public string? PlatformId { get; set; }
    }
}
