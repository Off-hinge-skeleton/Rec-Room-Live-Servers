﻿using Carbon.Json.Matchmaking;
using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json
{
    internal class PlayerPresence : ObjectDTO
    {
        public long PlayerId { get; set; }
        public bool IsOnline { get; set; }
        public bool InScreenMode { get; set; }
        public GameSession GameSession { get; set; }
    }
}
