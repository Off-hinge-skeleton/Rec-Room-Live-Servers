﻿using Carbon.Backend;
using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json
{
    internal class Profile : ObjectDTO, ICloneable<Profile>
    {
        public static readonly Profile Empty = new Profile
        {
            Id = 0,
            Username = "",
            DisplayName = "",
            Bio = "",
            XP = 0,
            Level = 0,
            RegistrationStatus = RegistrationType.Unregistered,
            Developer = false,
            CanReceiveInvites = false,
            ProfileImageName = "",
            JuniorProfile = false,
            ForceJuniorImages = false,
            PendingJunior = false,
            HasBirthday = false,
            AvoidJuniors = false,
            PlayerReputation = new Reputation
            {
                Noteriety = 0,
                CheerGeneral = 0,
                CheerHelpful = 0,
                CheerGreatHost = 0,
                CheerSportsman = 0,
                CheerCreative = 0,
                CheerCredit = 0,
                SubscriberCount = 0,
                SubscribedCount = 0,
                SelectedCheer = null
            },
            PlatformId = new PlatformId
            {
                Platform = PlatformType.LINUX_HEADLESS_BOT,
                Id = ""
            }
        };

        public Profile() { }
        public Profile(
            long id, 
            string username, 
            string displayName, 
            string bio, 
            int xP, 
            int level, 
            RegistrationType registrationStatus, 
            bool developer, 
            bool canReceiveInvites, 
            string profileImageName, 
            bool juniorProfile, 
            bool forceJuniorImages, 
            bool pendingJunior, 
            bool hasBirthday, 
            bool avoidJuniors, 
            Reputation playerReputation, 
            PlatformId platformId) : this()
        {
            Id = id;
            Username = username;
            DisplayName = displayName;
            Bio = bio;
            XP = xP;
            Level = level;
            RegistrationStatus = registrationStatus;
            Developer = developer;
            CanReceiveInvites = canReceiveInvites;
            ProfileImageName = profileImageName;
            JuniorProfile = juniorProfile;
            ForceJuniorImages = forceJuniorImages;
            PendingJunior = pendingJunior;
            HasBirthday = hasBirthday;
            AvoidJuniors = avoidJuniors;
            PlayerReputation = playerReputation;
            PlatformId = platformId;
        }

        public Profile Clone()
        {
            return new Profile(
                Id, 
                Username, 
                DisplayName, 
                Bio, 
                XP, 
                Level, 
                RegistrationStatus,
                Developer,
                CanReceiveInvites,
                ProfileImageName, 
                JuniorProfile, 
                ForceJuniorImages, 
                PendingJunior, 
                HasBirthday,
                AvoidJuniors, 
                PlayerReputation,
                PlatformId);
        }

        public void ModifyProperties(Profile profile)
        {
            Username = profile.Username;
            DisplayName = profile.DisplayName;
            Bio = profile.Bio;
            XP = profile.XP;
            Level = profile.Level;
            RegistrationStatus = profile.RegistrationStatus;
            Developer = profile.Developer;
            CanReceiveInvites = profile.CanReceiveInvites;
            ProfileImageName = profile.ProfileImageName;
            JuniorProfile = profile.JuniorProfile;
            ForceJuniorImages = profile.ForceJuniorImages;
            PendingJunior = profile.PendingJunior;
            HasBirthday = profile.HasBirthday;
            AvoidJuniors = profile.HasBirthday;
            PlayerReputation = profile.PlayerReputation;
            PlatformId = profile.PlatformId;
        }

        public long Id { get; set; }
        public string Username { get; set; }
        public string DisplayName { get; set; }
        public string Bio { get; set; }
        public int XP { get; set; }
        public int Level { get; set; }
        public RegistrationType RegistrationStatus { get; set; }
        public bool Developer { get; set; }
        public bool CanReceiveInvites { get; set; }
        public string ProfileImageName { get; set; }
        public bool JuniorProfile { get; set; }
        public bool ForceJuniorImages { get; set; }
        public bool PendingJunior { get; set; }
        public bool HasBirthday { get; set; }
        public bool AvoidJuniors { get; set; }
        public Reputation PlayerReputation { get; set; }
        public PlatformId PlatformId { get; set; }
    }

    public enum RegistrationType
    {
        Unregistered,
        PendingEmailVerification,
        Registered
    }
}
