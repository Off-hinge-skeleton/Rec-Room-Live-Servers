﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json
{
    internal class RecNetResult : ObjectDTO
    {
        public bool Success { get; set; }
        public string Message { get; set; }
    }
}
