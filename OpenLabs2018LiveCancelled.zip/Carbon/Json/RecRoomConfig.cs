﻿using Openlabs.Mgcxm.Assets;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json
{
    internal class RecRoomConfig : ObjectDTO
    {
        public string MessageOfTheDay { get; set; }
        public string CdnBaseUri { get; set; }
        public MatchmakingParams MatchmakingParams { get; set; }
        public ServerMaintenanceDTO ServerMaintenance { get; set; }
        public List<LevelProgressionEntry> LevelProgressionMaps { get; set; }
        public List<List<Objective>> DailyObjectives { get; set; }
        public List<Setting> ConfigTable { get; set; }
        public PhotonConfig PhotonConfig { get; set; }
    }
}
