﻿using Carbon.Backend.AccessTokens;
using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json
{
    internal class Relationship : ObjectDTO
    {
        public long PlayerID { get; set; }
        public RelationshipType RelationshipType { get; set; }
        public ReciprocalStatus Muted { get; set; }
        public ReciprocalStatus Ignored { get; set; }
        public ReciprocalStatus Favorited { get; set; }

        public ReciprocalStatus Block(AccessToken blocker, bool ignore)
        {
            if (ignore) RelationshipType = RelationshipType.None;
            return Ignored = ignore ? ReciprocalStatus.Local : ReciprocalStatus.None;
        }

        public ReciprocalStatus Mute(AccessToken muter, bool mute)
        {
            return Muted = mute ? ReciprocalStatus.Local : ReciprocalStatus.None;
        }

        public ReciprocalStatus Favorite(AccessToken favoriter, bool favorite)
        {
            return Favorited = favorite ? ReciprocalStatus.Local : ReciprocalStatus.None;
        }
    }

    public enum RelationshipType
    {
        None,
        FriendRequestSent,
        FriendRequestReceived,
        Friend
    }

    public enum ReciprocalStatus
    {
        None,
        Local,
        Remote,
        Mutual
    }

    internal class favoritedata
    {
        public long Id { get; set; }
    }
}
