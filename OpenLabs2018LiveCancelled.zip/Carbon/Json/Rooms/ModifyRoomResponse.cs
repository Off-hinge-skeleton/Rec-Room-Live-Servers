﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json.Rooms
{
    public enum ModifyRoomResultCode
    {
        Success,
        Unknown,
        PermissionDenied,
        RoomNotActive,
        RoomDoesNotExist,
        RoomHasNoDataBlob,
        DuplicateName = 10,
        ReservedName,
        InappropriateName,
        InappropriateDescription,
        TooManyRooms = 20,
        InvalidMaxPlayers = 30,
        DataHistoryDoesNotExist = 40,
        DataHistoryAlreadyActive,
        RoomUnderModerationReview = 100,
        PlayerHasRoomUnderModerationReview,
        AccessibilityUnderModerationLock,
        JuniorStatusFail = 200
    }

    internal class ModifyRoomDetailsResponse : ObjectDTO
    {
        public ModifyRoomResultCode Result { get; set; }
        public RoomDetailsCombine Room { get; set; }
    }

    internal class ModifyRoomResponse : ObjectDTO
    {
        public ModifyRoomResultCode Result { get; set; }
        public Room Room { get; set; }
    }
}
