﻿using Carbon.Backend.AccessTokens;
using Carbon.Backend.Statics;
using Openlabs.Mgcxm.Assets;
using OpenlabsSDKV1.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json.Rooms
{
    public enum RoomState
    {
        Active,
        PendingJunior = 11,
        Moderation_PendingReview = 100,
        Moderation_Closed,
        MarkedForDelete = 1000
    }

    public enum RoomAccessibility
    {
        Private,
        Public,
        Unlisted
    }

    public enum ScreenModeSupportType
    {
        Isolated,
        Mixed,
        Blocked
    }

    internal class Room : ObjectDTO, ICloneable<Room>
    {
        public Room() { }
        public Room(
            long roomId, 
            string name, 
            string description, 
            long creatorPlayerId, 
            string imageName, 
            string activityLevelId,
            RoomState state, 
            RoomAccessibility accessibility, 
            bool isSandbox, 
            bool instanced, 
            ScreenModeSupportType screenModeSupport) : this()
        {
            RoomId = roomId;
            Name = name;
            Description = description;
            CreatorPlayerId = creatorPlayerId;
            ImageName = imageName;
            ActivityLevelId = activityLevelId;
            State = state;
            Accessibility = accessibility;
            IsSandbox = isSandbox;
            Instanced = instanced;
            ScreenModeSupport = screenModeSupport;
        }

        public static Room Create(
            AccessToken accessToken, 
            string name, 
            string description,
            string activityLevelId,
            bool isSandbox,
            bool instanced,
            RoomAccessibility accessibility,
            string imageName = "DefaultRoomImage.png")
        {
            return new Room(Openlabs.Mgcxm.Common.Random.Range(1000000, 1000000000),
                name, description, accessToken.PlayerId, imageName, activityLevelId, RoomState.Active,
                accessibility, isSandbox, instanced, ScreenModeSupportType.Mixed);
        }

        public bool IsRoomLockedForMe(AccessToken accessToken)
        {
            if (CreatorPlayerId == accessToken.PlayerId) return false;
            return Accessibility == RoomAccessibility.Private;
        }

        public bool CanSeeRoomOnBrowsePage(AccessToken accessToken)
        {
            return Accessibility == RoomAccessibility.Public;
        }

        public bool SupportsScreenMode()
        {
            return (ScreenModeSupport == ScreenModeSupportType.Isolated ||
                   ScreenModeSupport == ScreenModeSupportType.Mixed) &&
                   ScreenModeSupport != ScreenModeSupportType.Blocked;
        }

        public bool SupportsVR() => true;

        public Room Clone()
        {
            return new Room
            {
                RoomId = RoomId,
                Name = Name,
                Description = Description,
                CreatorPlayerId = CreatorPlayerId,
                ImageName = ImageName,
                ActivityLevelId = ActivityLevelId,
                State = State,
                Accessibility = Accessibility,
                IsSandbox = IsSandbox,
                Instanced = Instanced,
                ScreenModeSupport = ScreenModeSupport
            };
        }

        public void ModifyProperties(Room room)
        {
            Name = room.Name;
            Description = room.Description;
            CreatorPlayerId = room.CreatorPlayerId;
            ImageName = room.ImageName;
            ActivityLevelId = room.ActivityLevelId;
            State = room.State;
            Accessibility = room.Accessibility;
            IsSandbox = room.IsSandbox;
            Instanced = room.Instanced;
            ScreenModeSupport = room.ScreenModeSupport;
        }

        public RoomDetails CreateRoomDetails(AccessToken accessToken)
        {
            return new RoomDetails
            {
                DataBlobName = "",
                MaxPlayers = ActivityLevelIds.GetCapacity(ActivityLevelId),
                AccessibilityLocked = IsRoomLockedForMe(accessToken),

                CreatedAt = DateTime.Now,
                ModifiedAt = DateTime.MinValue,
                StateModifiedAt = DateTime.MinValue,
                DataModifiedAt = DateTime.Now,
                LastVisitedAt = DateTime.MinValue,

                VisitorCount = 0,
                VisitCount = 0,

                CheerCount = 0,
                ReportCount = 0,

                Hosts = new List<long>(),
                CoOwners = new List<long>()
            };
        }

        public long RoomId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public long CreatorPlayerId { get; set; }
        public string ImageName { get; set; }
        public string ActivityLevelId { get; set; }
        public RoomState State { get; set; }
        public RoomAccessibility Accessibility { get; set; }
        public bool IsSandbox { get; set; }
        public bool Instanced { get; set; }
        public ScreenModeSupportType ScreenModeSupport { get; set; }
    }
}
