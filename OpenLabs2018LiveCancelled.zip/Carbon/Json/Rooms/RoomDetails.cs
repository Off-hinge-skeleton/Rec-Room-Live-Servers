﻿using Carbon.Backend.AccessTokens;
using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json.Rooms
{
    internal class RoomDetails : ObjectDTO
    {
        public void Initialize(AccessToken accessToken, Room room)
        {
            // can modify privacy settings
            AccessibilityLocked = room.CreatorPlayerId == accessToken.PlayerId;
        }

        public string DataBlobName { get; set; }
        public int MaxPlayers { get; set; }
        public bool AccessibilityLocked { get; set; }

        public DateTime CreatedAt { get; set; }
        public DateTime ModifiedAt { get; set; }
        public DateTime StateModifiedAt { get; set; }
        public DateTime DataModifiedAt { get; set; }
        public DateTime LastVisitedAt { get; set; }

        public int VisitorCount { get; set; }
        public int VisitCount { get; set; }

        public int CheerCount { get; set; }
        public int ReportCount { get; set; }

        public List<long> CoOwners { get; set; }
        public List<long> Hosts { get; set; }
    }
}
