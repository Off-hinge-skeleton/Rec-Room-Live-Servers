﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json.Rooms
{
    internal class RoomDetailsCombine : ObjectDTO
    {
        public RoomDetailsCombine(Room room, RoomDetails roomDetails)
        {
            RoomId = room.RoomId;
            Name = room.Name;
            Description = room.Description;
            CreatorPlayerId = room.CreatorPlayerId;
            ImageName = room.ImageName;
            ActivityLevelId = room.ActivityLevelId;
            State = room.State;
            Accessibility = room.Accessibility;
            IsSandbox = room.IsSandbox;
            Instanced = room.Instanced;
            ScreenModeSupport = room.ScreenModeSupport;

            DataBlobName = roomDetails.DataBlobName;
            MaxPlayers = roomDetails.MaxPlayers;
            AccessibilityLocked = roomDetails.AccessibilityLocked;

            CreatedAt = roomDetails.CreatedAt;
            ModifiedAt = roomDetails.ModifiedAt;
            StateModifiedAt = roomDetails.StateModifiedAt;
            DataModifiedAt = roomDetails.DataModifiedAt;
            LastVisitedAt = roomDetails.LastVisitedAt;

            VisitorCount = roomDetails.VisitorCount;
            VisitCount = roomDetails.VisitCount;

            CheerCount = roomDetails.CheerCount;
            ReportCount = roomDetails.ReportCount;

            CoOwners = roomDetails.CoOwners;
            Hosts = roomDetails.Hosts;
        }

        public long RoomId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public long CreatorPlayerId { get; set; }
        public string ImageName { get; set; }
        public string ActivityLevelId { get; set; }
        public RoomState State { get; set; }
        public RoomAccessibility Accessibility { get; set; }
        public bool IsSandbox { get; set; }
        public bool Instanced { get; set; }
        public ScreenModeSupportType ScreenModeSupport { get; set; }

        public string DataBlobName { get; set; }
        public int MaxPlayers { get; set; }
        public bool AccessibilityLocked { get; set; }

        public DateTime CreatedAt { get; set; }
        public DateTime ModifiedAt { get; set; }
        public DateTime StateModifiedAt { get; set; }
        public DateTime DataModifiedAt { get; set; }
        public DateTime LastVisitedAt { get; set; }

        public int VisitorCount { get; set; }
        public int VisitCount { get; set; }

        public int CheerCount { get; set; }
        public int ReportCount { get; set; }

        public List<long> CoOwners { get; set; }
        public List<long> Hosts { get; set; }
    }
}
