﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json
{
    internal class SavedOutfit : ObjectDTO
    {
        public int Slot { get; set; }
        public string PreviewImageName { get; set; }
        public string OutfitSelections { get; set; }
        public string HairColor { get; set; }
        public string SkinColor { get; set; }
        public string FaceFeatures { get; set; }
    }
}
