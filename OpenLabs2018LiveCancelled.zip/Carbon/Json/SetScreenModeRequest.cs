﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json
{
    internal class SetScreenModeRequest : ObjectDTO
    {
        public bool InScreenMode { get; set; }
    }
}
