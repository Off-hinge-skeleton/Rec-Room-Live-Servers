﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json
{
    internal class Setting : ObjectDTO
    {
        public string Key { get; set; }
        public string Value { get; set; }
    }
}
