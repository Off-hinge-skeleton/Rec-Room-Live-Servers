﻿using Openlabs.Mgcxm.Assets;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Json.Storefronts
{
    public enum StorefrontType
    {
        None,
        LaserTag,
        RecCenter,
        Watch,
        Quest_LostSkulls = 100,
        RecRoyale = 200
    }

    public enum PurchasableItemType
    {
        GiftDrop,
        SeasonTier,
        SeasonEliteUpgrade
    }

    public class PurchasableItemPrice : ObjectDTO
    {
        public CurrencyType CurrencyType { get; set; }
        public int Price { get; set; }
    }

    public class PurchasableItemBase : ObjectDTO
    {
        public int PurchasableItemId { get; set; }
        public PurchasableItemType Type { get; set; }
        public bool IsFeatured { get; set; }
        public PurchasableItemPrice[] Prices { get; set; }
    }

    public enum BalanceAddType
    {

        Invalid,
        WonGame = 1000,
        LostGame,
        WonGameRateLimited,
        WonGamePartial

    }
    public class GrantBalanceRequest
    {
        public float Multiplier { get; set; }

        public BalanceAddType BalanceAddType { get; set; }
    }

    public class RewardBalanceModificationDTO : ObjectDTO
    {
        public int BaseAward { get; set; }
        public int BonusAward { get; set; }
        public int CurrentCount { get; set; }
        public int TotalCount { get; set; }
        public int RateLimit { get; set; }
        public int Total { get; set; }
    };
    public class BalanceResponseDTO : ObjectDTO
    {
        
        public CurrencyType CurrencyType { get; set; }
        public long Balance { get; set; }

    }
    
    public class StorefrontGiftDrop : ObjectDTO
    {
        public int GiftDropId { get; set; }
        public string FriendlyName { get; set; }
        public string Tooltip { get; set; }
        public string AvatarItemDesc { get; set; }
        public string ConsumableItemDesc { get; set; }
        public string EquipmentPrefabName { get; set; }
        public string EquipmentModificationGuid { get; set; }
        public GiftRarity Rarity { get; set; }
        public bool IsQuery { get; set; }
        public bool Unique { get; set; }
        public GiftContext Context { get; set; }
    }

    public class StoreItem : PurchasableItemBase
    {
        public StorefrontGiftDrop[] GiftDrops { get; set; }
    }

    public class StorefrontBase : ObjectDTO
    {
        public StorefrontType StorefrontType { get; set; }
        public DateTime NextUpdate { get; set; }
    }

    internal class Storefront : StorefrontBase
    {
        public StoreItem[] StoreItems { get; set; }
    }

    internal class PurchaseItem : ObjectDTO
    {
        public StorefrontType StorefrontType { get; set; }
        public int PurchasableItemId { get; set; }
        public CurrencyType CurrencyType { get; set; }


    }



    public enum PurchaseResponse
    {
        OK = 0
    }



    public class PurchaseBalanceUpdateResponse
    {
       public PurchaseResponse UpdateResponse { get; set; }
        public object Data { get; set; }

    };


    public class GiftItem
    {
        public long Id { get; set; }
        public string AvatarItemDesc { get; set; }
        public string ConsumableItemDesc { get; set; }
        public string EquipmentPrefabName { get; set; }
        public string EquipmentModificationGuid { get; set; }
        public CurrencyType CurrencyType { get; set; }
        public int Currency {  get; set; }
        public int Xp {  get; set; }
        public int Level { get; set; }
        public string Message {  get; set; }

        public GiftContext GiftContext { get; set; }

    }
    public class BuyItemResponse
    {
        public long Balance { get; set; }
        public CurrencyType CurrencyType { get; set; }
        public List<PurchaseBalanceUpdateResponse> BalanceUpdates { get; set; }

    }
}