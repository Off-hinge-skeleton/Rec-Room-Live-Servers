﻿using Carbon.Backend;
using Carbon.Backend.Attributes;
using Carbon.Backend.Statics;
using Carbon.Json.Notifications;
using Carbon.Servers;
using Carbon.Steam;
using Carbon.Utilities;
using Openlabs.Mgcxm.Internal;
using Openlabs.Mgcxm.Net;
using Openlabs.Mgcxm.Startup;

using OpenlabsSDKV1;
using OpenlabsSDKV1.Cloud;
using OpenlabsSDKV1.Core.Analytics;
using OpenlabsSDKV1.Domain;

namespace Carbon
{
    public class AppDomain_FirstChanceExceptionData : IAnalyticsSerializable
    {
        public Dictionary<string, object> Serialize()
        {
            var type = Exception.GetType();
            return new Dictionary<string, object>
            {
                { "Guid", type.GUID },
                { "FriendlyName", type.GetSafeName() },
                { "Message", Exception.Message },
                { "StackTrace", Exception.StackTrace },
            };
        }

        public Exception Exception { get; set; }
    }

    public static class Program
    {
        public const string GAME_VERSION = "20180810_EA";
        public const string APP_VERSION = "1.0.0-2018devtest";
        public const bool GATEWAY_ACTIVE = !SELFHOST && false;
        public const bool SELFHOST = true;

        static List<IStartableServer> startableServers = new List<IStartableServer>();

        public static async Task<int> Main(string[] args)
        {
            Console.Title = "Carbon (Openlabs Server)";
            if (!SELFHOST && !Application.IsAdministrator())
            {
                Application.RestartAsAdministrator();
                return 99;
            }

            Directory.CreateDirectory(Environment.CurrentDirectory + "//assets");

            await Bootstrap.LoadMgcxm(new BootstrapOptions
            {
#if (DEBUG)
                minimumLogLevel = LogLevel.TRACE,
#elif (!DEBUG)
                minimumLogLevel = LogLevel.INFO, // INFO
#endif
                useExperimentalOptions = false,
                scalingOptions = new ScalingOptions
                {
                    maxNodes = 10,
                    maxThreads = 10,
                    runProcessesInBackground = true,
                    useRandomPrefixes = false
                }
            });

            if (GATEWAY_ACTIVE)
            {
                if (!await CentralGatewayApi.ConnectAsync(GAME_VERSION, APP_VERSION))
                {
                    Logger.Error("Failed to connect to Central Gateway: " + CentralGatewayApi.ErrorMessage);
                    Logger.Info("Press any key to exit...");

                    Console.ReadKey();
                    return -1;
                }
                Logger.Info("Connected to Central Gateway (server 1, formerly known as " + CentralGatewayApi.Version + ")");
            }

            RecRoomOriginalRooms.Initialize();
            BackendMethodAttribute.Initialize();
            BackendService.Initialize();
            

            startableServers.Add(new NameServer());
            startableServers.Add(new AuthServer());
            startableServers.Add(new ApiServer());
            startableServers.Add(new NotificationsServer());
            startableServers.Add(new ImagesServer());
            startableServers.Add(new CdnServer());

            foreach (var server in startableServers)
            {
                server.Start();
                Logger.Info(string.Format("Started server: 0x{0}, known as {1}", (server.GetHashCode() >> 24 * 8)
                    .ToString("x2").PadLeft(8, '0'), server.GetType().Name));
            }

            await Task.Delay(-1);
            return 0;
        }
    }
}