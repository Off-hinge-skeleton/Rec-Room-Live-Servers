﻿using Carbon.Backend;
using Carbon.Backend.Interfaces;
using Carbon.Backend.Statics;
using Carbon.Json.Notifications;
using Carbon.Utilities;
using Openlabs.Mgcxm.Common.JsonMapping;
using Openlabs.Mgcxm.Internal;
using Openlabs.Mgcxm.Net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Servers
{
    internal class AdminServer : MgcxmHttpListener
    {
        public AdminServer() : base(
            Constants.LOCAL_ADMIN_SERVER_HOSTNAME,
            !Program.SELFHOST ? Constants.HOSTNAME : Constants.SELFHOST_ADMIN_SERVER_HOSTNAME)
        {
            var host = Constants.LOCAL_ADMIN_SERVER_HOSTNAME;
            var postfix = !Program.SELFHOST ? Constants.HOSTNAME : Constants.SELFHOST_ADMIN_SERVER_HOSTNAME;
            Logger.Warning(host + ", " + postfix);

            Singleton<AdminServer>.Allocate(this);
        }
        ~AdminServer() { Singleton<AdminServer>.Free(); }

        
    }
}
