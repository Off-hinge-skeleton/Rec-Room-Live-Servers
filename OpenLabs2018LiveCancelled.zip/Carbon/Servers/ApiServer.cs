using Openlabs.Mgcxm.Internal;
using Openlabs.Mgcxm.Common;
using Openlabs.Mgcxm.Common.JsonMapping;
using Openlabs.Mgcxm.Net;
using Carbon.Json.Challenges;
using OpenlabsSDKV1.Core.Async;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using Newtonsoft.Json;
using Carbon.Backend;
using Carbon.Json;
using Carbon.Backend.Databasing;
using Carbon.Backend.AccessTokens;
using Carbon.Utilities;
using Carbon.Json.Storefronts;
using Carbon.Steam;
using Carbon.Json.Matchmaking;

using Carbon.Backend;
using System.Net.Http.Headers;
using Carbon.Backend.Statics;
using Carbon.Json.Notifications;
using System.Net.Sockets;
using System.Net;
using System.Xml.Linq;
using Carbon.Backend.Interfaces;
using Carbon.Json.Rooms;
using Carbon.Configs;
using System.Drawing.Printing;
using System.Security.Cryptography.X509Certificates;
using System.IO.Enumeration;
using System.Xml.Serialization;
using Carbon.Json.Chats;
using Carbon.Json.Storefronts;
using OpenlabsSDKV1.Cloud.Json;
using Carbon.Json.Checklist;
using Steamworks;
using System.Diagnostics.Contracts;
using System.Text.RegularExpressions;
using Carbon.Json.Admin;
using System.ComponentModel.Design;
using JWT;
using System.Data.Common;

namespace Carbon.Servers
{
    internal class ApiServer : MgcxmHttpListener
    {
        public ApiServer() : base(
            addressToHostOn: Constants.LOCAL_API_SERVER_HOSTNAME,
            host: !Program.SELFHOST ? Constants.HOSTNAME : Constants.SELFHOST_API_SERVER_HOSTNAME,
            certificate: Constants.SSL ? SslConfig.Instance.GetCertificate() : null)
        {
            Singleton<ApiServer>.Allocate(this);
        }
        ~ApiServer() { Singleton<ApiServer>.Free(); }

        [HttpEndpoint(HttpMethods.GET, "/api/versioncheck/v3")]
        public void OnVersionCheckRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            response.Status(HttpStatusCodes.OK)
                    .Json(new VersionCheckResponse
                    {
                        ValidVersion = request.Query["v"] == Program.GAME_VERSION
                    })
                    .Finish();
        }

        [HttpEndpoint(HttpMethods.GET, "/api/config/v2")]
        public void OnConfigRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            response.Status(HttpStatusCodes.OK)
                    .Json(new RecRoomConfig
                    {
                        MessageOfTheDay = "Welcome to Openlabs!",
                        CdnBaseUri = Constants.CreateNameServerUrl(Constants.SSL, Constants.SELFHOST_CDN_SERVER_HOSTNAME, Constants.CDN_SERVER_PORT),
                        MatchmakingParams = new MatchmakingParams
                        {
                            PreferEmptyRoomsFrequency = 0.1f,
                            PreferFullRoomsFrequency = 0.9f
                        },
                        ServerMaintenance = new ServerMaintenanceDTO { StartsInMinutes = 0 },
                        LevelProgressionMaps = new List<LevelProgressionEntry>
                        {
                            new LevelProgressionEntry{Level = 0, RequiredXp = 0},
                            new LevelProgressionEntry{Level = 1, RequiredXp = 1000},
                            new LevelProgressionEntry{Level = 2, RequiredXp = 2000},
                            new LevelProgressionEntry{Level = 3, RequiredXp = 3000},
                            new LevelProgressionEntry{Level = 4, RequiredXp = 4000},
                            new LevelProgressionEntry{Level = 5, RequiredXp = 5000},
                            new LevelProgressionEntry{Level = 6, RequiredXp = 6000},
                            new LevelProgressionEntry{Level = 7, RequiredXp = 7000},
                            new LevelProgressionEntry{Level = 8, RequiredXp = 8000},
                            new LevelProgressionEntry{Level = 9, RequiredXp = 9000},
                            new LevelProgressionEntry{Level = 10, RequiredXp = 10000},
                            new LevelProgressionEntry{Level = 11, RequiredXp = 11000},
                            new LevelProgressionEntry{Level = 12, RequiredXp = 12000},
                            new LevelProgressionEntry{Level = 13, RequiredXp = 13000},
                            new LevelProgressionEntry{Level = 14, RequiredXp = 14000},
                            new LevelProgressionEntry{Level = 15, RequiredXp = 15000},
                            new LevelProgressionEntry{Level = 16, RequiredXp = 16000},
                            new LevelProgressionEntry{Level = 17, RequiredXp = 17000},
                            new LevelProgressionEntry{Level = 18, RequiredXp = 18000},
                            new LevelProgressionEntry{Level = 19, RequiredXp = 19000},
                            new LevelProgressionEntry{Level = 20, RequiredXp = 20000},
                            new LevelProgressionEntry{Level = 21, RequiredXp = 21000},
                            new LevelProgressionEntry{Level = 22, RequiredXp = 22000},
                            new LevelProgressionEntry{Level = 23, RequiredXp = 23000},
                            new LevelProgressionEntry{Level = 24, RequiredXp = 24000},
                            new LevelProgressionEntry{Level = 25, RequiredXp = 25000},
                            new LevelProgressionEntry{Level = 26, RequiredXp = 26000},
                            new LevelProgressionEntry{Level = 27, RequiredXp = 27000},
                            new LevelProgressionEntry{Level = 28, RequiredXp = 28000},
                            new LevelProgressionEntry{Level = 29, RequiredXp = 29000},
                            new LevelProgressionEntry{Level = 30, RequiredXp = 30000},



                        },
                        DailyObjectives = new List<List<Objective>>
                        {
                            new List<Objective>
                            {
                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.GoToRecCenter,
                                   RequiredScore = 1,
                                },

                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.CheerAPlayer,
                                   RequiredScore = 1,
                                },

                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.ScoreBasketInRecCenter,
                                   RequiredScore = 1,
                                },

                            },

                            new List<Objective>
                            {
                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.GoToRecCenter,
                                   RequiredScore = 1,
                                },

                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.CheerAPlayer,
                                   RequiredScore = 1,
                                },

                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.ScoreBasketInRecCenter,
                                   RequiredScore = 1,
                                },

                            },

                            new List<Objective>
                            {
                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.GoToRecCenter,
                                   RequiredScore = 1,
                                },

                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.CheerAPlayer,
                                   RequiredScore = 1,
                                },

                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.ScoreBasketInRecCenter,
                                   RequiredScore = 1,
                                },

                            },

                            new List<Objective>
                            {
                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.GoToRecCenter,
                                   RequiredScore = 1,
                                },

                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.CheerAPlayer,
                                   RequiredScore = 1,
                                },

                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.ScoreBasketInRecCenter,
                                   RequiredScore = 1,
                                },

                            },

                            new List<Objective>
                            {
                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.GoToRecCenter,
                                   RequiredScore = 1,
                                },

                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.CheerAPlayer,
                                   RequiredScore = 1,
                                },

                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.ScoreBasketInRecCenter,
                                   RequiredScore = 1,
                                },

                            },

                            new List<Objective>
                            {
                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.GoToRecCenter,
                                   RequiredScore = 1,
                                },

                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.CheerAPlayer,
                                   RequiredScore = 1,
                                },

                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.ScoreBasketInRecCenter,
                                   RequiredScore = 1,
                                },

                            },

                            new List<Objective>
                            {
                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.GoToRecCenter,
                                   RequiredScore = 1,
                                },

                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.CheerAPlayer,
                                   RequiredScore = 1,
                                },

                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.ScoreBasketInRecCenter,
                                   RequiredScore = 1,
                                },

                            },

                            new List<Objective>
                            {
                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.GoToRecCenter,
                                   RequiredScore = 1,
                                },

                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.CheerAPlayer,
                                   RequiredScore = 1,
                                },

                                new Objective
                                {
                                    ObjectiveType = ObjectiveType.ScoreBasketInRecCenter,
                                   RequiredScore = 1,
                                },

                            },


                        },
                        ConfigTable = new List<Setting>
                        {
                            new Setting
                            {
                                Key = "forceRegistration",
                                Value = "0"
                            },
                            new Setting
                            {
                                Key = "GASamplingRatio",
                                Value = "0"
                            },
                            new Setting
                            {
                                Key = "impossiblesAllowed",
                                Value = "false"
                            },
                            new Setting
                            {
                                Key = "Gift.DropChance",
                                Value = "10"
                            },
                            new Setting
                            {
                                Key = "Gift.Falloff",
                                Value = "0.35"
                            },
                            new Setting
                            {
                                Key = "Gift.MaxDaily",
                                Value = "10"
                            }
                        },
                        PhotonConfig = new PhotonConfig
                        {
                            CrcCheckEnabled = true,
                            EnableServerTracingAfterDisconnect = false
                        }
                    })
                    .Finish();
        }

        [HttpEndpoint(HttpMethods.GET, "/api/players/v2/search")]
        public void Search(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            var loginBackend = BackendService.GetBackend<Login>();
            var players = loginBackend.GetAllPlayers();

            var profiles = new List<Profile>();
            
            if (!players.Any(p => Convert.ToString(p.DisplayName.ToLower()).StartsWith(request.Query["name"].ToLower())))
            {
                response.Status(HttpStatusCodes.OK)
                    .Json(profiles)
                    .Finish();
                return;
            }

            
            foreach (var player in players)
            {
                if (Convert.ToString(player.DisplayName.ToLower()).StartsWith(request.Query["name"].ToLower()))
                {
                    profiles.Add(player);
                }
                
            }



            response.Status(HttpStatusCodes.OK)
                    .Json(profiles)
                    .Finish();
        }

        [HttpEndpoint(HttpMethods.GET, "/api/config/v1/amplitude")]
        public void OnAmplitudeConfigRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            response.Status(HttpStatusCodes.OK)
                    .Json(new AmplitudeConfig
                    {
                        AmplitudeKey = "6023da7f25eef9c7ee5a20717eebff5d"
                    })
                    .Finish();
        }

        [HttpEndpoint(HttpMethods.POST, "/api/platformlogin/v1/getcachedlogins")]
        public void OnCachedLoginsRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            var loginBackend = BackendService.GetBackend<Login>();
            var platform = (PlatformType)int.Parse(request.Form["Platform"]);
            string platformId = request.Form["PlatformId"];

            Carbon.Steam.SteamUser.Get(platformId)
                .Then(user =>
                {
                    var profiles = (List<Profile>)loginBackend.GetCachedLogins(platform, platformId);

                    if (!profiles.Any())
                    {
                        var profileId = Openlabs.Mgcxm.Common.Random.Range(1000000, 1000000000);
                        var hash = Hashing.MD5(platformId + profileId);
                        var username = string.Format("user{0}", hash.Substring(0, 6));
                        profiles.Insert(0, new Profile
                        {
                            Id = profileId,
                            Username = username,
                            DisplayName = user.DisplayName,
                            Bio = "",
                            XP = 0,
                            Level = 1,
                            RegistrationStatus = RegistrationType.Registered,
                            Developer = false,
                            CanReceiveInvites = true,
                            ProfileImageName = "DefaultProfileImage.png",
                            JuniorProfile = false,
                            ForceJuniorImages = false,
                            PendingJunior = false,
                            HasBirthday = true,
                            AvoidJuniors = false,
                            PlayerReputation = new Reputation
                            {
                                Noteriety = 0,
                                CheerGeneral = 0,
                                CheerHelpful = 0,
                                CheerGreatHost = 0,
                                CheerSportsman = 0,
                                CheerCreative = 0,
                                CheerCredit = 5,
                                SubscriberCount = 0,
                                SubscribedCount = 0,
                                SelectedCheer = null
                            },
                            PlatformId = new PlatformId
                            {
                                Platform = platform,
                                Id = platformId
                            }
                        });
                    }

                    Database.ProfileDatabase.WriteGeneric(platformId, profiles);
                    response.Status(HttpStatusCodes.OK)
                            .Json(profiles).Finish();
                });
        }

        [HttpEndpoint(HttpMethods.POST, "/api/platformlogin/v1/logincached")]
        public void OnLoginToCachedProfileRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            var loginBackend = BackendService.GetBackend<Login>();
            var postData = JsonConvert.DeserializeObject<LoginToCachedProfileRequest>(request.Body);

            loginBackend.LoginToCachedAccount(postData!)
                .WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.POST, "/api/platformlogin/v1/logout")]
        public void OnPlatformLogout(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {

            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var presenceBackend = BackendService.GetBackend<Presence>();
            presenceBackend.NonBackend_RemovePlayerPresence(accessToken);

            response.Status(HttpStatusCodes.OK).Finish();
        }

        [HttpEndpoint(HttpMethods.GET, "/api/PlayerReporting/v1/moderationBlockDetails")]
        public void OnBanishmentDetailsRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var moderationBackend = BackendService.GetBackend<PlayerReporting>();



            var details = moderationBackend.GetModerationBlockDetail(accessToken);
            Logger.Info(details.ToJson());
            response.Status(HttpStatusCodes.OK).Json(details).Finish();
        }

        [HttpEndpoint(HttpMethods.POST, "/api/presence/v2/setscreenmode")]
        public void OnSetScreenModeRequestedRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            SetScreenModeRequest postData = JsonConvert.DeserializeObject<SetScreenModeRequest>(request.Body)!;

            var presenceBackend = BackendService.GetBackend<Presence>();
            presenceBackend.SetScreenMode(accessToken, postData.InScreenMode).WriteOnSuccess(request, response);
        }

        [HttpEndpoint(HttpMethods.POST, "/api/relationships/v1/bulkignoreplatformusers")]
        public void OnBulkIgnorePlatformUsersRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            SetScreenModeRequest postData = JsonConvert.DeserializeObject<SetScreenModeRequest>(request.Body)!;

            var presenceBackend = BackendService.GetBackend<Presence>();
            presenceBackend.SetScreenMode(accessToken, postData.InScreenMode).WriteOnSuccess(request, response);
        }

        [HttpEndpoint(HttpMethods.GET, "/api/images/v2/named")]
        public void OnNamedImagesRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var imagesBackend = BackendService.GetBackend<Images>();
            imagesBackend.GetNamedImages(accessToken).WriteOnItem(request, response);
        }




        [HttpEndpoint(HttpMethods.GET, "/api/messages/v2/get")]
        public void OnNotificationMessagesRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var messagesBackend = BackendService.GetBackend<Messages>();
            messagesBackend.GetNotificationMessages(accessToken).WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.POST, "/api/messages/v2/send")]
        public void OnNotificationSendRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            long toPlayerId = long.Parse(request.Form["ToPlayerId"]);
            NotificationMessageType type = (NotificationMessageType)int.Parse(request.Form["Type"]);
            string data = request.Form.ContainsKey("Data") && !string.IsNullOrEmpty(request.Form["Data"]) ? WebUtility.UrlDecode(request.Form["Data"]) : "";
            long? roomId = request.Form.ContainsKey("RoomId") ? long.Parse(request.Form["RoomId"]) : null;

            var messagesBackend = BackendService.GetBackend<Messages>();
            var loginBackend = BackendService.GetBackend<Login>();

            loginBackend.GetProfile(accessToken, toPlayerId).Then(toPlayer =>
            {
                var toPlayerIdAccessToken = AccessToken.CreateFake(toPlayer.Id, toPlayer.PlatformId.Id);
                messagesBackend.NonBackend_AddMessage(toPlayerIdAccessToken, NotificationMessage.Create(accessToken.PlayerId, type, data, roomId, null));

                response.Status(HttpStatusCodes.OK).Finish();
            });
        }

        [HttpEndpoint(HttpMethods.POST, "/api/messages/v2/delete")]
        public void OnNotificationMessagesDeleteRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var messagesBackend = BackendService.GetBackend<Messages>();
            messagesBackend.NonBackend_RemoveMessage(accessToken, long.Parse(request.Form["Id"]));

            response.Status(HttpStatusCodes.OK).Finish();
        }

        [HttpEndpoint(HttpMethods.POST, "/api/chat/v1/readMessage")]
        public void OnReadMessage(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var data = JsonConvert.DeserializeObject<ChatReadData>(request.Body);
            Logger.Info(data.ToJson());

            var chat = Database.ChatsDatabase.ReadGeneric<ChatThread>(data.ChatId.ToString());

            var newmsg = chat.Messages.FirstOrDefault(p => p.ChatMessageId == chat.LastReadMessageId, new ChatMessage());
            var result = new ChatSendResponse()
            {
                ChatResult = ChatResults.Success,
                ChatMessage = newmsg
            };

            response.Status(HttpStatusCodes.OK).Json(result).Finish();
        }
           

        [HttpEndpoint(HttpMethods.POST, "/api/chat/v1/sendMessage")]
        public void OnSendMessage(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {

                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            Logger.Info(request.Body);
            
            var data = JsonConvert.DeserializeObject<ChatSendData>(request.Body);
            var content = JsonConvert.DeserializeObject<MessageContent>(data.MessageContents);
            var chat = Database.ChatsDatabase.ReadGeneric<ChatThread>(data.ChatId.ToString());

            var newmsg = new ChatMessage
            {
                ChatMessageId = chat.ChatThreadId + chat.Messages.Count() + 1,
                ChatThreadId = data.ChatId,
                SenderPlayerId = (int)accessToken.PlayerId,
                Contents = data.MessageContents,
                TimeSent = DateTime.Now,



            };

            chat.Messages.Add(newmsg);
            chat.LastReadMessageId = newmsg.ChatMessageId;


            Database.ChatsDatabase.WriteGeneric<ChatThread>(data.ChatId.ToString(), chat);


            foreach (var PlayerId in chat.PlayerIds)
            {
                var connectionNode = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(PlayerId);

                if (connectionNode != null)
                {
                    connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                    {
                        Id = PushNotificationId.ChatMessageReceived,
                        Msg = newmsg

                    });
                }
                


                
            }
               
            var result = new ChatSendResponse()
                {
                    ChatResult = ChatResults.Success,
                    ChatMessage = newmsg
                };


                
            response.Status(HttpStatusCodes.OK).Json(result).Finish();

        }



        [HttpEndpoint(HttpMethods.POST, "/api/chat/v1/create")]
        public void OnChatCreate(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {

            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }


            var data = JsonConvert.DeserializeObject<ChatCreateInfo>(request.Body);

            long new_chatThreadID = Openlabs.Mgcxm.Common.Random.Range(100000, 999999);
            long new_chatMessageID = 1 + new_chatThreadID;

            var newmsg = new ChatMessage()
            {
                ChatMessageId = new_chatMessageID,
                ChatThreadId = new_chatThreadID,
                Contents = data.MessageContents,
                SenderPlayerId = int.Parse(accessToken.PlayerId.ToString()),
                TimeSent = DateTime.Now
            };

            var new_chat = new ChatCreateResponse()
            {

                ChatResult = ChatResults.Success,
                ChatThread = new ChatThread
                {
                    ChatThreadId = new_chatThreadID,
                    Messages = new List<ChatMessage>
                    {
                        newmsg
                    },

                    LastReadMessageId = new_chatMessageID,
                    PlayerIds = data.PlayerIds,

                }

            };

            

            foreach (var PlayerId in data.PlayerIds)
                {
                    var PlayerID = long.Parse(PlayerId.ToString());
                    var connectionNode = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(PlayerID);
                    Logger.Info(request.Body);

                    if (connectionNode != null)
                    {
                        connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                        {
                            Id = PushNotificationId.ChatMessageReceived,
                            Msg = newmsg

                        });

                    }

            };

            
            Database.ChatsDatabase.WriteGeneric(new_chatThreadID.ToString(), new_chat.ChatThread);
            Logger.Info(new_chat.ToJson());
            response.Status(HttpStatusCodes.OK).Json(new_chat).Finish();
        }

        [HttpEndpoint(HttpMethods.GET, "/api/chat/v2/myChats")]
        public void OnMyChatsRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var chatsBackend = BackendService.GetBackend<Chats>();
            int takeAmount = request.Query.ContainsKey("count") ? int.Parse(request.Query["count"]) : 50;
            Logger.Info(takeAmount.ToString());

            chatsBackend.GetMyChats(accessToken, takeAmount).WriteOnItem(request, response);
        }



        [HttpEndpoint(HttpMethods.GET, "/api/relationships/v1/favorite")]
        public void On_Favorite(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var remote_Player = JsonConvert.DeserializeObject<favoritedata>(request.Query.ToJson());
            Logger.Info(remote_Player.ToJson());

            var relation= new Relationship();

            var relationships = Database.RelationshipsDatabase.ReadGeneric<List<Relationship>>(accessToken.PlatformId);

            Logger.Info(relationships.ToJson());

            var relationship = relationships.FirstOrDefault(relation => relation.PlayerID == remote_Player.Id, new Relationship());

            relationships.Remove(relation);
            relationship.Favorited = ReciprocalStatus.Local;

            relation = relationship;

            relationships.Add(relationship);

            Database.RelationshipsDatabase.WriteGeneric(accessToken.PlatformId, relationships);



            response.Status(HttpStatusCodes.OK).Json(relation).Finish();
            
        }

        [HttpEndpoint(HttpMethods.GET, "/api/relationships/v1/unfavorite")]
        public void On_Unfavorite(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var remote_Player = JsonConvert.DeserializeObject<favoritedata>(request.Query.ToJson());
            Logger.Info(remote_Player.ToJson());

            var relation = new Relationship();

            var relationships = Database.RelationshipsDatabase.ReadGeneric<List<Relationship>>(accessToken.PlatformId);

            Logger.Info(relationships.ToJson());

            foreach (var relationship in relationships)
            {
                if (relationship.PlayerID == remote_Player.Id)
                {
                    relation = relationship;
                    relationship.Favorited = ReciprocalStatus.None;
                    Database.RelationshipsDatabase.WriteGeneric(accessToken.PlatformId, relationships);
                    break;

                }
            }


            response.Status(HttpStatusCodes.OK).Json(relation).Finish();

        }

        [HttpEndpoint(HttpMethods.GET, "/api/avatar/v2")]
        public void OnMyAvatarRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var avatarsBackend = BackendService.GetBackend<Avatars>();
            avatarsBackend.GetCurrentAvatar(accessToken).WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.POST, "/api/avatar/v2/set")]
        public void OnSetMyAvatarRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var avatarsBackend = BackendService.GetBackend<Avatars>();
            avatarsBackend.SetCurrentAvatar(accessToken, JsonConvert.DeserializeObject<Avatar>(request.Body)!).WriteOnSuccess(request, response);
        }

        [HttpEndpoint(HttpMethods.GET, "/api/avatar/v3/items")]
        public void OnMyAvatarItemsRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var avatarsBackend = BackendService.GetBackend<Avatars>();
            avatarsBackend.GetItemWardrobe(accessToken).WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.GET, "/api/avatar/v3/saved")]
        public void OnMySavedAvatarOutfitsRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var avatarsBackend = BackendService.GetBackend<Avatars>();
            avatarsBackend.GetSavedOutfits(accessToken).WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.GET, "/api/avatar/v2/gifts")]
        public void OnMyGiftsRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var giftsBackend = BackendService.GetBackend<Gifts>();
            giftsBackend.GetGifts(accessToken).WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.GET, "/api/relationships/v2/get")]
        public void OnMyFriendsRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var relationshipsBackend = BackendService.GetBackend<Relationships>();
            relationshipsBackend.GetFriends(accessToken).WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.GET, "/api/playersubscriptions/v1/my")]
        public void OnMySubscriptionsRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var playerSubscriptionsBackend = BackendService.GetBackend<PlayerSubscriptions>();
            playerSubscriptionsBackend.GetSubscriptions(accessToken).WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.GET, "/api/settings/v2")]
        public void OnPlayerSettingsRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var settingsBackend = BackendService.GetBackend<Settings>();
            settingsBackend.GetSettings(accessToken).WriteOnItem(request, response);
        }


        [HttpEndpoint(HttpMethods.GET, "/api/storefronts/v3/balance/{sftype}")]
        [HttpDynamicUse("{sftype}")]

        public void OnBalance(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();

                return;
            }
            CurrencyType type = (CurrencyType)int.Parse(request.Uri.Split("/")[5]);
            
            var result = Econ.GetStorefrontBalance(type, accessToken);

            response.Status(HttpStatusCodes.OK).Json(result).Finish();


        }

        [HttpEndpoint(HttpMethods.POST, "/api/settings/v2/set")]
        public void OnSetPlayerSettingsRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var settingsBackend = BackendService.GetBackend<Settings>();
            settingsBackend.SetOrAddSetting(accessToken, JsonConvert.DeserializeObject<Setting>(request.Body)!)
                .WriteOnSuccess(request, response);
        }

        [HttpEndpoint(HttpMethods.GET, "/api/equipment/v1/getUnlocked")]
        public void OnMyEquipmentRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var equipmentsBackend = BackendService.GetBackend<Equipments>();
            equipmentsBackend.GetEquipment(accessToken).WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.POST, "/api/equipment/v1/update")]
        public void OnUpdateMyEquipmentRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var equipmentsBackend = BackendService.GetBackend<Equipments>();
            equipmentsBackend.UpdateEquipment(accessToken, JsonConvert.DeserializeObject<List<Equipment>>(request.Body)!).WriteOnSuccess(request, response);
        }

        [HttpEndpoint(HttpMethods.GET, "/api/consumables/v1/getUnlocked")]
        public void OnMyConsumablesRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var ConsumableBackend = BackendService.GetBackend<Consumables>();

            var consumables = ConsumableBackend.GetConsumables(accessToken);
            response.Status(HttpStatusCodes.OK).Json(consumables).Finish();
        }

        [HttpEndpoint(HttpMethods.POST, "/api/avatar/v2/gifts/consume")]
        public void ConsumeGift(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var Gifts = Database.GiftsDatabase.ReadGeneric<List<GiftPackage>>(accessToken.PlatformId);

            var gift = Gifts.ElementAt(0);

            if (gift.AvatarItemDesc != "")
            {

                var AvatarItems = Database.WardrobeDatabase.ReadGeneric<List<UnlockedAvatarItem>>(accessToken.PlatformId);

                var newItem = new UnlockedAvatarItem()
                {
                    UnlockedLevel = gift.Level,
                    AvatarItemDesc = gift.AvatarItemDesc
                };

                AvatarItems.Add(newItem);

                Database.WardrobeDatabase.WriteGeneric(accessToken.PlatformId, AvatarItems);

                var result = new GiftResponseForm
                {
                    Id = gift.Id,
                    LevelUnlocked = gift.Level,
                };

                Gifts.Remove(gift);

                Database.GiftsDatabase.WriteGeneric(accessToken.PlatformId, Gifts);

                response.Status(HttpStatusCodes.OK).Json(result).Finish();
                return;


            }

            else if (gift.Currency != 0)
            {
                var econdata = Database.EconDatabase.ReadGeneric<List<BalanceResponseDTO>>(accessToken.PlatformId);
                var currency = econdata.FirstOrDefault(item => item.CurrencyType == gift.CurrencyType, new BalanceResponseDTO());
                var connectionNode = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(accessToken.PlayerId);
                var balance = new BalanceResponseDTO();

                if(econdata.Any(balance => balance.CurrencyType == gift.CurrencyType) == false)
                {
                    balance = new BalanceResponseDTO()
                    {
                        Balance = long.Parse(gift.Currency.ToString()),
                        CurrencyType = gift.CurrencyType,
                    };

                    econdata.Add(balance);
                }
                else
                {
                    balance = econdata.FirstOrDefault(balance => balance.CurrencyType == gift.CurrencyType);
                    var new_balanceData = balance;

                    new_balanceData.Balance += gift.Currency;

                    econdata[econdata.IndexOf(balance)] = new_balanceData;

                    
                }

                if (connectionNode != null)
                {
                    connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                    {
                        Id = PushNotificationId.StorefrontBalanceAdd,
                        Msg = balance

                    });

                }

                Database.EconDatabase.WriteGeneric(accessToken.PlatformId, econdata);
                response.Status(HttpStatusCodes.OK).Json(balance).Finish();
                

            }

            else if (gift.EquipmentModificationGuid != "")
            {
                var Skins = Database.EquipmentDatabase.ReadGeneric<List<Equipment>>(accessToken.PlatformId);

                var newItem = new Equipment()
                {
                    UnlockedLevel = gift.Level,
                    ModificationGuid = gift.EquipmentModificationGuid,
                    PrefabName = gift.EquipmentPrefabName
                };

                Skins.Add(newItem);

                Database.EquipmentDatabase.WriteGeneric(accessToken.PlatformId, Skins);

                var result = new GiftResponseForm
                {
                    Id = gift.Id,
                    LevelUnlocked = gift.Level,
                };

                Gifts.Remove(gift);

                Database.GiftsDatabase.WriteGeneric(accessToken.PlatformId, Gifts);

                response.Status(HttpStatusCodes.OK).Json(result).Finish();
                return;
            }
           
            else if (gift.ConsumableItemDesc != "")
            {
                var consumableBackend = BackendService.GetBackend<Consumables>();

                var consumableItem = new Consumable()
                {
                    ConsumableItemDesc = gift.ConsumableItemDesc,
                    Count = 1,
                    CreatedAt = DateTime.UtcNow,
                    Id = gift.Id,
                    IsActive = false,
                    UnlockedLevel = 0
                };

                consumableBackend.addconsumable(accessToken, consumableItem);

                var connectionNode = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(accessToken.PlayerId);
                Logger.Info(request.Body);

                if (connectionNode != null)
                {
                    connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                    {
                        Id = PushNotificationId.ConsumableMappingAdded,
                        Msg = consumableItem

                    });

                }
            }

            Gifts.Remove(gift);

            Database.GiftsDatabase.WriteGeneric(accessToken.PlatformId, Gifts);


            response.Status(HttpStatusCodes.OK).Finish();
            
        }

        [HttpEndpoint(HttpMethods.POST, "/api/consumables/v1/consume")]
        public void OnConsumeItem(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            var data = JsonConvert.DeserializeObject<ConsumeResponse>(request.Body);

            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.OK).Finish();
                return;
            }

            var inventory = Database.ConsumableDatabase.ReadGeneric<List<Consumable>>(accessToken.PlatformId);
            var consumable = inventory.First(Item => Item.Id == data.Id);

            var ItemIndex = inventory.IndexOf(consumable);

            inventory[ItemIndex].Count -= data.DeltaCount;
            Consumable NewItem = inventory[ItemIndex];
            
            if (inventory[ItemIndex].Count <= 0)
            {
                inventory.Remove(inventory[ItemIndex]);
                Logger.Info(inventory.ToJson());


                var connectionNode = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(accessToken.PlayerId);
                
                NewItem = new Consumable()
                {
                    ConsumableItemDesc = consumable.ConsumableItemDesc,
                    Id = consumable.Id,
                    Count = 1,
                    CreatedAt = DateTime.UtcNow,
                    IsActive = false,
                    UnlockedLevel = 1,
                };

                if (connectionNode != null)
                {
                    connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                    {
                        Id = PushNotificationId.ConsumableMappingRemoved,
                        Msg = NewItem

                    });

                }
            }
            Database.ConsumableDatabase.WriteGeneric(accessToken.PlatformId, inventory);
            response.Status(HttpStatusCodes.OK).Json(NewItem).Finish();
        }

        [HttpEndpoint(HttpMethods.GET, "/api/storefronts/v3/giftdropstore/{sfType}")]
        [HttpDynamicUse("{sfType}")]
        public void OnStorefrontRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }


            StorefrontType storefrontType = (StorefrontType)int.Parse(request.Uri.Split("/")[5]);

            var storefrontsBackend = BackendService.GetBackend<Storefronts>();
            storefrontsBackend.GetStorefront(accessToken, storefrontType).WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.POST, "/api/avatar/v2/gifts/generate")]
        public void GenGift(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }
            var platid = accessToken.PlatformId;

            var currency = new List<int> { 10, 10, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 100, 100, 100, 100, 500, 500 };
            var gift = new GiftPackage()
            {
                GiftContext = GiftContext.Game_Drop,
                GiftRarity = GiftRarity.Common,
                AvatarItemDesc = "",
                ConsumableItemDesc = "",
                CurrencyType = CurrencyType.RecCenterTokens,
                Currency = currency.ElementAt(Openlabs.Mgcxm.Common.Random.Range(0, 29)),
                Xp = 0,
                Message = "Game Played!",
                EquipmentModificationGuid = "",
                EquipmentPrefabName = "",
                Id = Openlabs.Mgcxm.Common.Random.Range(100000, 999999),
                Level = 1

            };
            var Gifts = Database.GiftsDatabase.ReadGeneric<List<GiftPackage>>(platid);

            Logger.Info(Gifts.ToJson());
            Gifts.Add(gift);
            Logger.Info(Gifts.ToJson());

            Database.GiftsDatabase.WriteGeneric<List<GiftPackage>>(platid, Gifts);

            var connectionNode = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(accessToken.PlayerId);
            Logger.Info(request.Body);

            if (connectionNode != null)
            {
                connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                {
                    Id = PushNotificationId.GiftPackageReceived,
                    Msg = gift
                });
            }

            response.Status(HttpStatusCodes.OK).Json(new RecNetResult { Success = true, Message = gift.ToString()}).Finish();
        }

        //daily

        [HttpEndpoint(HttpMethods.GET, "/api/objectives/v1/myprogress")]
        public void OnMyObjectiveProgressRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            ObjectiveProgress progress = new ObjectiveProgress()
            {
                Objectives = new List<ObjectiveProgressIndex>
                {
                    new ObjectiveProgressIndex
                    {
                        Index = 0,
                        Group = 1,
                        Progress = 0,
                        VisualProgress = 0,
                        IsCompleted = false,
                        IsRewarded = false
                    },
                    new ObjectiveProgressIndex
                    {
                        Index = 1,
                        Group = 2,
                        Progress = 0,
                        VisualProgress = 0,
                        IsCompleted = false,
                        IsRewarded = false

                    },
                    new ObjectiveProgressIndex
                    {
                        Index = 2,
                        Group = 3,
                        Progress = 0,
                        VisualProgress = 0,
                        IsCompleted = false,
                        IsRewarded = false

                    }
                },

                ObjectiveGroups = new List<ObjectiveProgressGroup>
                {
                    new ObjectiveProgressGroup
                    {
                        Group = 1,
                        IsCompleted = false,
                        ClearedAt = DateTime.Now.AddHours(-1)
                    },
                    new ObjectiveProgressGroup
                    {
                        Group = 2,
                        IsCompleted = false,
                        ClearedAt = DateTime.Now.AddHours(-1)
                    },
                    new ObjectiveProgressGroup
                    {
                        Group = 3,
                        IsCompleted = false,
                        ClearedAt = DateTime.Now.AddHours(-1)
                    }
                }
            };

            if (!Database.ProgressionDatabase.Exists(accessToken.PlatformId))
            {
                Database.ProgressionDatabase.WriteGeneric<ObjectiveProgress>(accessToken.PlatformId, progress);

                response.Status(HttpStatusCodes.OK).Json(progress).Finish();
                return;
            }

            else
            {
                var progressiondb = Database.ProgressionDatabase.ReadGeneric<ObjectiveProgress>(accessToken.PlatformId);
                response.Status(HttpStatusCodes.OK).Json(progressiondb).Finish();
            }

            

        }

        //weekly
        [HttpEndpoint(HttpMethods.GET, "/api/challenges/v1/GetCurrent")]
        public void OnMyWeeklyRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var serverTime = DateTime.Now;
            var challengeMap = new ChallengeMap
            {
                ChallengeMapId = 1,
                CompleteAll = false,
                StartAt = serverTime.AddDays(-2),
                EndAt = serverTime.AddDays(5),
                ServerTime = serverTime,

                Challenges = new RecNetChallenge[3] 
                {
                    new RecNetChallenge { ChallengeId = 1, Complete = false, Name = "Go-to the RecCenter", Config = "[]", Description = "", Tooltip = "" },
                    new RecNetChallenge { ChallengeId = 2, Complete = false, Name = "Complete Objective 2", Config = "[]", Description = "", Tooltip = "" },
                    new RecNetChallenge { ChallengeId = 3, Complete = false, Name = "Complete Objective 3", Config = "[]", Description = "", Tooltip = "" } 
                },

                Gifts = new RecNetGiftDrop[] 
                {
                    new RecNetGiftDrop
                    { 
                        GiftDropId = 14,
                        GiftContext = GiftContext.All_Weekly_Challenge_Complete,
                        EquipmentModificationGuid = "d218ae45-8534-4f96-b2ed-1cf281bc3578",
                        EquipmentPrefabName = "[ShareCamera]",
                        GiftRarity = GiftRarity.Legendary,
                        AvatarItemDesc = "",
                        ConsumableItemDesc = "",
                        Level = 1,
                        StorefrontType = Json.Storefronts.StorefrontType.Watch,
                        Xp = 0,
                        
                    },
                 },

                ChallengeThemeId = 0,
                ChallengeThemeString = "Default"
            };

            var result = new RecNetResult
            {
                Success = true,
                Message = JsonConvert.SerializeObject(challengeMap)
            };

            response.Status(HttpStatusCodes.OK).Json(challengeMap).Finish();
        }

        //orientation
        [HttpEndpoint(HttpMethods.GET, "/api/checklist/v1/current")]
        public void OnMyChecklistRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }



            response.Status(HttpStatusCodes.OK).Json(new object[0]).Finish();
        }

        [HttpEndpoint(HttpMethods.GET, "/api/playerevents/v1/all")]
        public void OnPlayerEventsRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var eventsBackend = BackendService.GetBackend<Events>();
            eventsBackend.GetEventList(accessToken).WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.GET, "/api/events/v3/list")]
        public void OnFeaturedEventsRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var eventsBackend = BackendService.GetBackend<Events>();
            eventsBackend.GetFeaturedEventList(accessToken).WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.GET, "/api/rooms/v2/myrooms")]
        public void OnMyRoomsRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var roomsBackend = BackendService.GetBackend<Rooms>();
            roomsBackend.GetMyRooms(accessToken).WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.POST, "/api/playersubscriptions/v1/subscribe/{PlayerId}")]
        [HttpDynamicUse("{PlayerId}")]
        public void OnSubscribe(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            



            Logger.Info(request.Body.ToJson());

        }

        [HttpEndpoint(HttpMethods.POST, "/api/PlayerCheer/v1/create")]
        public void OnCreateCheer(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var data = JsonConvert.DeserializeObject<CheerData>(request.Form.ToJson());
            Logger.Info(data.ToJson());

            var noti = new NotificationMessage
            {
                Type = NotificationMessageType.PlayerCheer,
                Id = Openlabs.Mgcxm.Common.Random.Range(0, Int32.MaxValue),
                Data = request.Form["CheerCategory"],
                FromPlayerId = accessToken.PlayerId,
                SentTime = DateTime.UtcNow,
                RoomId = null,
                
            };
            
            Logger.Info(JsonConvert.SerializeObject(noti));

            var Notifications = Database.NotificationsDatabase.ReadGeneric<List<NotificationMessage>>(accessToken.PlatformId);

            Notifications.Add(noti);

            Database.NotificationsDatabase.WriteGeneric(accessToken.PlatformId, Notifications);

            var connectionNode = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(data.PlayerIdTo);
            if (connectionNode != null)
            {

                connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                {
                    Id = PushNotificationId.MessageReceived,
                    Msg = noti
                });


                response.Status(HttpStatusCodes.OK).Json(new RecNetResult { Success = true, Message = null }).Finish();
            }

            response.Status(HttpStatusCodes.OK).Json(new RecNetResult { Success = true, Message = null }).Finish();
        }




        [HttpEndpoint(HttpMethods.POST, "/api/rooms/v1/modifyPermissions")]
        public void ModifyPerms(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {

            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var data = JsonConvert.DeserializeObject<RoomPermissionRequestV2>(request.Body);

            long playerId = data.PlayerId;
            long roomId = data.RoomId;
            bool IsOwner = data.IsOwner;
            bool IsHost = data.IsHost;

            var details = Database.RoomDetailsDatabase.ReadGeneric<RoomDetails>(roomId.ToString());
            var connectionNode = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(playerId);
            if (IsOwner == true)
            {
                Logger.Info("Co-Owner");
                if (details.CoOwners.Contains(playerId) == false)
                { 
                    details.Hosts.Remove(playerId);
                    details.CoOwners.Add(playerId);

                    Database.RoomDetailsDatabase.WriteGeneric<RoomDetails>(roomId.ToString(), details);

                   

                    var noti = new NotificationMessage()
                    {
                        FromPlayerId = 1,
                        Id = playerId,
                        Type = NotificationMessageType.RoomCoOwnerAdded,

                    };

                    if (connectionNode != null)
                    {
                        connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                        {
                            Id = PushNotificationId.MessageReceived,
                            Msg = noti
                        });
                    }

                    if (connectionNode != null)
                    {
                        connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                        {
                            Id = PushNotificationId.SubscriptionUpdateRoom,
                            Msg = details
                        });
                    }
                }
            
            }


            else if (IsHost == true)
            {
                Logger.Info("Host");
                if (details.Hosts.Contains(playerId) == false)
                {
                    details.CoOwners.Remove(playerId);
                    details.Hosts.Add(playerId);

                    if (connectionNode != null)
                    {
                        connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                        {
                            Id = PushNotificationId.SubscriptionUpdateRoom,
                            Msg = details
                        });
                    }

                    Database.RoomDetailsDatabase.WriteGeneric<RoomDetails>(roomId.ToString(), details);

                }
            }

            else if (IsHost == false && IsOwner == false)
            {
                Logger.Info("Guest");
                details.Hosts.Remove(playerId);
                details.CoOwners.Remove(playerId);
               
                if (connectionNode != null)
                {
                    connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                    {
                        Id = PushNotificationId.SubscriptionUpdateRoom,
                        Msg = details
                    });
                }
                Database.RoomDetailsDatabase.WriteGeneric<RoomDetails>(roomId.ToString(), details);

            }

            Database.RoomDetailsDatabase.WriteGeneric<RoomDetails>(roomId.ToString(), details);

            var room = Database.RoomsDatabase.ReadGeneric<Carbon.Json.Rooms.Room>(roomId.ToString());
            Logger.Info(details.ToJson());


            var permresp = new ModifyRoomResponse();
            permresp.Result = 0;
            permresp.Room = room;

            response.Status(HttpStatusCodes.OK).Json(permresp).Finish();

        }

        [HttpEndpoint(HttpMethods.GET, "/api/rooms/v3/details/{roomId}")]
        [HttpDynamicUse("{roomId}")]
        public void OnRoomDetailsRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            long roomId = long.Parse(request.Uri.Split("/")[5]);
            var roomsBackend = BackendService.GetBackend<Rooms>();
            roomsBackend.GetRoomDetailsCombine(accessToken, roomId).WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.POST, "/api/rooms/v1/modify/name")]
        public void OnModifyRoomNameRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var roomsBackend = BackendService.GetBackend<Rooms>();
            roomsBackend.ModifyRoomName(accessToken, JsonConvert.DeserializeObject<ModifyNameRequest>(request.Body)!)
                .WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.POST, "/api/rooms/v1/modify/imagename")]
        public void OnModifyRoomImageNameRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var roomsBackend = BackendService.GetBackend<Rooms>();
            roomsBackend.ModifyImageName(accessToken, JsonConvert.DeserializeObject<ModifyImageNameRequest>(request.Body)!)
                .WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.POST, "/api/rooms/v1/modify/maxplayers")]
        public void OnModifyRoomMaxPlayerRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var roomsBackend = BackendService.GetBackend<Rooms>();
            roomsBackend.ModifyMaxPlayers(accessToken, JsonConvert.DeserializeObject<ModifyMaxPlayersRequest>(request.Body)!)
                .WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.POST, "/api/rooms/v1/modify/description")]
        public void OnModifyRoomDescriptionRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var roomsBackend = BackendService.GetBackend<Rooms>();
            roomsBackend.ModifyDescription(accessToken, JsonConvert.DeserializeObject<ModifyDescriptionRequest>(request.Body)!)
                .WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.POST, "/api/rooms/v1/modify/screenmode")]
        public void OnModifyRoomScreenModeRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var roomsBackend = BackendService.GetBackend<Rooms>();
            roomsBackend.ModifyScreenMode(accessToken, JsonConvert.DeserializeObject<ModifyScreenModeRequest>(request.Body)!)
                .WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.POST, "/api/rooms/v1/modify/instanced")]
        public void OnModifyRoomInstancedRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var roomsBackend = BackendService.GetBackend<Rooms>();
            roomsBackend.ModifyInstanced(accessToken, JsonConvert.DeserializeObject<ModifyInstancedRequest>(request.Body)!)
                .WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.POST, "/api/rooms/v1/saveData/{roomId}")]
        [HttpDynamicUse("{roomId}")]
        public void OnUpdateRoomSaveRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var roomId = long.Parse(request.Uri.Split("/")[5]);
            var roomsBackend = BackendService.GetBackend<Rooms>();
            roomsBackend.SaveRoom(accessToken, roomId, request.RawBodyData)
                .WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.POST, "/api/players/v1/list")]
        public void OnListProfilesRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var loginBackend = BackendService.GetBackend<Login>();
            loginBackend.ListProfiles(accessToken, JsonConvert.DeserializeObject<long[]>(request.Body)!).WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.POST, "/api/players/v2/displayname")]
        public void OnUpdatePlayerNameRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var loginBackend = BackendService.GetBackend<Login>();
            loginBackend.GetProfile(accessToken, accessToken.PlayerId).Then(localProfile =>
            {
                localProfile.DisplayName = WebUtility.UrlDecode(request.Form["Name"]);
                loginBackend.UpdateProfile(accessToken, localProfile).WriteOnSuccess(request, response);
            });
        }

        [HttpEndpoint(HttpMethods.GET, "/api/activities/charades/v1/words")]
        public void OnCharadeWordsRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            var content = Database.ActivityDataDatabase.ReadString("charade_words");
            List<CharadeWord> charadeWords = new List<CharadeWord>();

            foreach (var word in content.Split("\r\n"))
            {
                charadeWords.Add(new CharadeWord
                {
                    Word = word.Trim(),
                    Difficulty = 0
                });
            }

            response.Status(HttpStatusCodes.OK)
                    .Json(charadeWords).Finish();
        }

        [HttpEndpoint(HttpMethods.POST, "/api/gamesessions/v2/joinrandom")]
        public void OnJoinRandomRoomRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var gameSessionsBackend = BackendService.GetBackend<GameSessions>();
            gameSessionsBackend.JoinRandom(accessToken, JsonConvert.DeserializeObject<JoinRandomGameSessionRequest>(request.Body)!)
                .WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.POST, "/api/gamesessions/v2/joinplayer")]
        public void OnJoinPlayerRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var gameSessionsBackend = BackendService.GetBackend<GameSessions>();
            gameSessionsBackend.JoinPlayer(accessToken, JsonConvert.DeserializeObject<JoinPlayerRequest>(request.Body)!)
                .WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.POST, "/api/gamesessions/v2/joinroom")]
        public void OnJoinRoomRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var gameSessionsBackend = BackendService.GetBackend<GameSessions>();
            gameSessionsBackend.JoinRoom(accessToken, JsonConvert.DeserializeObject<JoinRoomRequest>(request.Body)!)
                .WriteOnItem(request, response);
        }


        [HttpEndpoint(HttpMethods.POST, "/api/gamesessions/v2/create")]
        public void OnCreateCustomGameSessionRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var gameSessionsBackend = BackendService.GetBackend<GameSessions>();
            gameSessionsBackend.Create(accessToken, JsonConvert.DeserializeObject<CreateCustomGameSessionRequest>(request.Body)!)
                .WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.POST, "/api/gamesessions/v2/reportjoinresult")]
        public void OnReportGameJoinResult(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var joinResult = JsonConvert.DeserializeObject<ReportGameJoinResultRequest>(request.Body);
            if (joinResult != null && joinResult.Result == GameSessionJoinResult.Success)
            {
                var playerSubscriptionsBackend = BackendService.GetBackend<PlayerSubscriptions>();
                playerSubscriptionsBackend.NonBackend_ReportStatusToSubscribers(accessToken);
            }
            response.Status(HttpStatusCodes.OK).Finish();
        }

        [HttpEndpoint(HttpMethods.GET, "/api/relationships/v2/sendfriendrequest")]
        public void OnSendFriendRequestRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }



            var PlayerId = long.Parse(request.Query["id"]);

            if (PlayerId == accessToken.PlayerId)
            {
                response.Status(HttpStatusCodes.NotAcceptable).Finish();
                return;
            }

            var localrelationship = new Relationship()
            {
                PlayerID = PlayerId,
                RelationshipType = RelationshipType.FriendRequestReceived,
                Favorited = ReciprocalStatus.None,
                Ignored = ReciprocalStatus.None,
                Muted = ReciprocalStatus.None

            };

            var relationship = new Relationship()
            {
                PlayerID = accessToken.PlayerId,
                RelationshipType = RelationshipType.FriendRequestSent,
                Favorited = ReciprocalStatus.None,
                Ignored = ReciprocalStatus.None,
                Muted = ReciprocalStatus.None

            };

            var connectionNode = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(PlayerId);

            if (connectionNode != null)
            {
                connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                {
                    Id = PushNotificationId.MessageReceived,
                    Msg = relationship
                });
            }


            var friendRequest = new NotificationMessage()
            {
                FromPlayerId = accessToken.PlayerId,
                Type = NotificationMessageType.FriendInvite,
                Data = null

            };

            var remote_platId = BackendService.GetBackend<Login>().getUserProfile(PlayerId).PlatformId.Id;
            var notifications = Database.NotificationsDatabase.ReadGeneric<List<NotificationMessage>>(remote_platId);

            notifications.Add(friendRequest);
            Database.NotificationsDatabase.WriteGeneric<List<NotificationMessage>>(remote_platId, notifications);

            if (connectionNode != null)
            {
                connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                {
                    Id = PushNotificationId.MessageReceived,
                    Msg = friendRequest
                });
            }



            response.Status(HttpStatusCodes.OK).Json(localrelationship).Finish();
        }

        [HttpEndpoint(HttpMethods.GET, "/api/relationships/v2/acceptfriendrequest")]
        public void OnAcceptFriendRequestRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var PlayerId = long.Parse(request.Query["id"]);

            var relationship = new Relationship()
            {
                PlayerID = PlayerId,
                RelationshipType = RelationshipType.Friend,
                Favorited = ReciprocalStatus.None,
                Ignored = ReciprocalStatus.None,
                Muted = ReciprocalStatus.None

            };

            var relationship2 = new Relationship()
            {
                PlayerID = accessToken.PlayerId,
                RelationshipType = RelationshipType.Friend,
                Favorited = ReciprocalStatus.None,
                Ignored = ReciprocalStatus.None,
                Muted = ReciprocalStatus.None

            };

            var connectionNode = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(PlayerId);
            var connectionNode2 = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(accessToken.PlayerId);



            var friendRequest = new NotificationMessage()
            {
                FromPlayerId = accessToken.PlayerId,
                Type = NotificationMessageType.FriendRequestAccepted,
                Data = null

            };

            if (connectionNode != null)
            {


                connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                {
                    Id = PushNotificationId.MessageReceived,
                    Msg = friendRequest
                });
            }



            if (connectionNode != null)
            {
                connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                {
                    Id = PushNotificationId.RelationshipChanged,
                    Msg = relationship2
                });

            }

            if (connectionNode2 != null)
            {
                connectionNode2.Handler.SendNotificationBulk(new PushNotificationObject
                {
                    Id = PushNotificationId.RelationshipChanged,
                    Msg = relationship
                });
            }

            var remote_platId = BackendService.GetBackend<Login>().getUserProfile(PlayerId).PlatformId.Id;


            var local_Relationships = Database.RelationshipsDatabase.ReadGeneric<List<Relationship>>(accessToken.PlatformId);
            var remote_Relationships = Database.RelationshipsDatabase.ReadGeneric<List<Relationship>>(remote_platId);

            local_Relationships.Add(relationship);
            remote_Relationships.Add(relationship2);

            Database.RelationshipsDatabase.WriteGeneric(accessToken.PlatformId, local_Relationships);
            Database.RelationshipsDatabase.WriteGeneric(remote_platId, remote_Relationships);

            response.Status(HttpStatusCodes.OK).Json(relationship).Finish();

        }

        [HttpEndpoint(HttpMethods.GET, "/api/relationships/v2/addfriend")]
        public void OnAddFriendRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }


            var Relationships = Database.RelationshipsDatabase.ReadGeneric<List<Relationship>>(accessToken.PlatformId);

            var relationship = new Relationship()
            {
                PlayerID = accessToken.PlayerId,
                RelationshipType = RelationshipType.Friend,
                Favorited = ReciprocalStatus.None,
                Ignored = ReciprocalStatus.None,
                Muted = ReciprocalStatus.None

            };


            Relationships.Add(relationship);

            Database.RelationshipsDatabase.WriteGeneric(accessToken.PlatformId.ToString(), Relationships);


            response.Status(HttpStatusCodes.OK).Json(relationship).Finish();



        }

        [HttpEndpoint(HttpMethods.GET, "/api/relationships/v2/removefriend")]
        public void OnRemoveFriendRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }
            var PlayerId = long.Parse(request.Query["id"]);

            var loginBackend = BackendService.GetBackend<Login>();
            var remoteplr = loginBackend.getUserProfile(PlayerId);

            var remotePlatId = remoteplr.PlatformId.Id;

            var emptyRel = new Relationship()
            {
                PlayerID = PlayerId,
                RelationshipType = RelationshipType.None,
                Favorited = ReciprocalStatus.None,
                Ignored = ReciprocalStatus.None,
                Muted = ReciprocalStatus.None

            };

            var emptyRel2 = new Relationship()
            {
                PlayerID = accessToken.PlayerId,
                RelationshipType = RelationshipType.None,
                Favorited = ReciprocalStatus.None,
                Ignored = ReciprocalStatus.None,
                Muted = ReciprocalStatus.None

            };


            var Relationships = Database.RelationshipsDatabase.ReadGeneric<List<Relationship>>(accessToken.PlatformId);
            var Relationships2 = Database.RelationshipsDatabase.ReadGeneric<List<Relationship>>(remotePlatId);

            var new_relationship = new Relationship()
            {
                PlayerID = accessToken.PlayerId,
                RelationshipType = RelationshipType.None,
                Favorited = ReciprocalStatus.None,
                Ignored = ReciprocalStatus.None,
                Muted = ReciprocalStatus.None

            };

            var new_relationship2 = new Relationship()
            {
                PlayerID = PlayerId,
                RelationshipType = RelationshipType.None,
                Favorited = ReciprocalStatus.None,
                Ignored = ReciprocalStatus.None,
                Muted = ReciprocalStatus.None

            };

            var prev_relationship = Relationships.FirstOrDefault(rel => rel.PlayerID == PlayerId, emptyRel);
            var prev_relationship2 = Relationships2.FirstOrDefault(rel => rel.PlayerID == accessToken.PlayerId, emptyRel2);









            Relationships.Remove(prev_relationship2);
            Relationships.Add(new_relationship2);
            Relationships.Remove(prev_relationship);
            Relationships.Add(new_relationship);

            Database.RelationshipsDatabase.WriteGeneric(accessToken.PlatformId.ToString(), Relationships2);
            Database.RelationshipsDatabase.WriteGeneric(remotePlatId, Relationships);

            var connectionNode = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(accessToken.PlayerId);
            var connectionNode2 = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(remotePlatId);

            if (connectionNode != null)
            {
                connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                {
                    Id = PushNotificationId.RelationshipChanged,
                    Msg = new_relationship2
                });
            }

            if (connectionNode2 != null)
            {
                connectionNode2.Handler.SendNotificationBulk(new PushNotificationObject
                {
                    Id = PushNotificationId.RelationshipChanged,
                    Msg = new_relationship
                });
            }

            response.Status(HttpStatusCodes.OK).Json(new_relationship).Finish();

        }

        [HttpEndpoint(HttpMethods.POST, "/api/players/v2/listByPlatformId")]
        public void listPlatforIds(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var platformIds = new List<PlatformId>();



            response.Status(HttpStatusCodes.OK).Json(platformIds).Finish();
        }

        [HttpEndpoint(HttpMethods.POST, "/api/images/v3/uploadsaved")]
        public void OnUploadSavedImageRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var imageBackend = BackendService.GetBackend<Images>();
            imageBackend.UploadSavedImage(accessToken, request.RawBodyData)
                .WriteOnItem(request, response);
        }

        [HttpEndpoint(HttpMethods.POST, "/api/images/v3/profile")]
        public void OnUploadProfileImageRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var loginBackend = BackendService.GetBackend<Login>();
            var imageBackend = BackendService.GetBackend<Images>();
            var connectionHandler = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(accessToken.PlayerId).Handler;

            loginBackend.GetProfile(accessToken, accessToken.PlayerId).Then(localPlayer =>
            {
                imageBackend.UploadSavedImage(accessToken, request.RawBodyData).Then(imageNameResponse =>
                {
                    localPlayer.ProfileImageName = imageNameResponse.ImageName;

                    loginBackend.UpdateProfile(accessToken, localPlayer).Then(() =>
                    {
                        connectionHandler.SendNotificationBulk(new PushNotificationDto<Profile>
                        {
                            Id = PushNotificationId.SubscriptionUpdateProfile,
                            Msg = localPlayer
                        });
                        response.Status(HttpStatusCodes.OK).Finish();
                    }).Catch(ex =>
                    {
                        Logger.Error("Failed to update player image: " + ex.ToString());
                        response.Status(HttpStatusCodes.InternalServerError).Finish();
                    });
                }).Catch(ex =>
                {
                    Logger.Error("Failed to update player image: " + ex.ToString());
                    response.Status(HttpStatusCodes.InternalServerError).Finish();
                });
            }).Catch(ex =>
            {
                Logger.Error("Failed to update player image: " + ex.ToString());
                response.Status(HttpStatusCodes.InternalServerError).Finish();
            });
        }

        [HttpEndpoint(HttpMethods.POST, "/api/presence/v2/list")]
        public void OnPresenceListRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var presenceBackend = BackendService.GetBackend<Presence>();
            List<long> playerIds = JsonConvert.DeserializeObject<List<long>>(request.Body);

            response.Status(HttpStatusCodes.OK)
                    .Json(presenceBackend.NonBackend_GetPlayerPresences(playerIds))
                    .Finish();
        }
        [HttpEndpoint(HttpMethods.POST, "/api/players/v1/objectives")]
        public void onObjective(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }
            Logger.Info(request.Body);
            var data = JsonConvert.DeserializeObject<List<GameObjective>>(request.Body);

            if (data.Any(objective => objective.objectiveType == ObjectiveType.ArenaWins))
            {
               
                var gift = new GiftPackage()
                {
                    GiftContext = GiftContext.Game_Drop,
                    GiftRarity = GiftRarity.Rare,
                    AvatarItemDesc = "",
                    ConsumableItemDesc = "",
                    CurrencyType = CurrencyType.LaserTagTickets,
                    Currency = 100,
                    Xp = 0,
                    Message = "LazerTag Match!",
                    EquipmentModificationGuid = "",
                    EquipmentPrefabName = "",
                    Id = Openlabs.Mgcxm.Common.Random.Range(100000, 999999),
                    Level = 1

                };

                var gifts = Database.GiftsDatabase.ReadGeneric<List<GiftPackage>>(accessToken.PlatformId);

                gifts.Add(gift);

                Database.GiftsDatabase.WriteGeneric(accessToken.PlatformId, gifts);
                


                var connectionNode = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(accessToken.PlayerId);

                if (connectionNode != null)
                {
                    connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                    {
                        Id = PushNotificationId.GiftPackageReceived,
                        Msg = gift
                    });

                }
            }

            response.Status(HttpStatusCodes.OK).Finish();
        }

        [HttpEndpoint(HttpMethods.POST, "/api/storefronts/v1/objectives")]
        public void onStoreFront(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            


            response.Status(HttpStatusCodes.OK).Finish();
        }


        [HttpEndpoint(HttpMethods.POST, "/api/storefronts/v1/buyItem")]
        public void OnPurchaseItem(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            var data = JsonConvert.DeserializeObject<PurchaseItem>(request.Body);

            Logger.Info(data.ToJson());
            var storefront = new Storefront();
            if (data.StorefrontType == StorefrontType.LaserTag)
            {
                storefront = Database.StorefrontDatabase.ReadGeneric<Storefront>("storefront2");
            }
            else
            {
                storefront = Database.StorefrontDatabase.ReadGeneric<Storefront>("storefront");
            }
            
            var balance = Database.EconDatabase.ReadGeneric<List<BalanceResponseDTO>>(accessToken.PlatformId.ToString());
            var Gifts = Database.GiftsDatabase.ReadGeneric<List<GiftPackage>>(accessToken.PlatformId);




            var storefrontBackend = BackendService.GetBackend<Storefronts>();


            var Item = storefront.StoreItems.ElementAt(data.PurchasableItemId - 1).GiftDrops.ElementAt(0);
            Logger.Info(Item.ToJson());
            var price = storefront.StoreItems.ElementAt(data.PurchasableItemId - 1).Prices.ElementAt(0).Price;
            Logger.Info(price.ToString());
            if(!balance.Any(item => item.CurrencyType == data.CurrencyType))
            {
                var new_bal = new BalanceResponseDTO()
                {
                    Balance = 0,
                    CurrencyType = data.CurrencyType
                };

                balance.Add(new_bal);
                
            }

            var currency = balance.FirstOrDefault(item => item.CurrencyType == data.CurrencyType);

            

            var bal = int.Parse(currency.Balance.ToString());

            var result_bal = bal - price;
            Logger.Info(result_bal.ToString());
            var id = 0;

            currency.Balance = long.Parse(result_bal.ToString());

           

            if (Item.ConsumableItemDesc == "JfnVXFmilU6ysv-VbTAe3A") 
            {
                id = 1;
            }
            else if (Item.ConsumableItemDesc == "mq23W-RSP0G8iGNLdrcpUw")
            {
                id = 2;
            }
            else
            {
                id = 3;
            }
            var result = new BuyItemResponse()
            {
                Balance = long.Parse(result_bal.ToString()),
                CurrencyType = data.CurrencyType,
                BalanceUpdates = new List<PurchaseBalanceUpdateResponse>()
                {
                    new PurchaseBalanceUpdateResponse()
                    {
                        UpdateResponse = PurchaseResponse.OK,
                        
                        
                        

                        Data = new List<GiftItem>()
                        {
                            new GiftItem()
                            {
                                Id = id,
                                AvatarItemDesc = Item.AvatarItemDesc,
                                ConsumableItemDesc = Item.ConsumableItemDesc,
                                EquipmentPrefabName = Item.EquipmentPrefabName,
                                EquipmentModificationGuid =  Item.EquipmentModificationGuid,
                                Currency = 0,
                                CurrencyType = CurrencyType.RecCenterTokens,
                                GiftContext = Item.Context,
                                Level = 0,
                                Xp = 0,
                                Message = "Storefront Purchase"
                            }
                        }
                    }
                }

             
            };

            Gifts.Add(new GiftPackage()
            {
                Id = id,
                AvatarItemDesc = Item.AvatarItemDesc,
                ConsumableItemDesc = Item.ConsumableItemDesc,
                EquipmentPrefabName = Item.EquipmentPrefabName,
                EquipmentModificationGuid = Item.EquipmentModificationGuid,
                Currency = 0,
                CurrencyType = CurrencyType.RecCenterTokens,
                GiftContext = Item.Context,
                Level = 0,
                Xp = 0,
                Message = "Storefront Purchase",
                GiftRarity = GiftRarity.Legendary
            });


            Database.GiftsDatabase.WriteGeneric<List<GiftPackage>>(accessToken.PlatformId, Gifts);


            
            Database.EconDatabase.WriteGeneric<List<BalanceResponseDTO>>(accessToken.PlatformId, balance);
            Database.GiftsDatabase.WriteGeneric<List<GiftPackage>>(accessToken.PlatformId, Gifts);
            Logger.Info(result.ToJson());
            response.Status(HttpStatusCodes.OK).Json(result).Finish();
            

        }

        [HttpEndpoint(HttpMethods.POST, "/api/objectives/v1/updateobjective")]
        public void OnObjectiveUpdate(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }



            var result = new RecNetResult()
            {
                Success = true,
                Message = null
            };

            Logger.Info(result.ToJson());

            response.Status(HttpStatusCodes.OK).Json(result).Finish();


        }



        [HttpEndpoint(HttpMethods.POST, "/api/PlayerReporting/v3/create")]
        public void OnReportCreate(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }
            
            var data = JsonConvert.DeserializeObject<reportdetails>(request.Form.ToJson());
            Logger.Info(data.ToJson());

            var details = new ModerationBlockDetail()
            {
                ReportCategory = data.ReportCategory,
                Duration = int.Parse(data.Details),
                GameSessionId = -1,
                Message = "",
                EndTime = DateTime.UtcNow.AddSeconds(int.Parse(data.Details))
            };

            if (details.ReportCategory == ReportCategory.CoC_Trolling)
            {
                details.ReportCategory = ReportCategory.Cheating;
            }

            var id = new List<long> { 1, 23423 };
            if (id.Contains(accessToken.PlayerId))
            {
                var connectionNode = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(data.PlayerIdReported);

                var sessions_backend = BackendService.GetBackend<GameSessions>();

                var sessions = sessions_backend.AllSessions;

                var loginBackend = BackendService.GetBackend<Login>();

                var remote_User = loginBackend.getUserProfile(data.PlayerIdReported);
                var platform = remote_User.PlatformId.Id;
                Logger.Info(platform);

                Logger.Info(details.ToJson());

                Database.BanishmentDatabase.WriteGeneric<ModerationBlockDetail>(platform, details);

                foreach (var session in sessions)
                {
                    if (session.RecRoomId == data.RoomId)
                    {
                        details.GameSessionId = session.GameSessionId;
                        if (connectionNode != null)
                        {
                            connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                            {
                                Id = PushNotificationId.ModerationKick,
                                Msg = details
                            });
                        }

                    }
                   
                }

                var result = new RecNetResult()
                {
                    Success = true,
                    Message = details.ToString()
                };

                response.Status(HttpStatusCodes.OK).Json(result).Finish();

            }


            var nresult = new RecNetResult()
            {
                Success = true,
                Message = null
            };
            
            response.Status(HttpStatusCodes.OK).Json(nresult).Finish();

            
        }

        [HttpEndpoint(HttpMethods.POST, "/api/PlayerReporting/v2/voteToKick")]
        public void OnVoteKick(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }

            try
            {

                var data = JsonConvert.DeserializeObject<VoteKickResponse>(request.Form.ToJson());

                Logger.Info(data.PlayerId.ToString());
                var connectionNode = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(data.PlayerId);

                Logger.Info(request.Body);

                if (accessToken.PlayerId == 1)
                {
                    if (connectionNode != null)
                    {
                        connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                        {
                            Id = PushNotificationId.ModerationKick,
                            Msg = new ModerationBlockDetail() { ReportCategory = ReportCategory.VoteKick, Duration = 1, GameSessionId = data.GameSessionId, Message = "You have been Kicked" }
                        });
                    }

                    var modresult = new RecNetResult()
                    {
                        Success = true,
                        Message = null
                    };

                    response.Status(HttpStatusCodes.OK).Json(modresult).Finish();
                }
                else
                {
                    var result = new RecNetResult()
                    {
                        Success = true,
                        Message = null
                    };

                    response.Status(HttpStatusCodes.OK).Json(result).Finish();
                }
            }

            catch
            {
                var data = JsonConvert.DeserializeObject<VoteKickResponse>(request.Body);

                Logger.Info(data.PlayerId.ToString());
                var connectionNode = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(data.PlayerId);

                Logger.Info(request.Body);

                if (accessToken.PlayerId == 1)
                {
                    if (connectionNode != null)
                    {
                        connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                        {
                            Id = PushNotificationId.ModerationKick,
                            Msg = new ModerationBlockDetail() { ReportCategory = ReportCategory.VoteKick, Duration = 1, GameSessionId = data.GameSessionId, Message = "You have been Kicked" }
                        });
                    }

                    var modresult = new RecNetResult()
                    {
                        Success = true,
                        Message = null
                    };

                    response.Status(HttpStatusCodes.OK).Json(modresult).Finish();
                }
                else
                {
                    var result = new RecNetResult()
                    {
                        Success = true,
                        Message = null
                    };

                    response.Status(HttpStatusCodes.OK).Json(result).Finish();
                }
            }

        }


        [HttpEndpoint(HttpMethods.POST, "/api/PlayerReporting/v1/kickFromEvent")]
        public void OnInstantKick(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!UpdateAccessToken(request, out var accessToken))
            {
                response.Status(HttpStatusCodes.Unauthorized).Finish();
                return;
            }



            var data = JsonConvert.DeserializeObject<VoteKickResponse>(request.Form.ToJson());

            Logger.Info(data.PlayerId.ToString());
            var connectionNode = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(data.PlayerId);
            Logger.Info(request.Body);

            if (connectionNode != null)
            {
                connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                {
                    Id = PushNotificationId.ModerationKick,
                    Msg = new ModerationBlockDetail() { ReportCategory = ReportCategory.VoteKick, Duration = 1, GameSessionId = data.GameSessionId, Message = "You have been Kicked" }

                });
            }

            var result = new RecNetResult()
            {
                Success = true,
                Message = null
            };

            response.Status(HttpStatusCodes.OK).Json(result).Finish();


        }

        #region Admin APIs
        const string SECRET = "f28076b940711f29e90f653b9583bae1";

        [HttpEndpoint(HttpMethods.GET, "/Admin/Sessions")]
        public void OnGetSessions(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!request.Query.ContainsKey("secret"))
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }
            if (request.Query["secret"] != SECRET)
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }

            var gameSessionsBackend = BackendService.GetBackend<GameSessions>();
            response.Status(HttpStatusCodes.OK)
                    .Json(gameSessionsBackend.AllSessions)
                    .Finish();
        }

        [HttpEndpoint(HttpMethods.POST, "/Admin/Sessions/Write")]
        public void OnWriteSession(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!request.Query.ContainsKey("secret"))
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }
            if (request.Query["secret"] != SECRET)
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }
        }

        [HttpEndpoint(HttpMethods.GET, "/Admin/Players")]
        public void OnGetPlayers(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!request.Query.ContainsKey("secret"))
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }
            if (request.Query["secret"] != SECRET)
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }

            var loginBackend = BackendService.GetBackend<Login>();
            if (!request.Query.ContainsKey("id"))
            {
                request.Query.TryGetValue("skip", out var skipStr);
                request.Query.TryGetValue("take", out var takeStr);

                int skip = !string.IsNullOrEmpty(skipStr) ? int.Parse(skipStr) : 0;
                int take = !string.IsNullOrEmpty(takeStr) ? int.Parse(takeStr) : int.MaxValue;

                response.Status(HttpStatusCodes.OK)
                        .Json(loginBackend.GetAllPlayers().Skip(skip).Take(take))
                        .Finish();
            }
            else
            {
                var players = loginBackend.GetAllPlayers();
                var player = players.FirstOrDefault(x => x.Id == long.Parse(request.Query["id"]), Profile.Empty);

                response.Status(HttpStatusCodes.OK)
                        .Json(player)
                        .Finish();
            }
        }

        [HttpEndpoint(HttpMethods.POST, "/Admin/Players/Write")]
        public void OnWritePlayer(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!request.Query.ContainsKey("secret"))
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }
            if (request.Query["secret"] != SECRET)
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }
            if (!request.Query.ContainsKey("id"))
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }

            long id = long.Parse(request.Query["id"]);
            var updatedProfile = JsonConvert.DeserializeObject<Profile>(request.Body);
            var loginBackend = BackendService.GetBackend<Login>();

            loginBackend.GetProfile(null, id).Then(profile =>
            {
                var profileClone = profile.Clone();
                profileClone.ModifyProperties(updatedProfile!);

                loginBackend.UpdateProfile(null, profileClone).WriteOnSuccess(request, response, null, (ex) =>
                {
                    response.Status(HttpStatusCodes.InternalServerError)
                            .Json(ex)
                            .Finish();
                });
            });
        }

       [HttpEndpoint(HttpMethods.POST, "/Admin/Banishments/Write")]
        public void OnBanishment(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!request.Query.ContainsKey("secret"))
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }
            if (request.Query["secret"] != SECRET)
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }
            if (!request.Query.ContainsKey("id"))
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }

            var plrid = request.Query["id"];
            var loginBackend = BackendService.GetBackend<Login>();
            var platid = loginBackend.getUserProfile(long.Parse(plrid)).PlatformId.Id;
            
            Logger.Info(platid);

            var info = JsonConvert.DeserializeObject<baninfo>(request.Form.ToJson());
            Logger.Info(info.ToJson());

            if (!Database.BanishmentDatabase.Exists(platid))
            {
                var ban = new ModerationBlockDetail()
                {
                    ReportCategory = info.banType,
                    Duration = info.duration,
                    EndTime = DateTime.UtcNow.AddSeconds(info.duration),
                    GameSessionId = -1,
                    Message = ""
                };

               

                Logger.Info(ban.ToJson());
                Database.BanishmentDatabase.WriteGeneric(platid, ban);

                var connectionNode = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(plrid);
                if (connectionNode != null)
                {
                    connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                    {
                        Id = PushNotificationId.ModerationKick,
                        Msg = ban
                    });
                }

            }
            else
            {
                var ban = new ModerationBlockDetail()
                {
                    ReportCategory = info.banType,
                    Duration = info.duration,
                    EndTime = DateTime.UtcNow.AddSeconds(info.duration),
                    GameSessionId = -1,
                    Message = ""
                };

                Logger.Info(ban.ToJson());
                Database.BanishmentDatabase.WriteGeneric(platid, ban);

                var connectionNode = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(plrid);
                if (connectionNode != null)
                {
                    connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                    {
                        Id = PushNotificationId.ModerationKick,
                        Msg = ban
                    });
                }
            }

            response.Status(HttpStatusCodes.OK).Finish();

        }

        

        

        [HttpEndpoint(HttpMethods.GET, "/Admin/Players/Quit")]
        public void OnQuitPlayer(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!request.Query.ContainsKey("secret"))
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }
            if (request.Query["secret"] != SECRET)
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }

            if (!request.Query.ContainsKey("playerId"))
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }

            var playerId = long.Parse(request.Query["playerId"]);
            var connectionNode = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(playerId);

            if (connectionNode != null)
            {
                connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                {
                    Id = PushNotificationId.ModerationQuitGame,
                    Msg = null
                });
            }
        }

        [HttpEndpoint(HttpMethods.GET, "/Admin/Players/QuitAll")]
        public void OnQuitAllPlayers(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!request.Query.ContainsKey("secret"))
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }
            if (request.Query["secret"] != SECRET)
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }

            foreach (var node in Singleton<NotificationsServer>.Instance.NotificationConnectionTree.AllNodes)
            {
                node.Handler.SendNotificationBulk(new PushNotificationObject
                {
                    Id = PushNotificationId.ModerationQuitGame,
                    Msg = null
                });
            }
        }

        [HttpEndpoint(HttpMethods.POST, "/Admin/Gifts/Send")]
        public void OnSendGift(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!request.Query.ContainsKey("secret"))
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }
            if (request.Query["secret"] != SECRET)
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }

            if (!request.Query.ContainsKey("platformId"))
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }

            var platid = request.Query["platformId"];
            Logger.Info(request.Body);
            var gift = JsonConvert.DeserializeObject<GiftPackage>(request.Body);
            var Gifts = Database.GiftsDatabase.ReadGeneric<List<GiftPackage>>(platid);

            Logger.Info(Gifts.ToJson());
            Gifts.Add(gift);
            Logger.Info(Gifts.ToJson());

            Database.GiftsDatabase.WriteGeneric<List<GiftPackage>>(platid, Gifts);
            var connectionNode = Singleton<NotificationsServer>.Instance.NotificationConnectionTree.GetNode(gift.Id);

            try
            {
                connectionNode.Handler.SendNotificationBulk(new PushNotificationObject
                {
                    Id = PushNotificationId.GiftPackageReceived,
                    Msg = gift
                }) ;

            }
            catch
            {
                 response.Status(HttpStatusCodes.OK).Finish();
                return;
            }

            response.Status(HttpStatusCodes.OK).Finish();
        }



        [HttpEndpoint(HttpMethods.GET, "/Admin/BanAppeals")]
        public void OnGetBanAppeals(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!request.Query.ContainsKey("secret"))
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }
            if (request.Query["secret"] != SECRET)
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }

            response.Status(HttpStatusCodes.OK)
                    .Json(Array.Empty<object>())
                    .Finish();
        }

        [Flags]
        public enum GetRoomsType
        {
            DormRoom = 1 << 0,  // 1
            RRO = 1 << 1,      // 2
            UGC = 1 << 2,      // 4
            All = DormRoom | RRO | UGC  // 7 (1 + 2 + 4)
        }

        [HttpEndpoint(HttpMethods.GET, "/Admin/Rooms")]
        public void OnGetRooms(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!request.Query.ContainsKey("secret"))
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }
            if (request.Query["secret"] != SECRET)
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }

            var roomsBackend = BackendService.GetBackend<Rooms>();
            response.Status(HttpStatusCodes.OK)
                    .Json(roomsBackend.NonBackend_GetAllRooms())
                    .Finish();
        }

        [HttpEndpoint(HttpMethods.POST, "/Admin/Rooms/Write")]
        public void OnWriteRoom(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!request.Query.ContainsKey("secret"))
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }
            if (request.Query["secret"] != SECRET)
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Finish();
                return;
            }

            var room = JsonConvert.DeserializeObject<Carbon.Json.Rooms.Room>(request.Body);
            var roomsBackend = BackendService.GetBackend<Rooms>()!;
            roomsBackend.UpdateRoom(null!, room).WriteOnSuccess(request, response);
        }
        #endregion

        private bool UpdateAccessToken(MgcxmHttpRequest request, out AccessToken token)
        {
            token = null;

            if (!request.Headers.ContainsKey("Authorization"))
            {
                Constants.ApiSink.Error("Failed to UpdateAccessToken(): auth header is not present.");
                return false;
            }

            try
            {
                var tokenString = request.Headers["Authorization"].Substring("Bearer ".Length);
                token = AccessToken.GetCached(tokenString);
            }
            catch (Exception ex)
            {
                Constants.ApiSink.Exception("Failed to UpdateAccessToken()", ex);
                return false;
            }

            return true;
        }
    }
}
