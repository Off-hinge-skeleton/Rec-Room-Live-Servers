﻿using Openlabs.Mgcxm.Net;
using Openlabs.Mgcxm.Internal;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Carbon.Utilities;
using Carbon.Configs;

namespace Carbon.Servers
{
    internal class AuthServer : MgcxmHttpListener
    {
        public AuthServer() : base(
            Constants.LOCAL_AUTH_SERVER_HOSTNAME, 
            !Program.SELFHOST ? Constants.HOSTNAME : Constants.SELFHOST_AUTH_SERVER_HOSTNAME,
            certificate: Constants.SSL ? SslConfig.Instance.GetCertificate() : null)
        {
            Singleton<AuthServer>.Allocate(this);
        }
        ~AuthServer() { Singleton<AuthServer>.Free(); }
    }
}
