﻿using Carbon.Backend.Databasing;
using Carbon.Configs;
using Carbon.Utilities;
using HttpMultipartParser;
using Openlabs.Mgcxm.Assets;
using Openlabs.Mgcxm.Net;
using OpenlabsSDKV1.Core;
using OpenlabsSDKV1.Core.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Servers
{
    internal class CdnServer : MgcxmHttpListener
    {
        public CdnServer() : base(
            Constants.LOCAL_CDN_SERVER_HOSTNAME,
            !Program.SELFHOST ? Constants.HOSTNAME : Constants.SELFHOST_CDN_SERVER_HOSTNAME,
            certificate: Constants.SSL ? SslConfig.Instance.GetCertificate() : null)
        {
            Singleton<CdnServer>.Allocate(this);
        }
        ~CdnServer() { Singleton<CdnServer>.Free(); }

        public void UploadFile(FilePart file,  out string fileName)
        {
            fileName = "";
            if (file == null)
                return; // cant upload a null file!!

            fileName = UUID.CreateUnique().UuidValue;
            var tempBuffer = new byte[file.Data.Length];
            file.Data.Read(tempBuffer, 0, (int)file.Data.Length);

            Database.ContentDatabase.WriteBytes(fileName, tempBuffer);
        }

        [HttpEndpoint(HttpMethods.GET, "/{fileType}/{fileName}")]
        public void OnCdnBlobRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            try
            {
                var fileName = request.Uri.Split("/")[2];
                if (Database.ContentDatabase.Exists(fileName))
                {
                    response.Status(HttpStatusCodes.OK)
                            .Content(HttpContentTypes.BinaryData, Database.ContentDatabase.ReadBytes(fileName));
                    response.Finish();
                }
                else
                {
                    response.Status(HttpStatusCodes.NotFound).Finish();
                }
            }
            catch (Exception ex)
            {
                response.Status(HttpStatusCodes.InternalServerError)
                        .Content(HttpContentTypes.PlainText, "Failed to process your request:\n" + ex.ToString()).Finish();
            }
        }
    }
}
