﻿using Openlabs.Mgcxm.Net;
using Openlabs.Mgcxm.Internal;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Carbon.Utilities;
using Carbon.Backend.Databasing;
using Openlabs.Mgcxm.Assets;
using OpenlabsSDKV1.Core.Utilities;
using HttpMultipartParser;
using SixLabors.ImageSharp;
using OpenlabsSDKV1.Core;
using Carbon.Configs;

namespace Carbon.Servers
{
    internal class ImagesServer : MgcxmHttpListener
    {
        public ImagesServer() : base(
            Constants.LOCAL_IMAGES_SERVER_HOSTNAME,
            !Program.SELFHOST ? Constants.HOSTNAME : Constants.SELFHOST_IMAGES_SERVER_HOSTNAME,
            certificate: Constants.SSL ? SslConfig.Instance.GetCertificate() : null)
        {
            Singleton<ImagesServer>.Allocate(this);
        }
        ~ImagesServer() { Singleton<ImagesServer>.Free(); }

        public bool IsImageSizeAgaisntGuidelines(long size)
        {
            return false;
        }

        public void UploadFile(FilePart file, out ImageFileAsset imageFile)
        {
            string fileName = UUID.CreateUnique().UuidValue;

            imageFile = null;
            if (file == null)
                return; // cant upload a null file!!

            var path = Environment.CurrentDirectory + "/assets/images/" + fileName + ".png";

            var tempBuffer = new byte[file.Data.Length];
            file.Data.Read(tempBuffer, 0, (int)file.Data.Length);

            File.WriteAllBytes(path, tempBuffer);
            imageFile = AssetManager.Load<ImageFileAsset>(path).Result;
        }

        [HttpEndpoint(HttpMethods.GET, "/alt/{image}")]
        public void OnAlternativeImageRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            try
            {
                var imageName = request.Uri.Split("/")[2];
                var path = Environment.CurrentDirectory + "/assets/images/" + imageName;
                var imageAsset = AssetManager.Load<ImageFileAsset>(path).Result;

                if (imageAsset != null && File.Exists(imageAsset.Path))
                {
                    var imageBytes = request.Query.ContainsKey("cropSquare")
                        ? ImageUtils.ImageSharpCropSquare(imageAsset)
                        : imageAsset.ReadImage();

                    response.Status(HttpStatusCodes.OK).Content(HttpContentTypes.PngImage, imageBytes);
                    response.Finish();
                }
                else
                {
                    response.Status(HttpStatusCodes.NotFound).Finish();
                }
            }
            catch (Exception ex)
            {
                response.Status(HttpStatusCodes.InternalServerError)
                        .Content(HttpContentTypes.PlainText, "Failed to process your request:\n" + ex.ToString()).Finish();
            }
        }

        [HttpEndpoint(HttpMethods.GET, "/{image}")]
        public void OnImageRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            try
            {
                var imageName = request.Uri.Split("/")[1];
                var path = Environment.CurrentDirectory + "/assets/images/" + imageName;
                var imageAsset = AssetManager.Load<ImageFileAsset>(path).Result;

                if (imageAsset != null && File.Exists(imageAsset.Path))
                {
                    var imageBytes = request.Query.ContainsKey("cropSquare")
                        ? ImageUtils.ImageSharpCropSquare(imageAsset)
                        : imageAsset.ReadImage();

                    response.Status(HttpStatusCodes.OK).Content(HttpContentTypes.PngImage, imageBytes);
                    response.Finish();
                }
                else
                {
                    response.Status(HttpStatusCodes.NotFound).Finish();
                }
            }
            catch (Exception ex)
            {
                response.Status(HttpStatusCodes.InternalServerError)
                        .Content(HttpContentTypes.PlainText, "Failed to process your request:\n" + ex.ToString()).Finish();
            }
        }
    }
}
