﻿using Carbon.Json;

using Openlabs.Mgcxm.Common.JsonMapping;
using Openlabs.Mgcxm.Net;
using Openlabs.Mgcxm.Internal;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Carbon.Utilities;
using Carbon.Backend.Databasing;
using OpenlabsSDKV1.Core;
using System.Runtime.Intrinsics.Arm;
using Carbon.Configs;

namespace Carbon.Servers
{
    internal class NameServer : MgcxmHttpListener
    {
        public NameServer() : base(
            Constants.LOCAL_NAME_SERVER_HOSTNAME,
            !Program.SELFHOST ? Constants.HOSTNAME : Constants.SELFHOST_NAME_SERVER_HOSTNAME,
            certificate: Constants.SSL ? SslConfig.Instance.GetCertificate() : null)
        {
            Singleton<NameServer>.Allocate(this);
        }
        ~NameServer() { Singleton<NameServer>.Free(); }


        [HttpEndpoint(HttpMethods.GET, "/photon/server")]
        public void OnPhotonServersRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            if (!request.Query.ContainsKey("type"))
            {
                response.Status(HttpStatusCodes.BadRequest)
                        .Json(new
                        {
                            error = "No server type is given.",
                            valid_values = new string[]
                            {
                                "primary",
                                "developer"
                            },
                            requestId = UUID.CreateUnique().UuidValue
                        }).Finish();
                return;
            }

            var serverType = request.Query["type"];
            response.Status(HttpStatusCodes.OK)
                    .Json(Database.PhotonDatabase.ReadGeneric<PhotonServer>(serverType)).Finish();
        }

        [HttpEndpoint(HttpMethods.GET, "/")]
        public void OnRootRequested(MgcxmHttpRequest request, MgcxmHttpResponse response)
        {
            response.Status(HttpStatusCodes.OK)
                    .Json(new NameServerResponse
                    {
                        Auth = Constants.CreateNameServerUrl(Constants.SSL, Constants.SELFHOST_AUTH_SERVER_HOSTNAME, Constants.AUTH_SERVER_PORT),
                        API = Constants.CreateNameServerUrl(Constants.SSL, Constants.SELFHOST_API_SERVER_HOSTNAME, Constants.API_SERVER_PORT),
                        Notifications = Constants.CreateNameServerUrl(Constants.SSL, Constants.SELFHOST_NOTIFICATIONS_SERVER_HOSTNAME, Constants.NOTIFICATIONS_SERVER_PORT),
                        Images = Constants.CreateNameServerUrl(Constants.SSL, Constants.SELFHOST_IMAGES_SERVER_HOSTNAME, Constants.IMAGES_SERVER_PORT),
                        WWW = "https://recnet.openlabs.quest/"
                    })
                    .Finish();
        }
    }
}
