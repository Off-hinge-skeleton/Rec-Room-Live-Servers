﻿using Carbon.Backend;
using Carbon.Backend.AccessTokens;
using Carbon.Backend.Interfaces;
using Carbon.Backend.Statics;
using Carbon.Configs;
using Carbon.Json;
using Carbon.Json.Notifications;
using Carbon.Servers.Processors;
using Carbon.Utilities;
using Newtonsoft.Json;
using Openlabs.Mgcxm.Assets;
using Openlabs.Mgcxm.Common;
using Openlabs.Mgcxm.Internal;
using Openlabs.Mgcxm.Net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.WebSockets;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Servers
{
    internal class NotificationsServer : MgcxmSocketListener
    {
        public NotificationConnectionTree NotificationConnectionTree { get; private set; } = new NotificationConnectionTree(new List<NotificationConnectionNode>());

        public NotificationsServer() : base(
            Constants.LOCAL_NOTIFICATIONS_SERVER_HOSTNAME, 
            !Program.SELFHOST ? Constants.HOSTNAME : Constants.SELFHOST_NOTIFICATIONS_SERVER_HOSTNAME,
            certificate: Constants.SSL ? SslConfig.Instance.GetCertificate() : null)
        {
            Singleton<NotificationsServer>.Allocate(this);
        }
        ~NotificationsServer() { Singleton<NotificationsServer>.Free(); }

        [SocketRoute("/api/notification/v2"), SocketConnectionHandler(typeof(NotificationConnectionHandler))]
        public void OnNotificationClientConnect(MgcxmSocket socket) { }
    }

    public class NotificationConnectionTree
    {
        public NotificationConnectionTree(List<NotificationConnectionNode> nodes)
        {
            _nodes = nodes;
        }

        public void Add(string loginLockToken, long playerId, NotificationConnectionHandler handler)
            => _nodes.Add(new NotificationConnectionNode(loginLockToken, playerId, handler));

        public void Remove(string loginLockToken) => _nodes.RemoveAll(x => x.LoginLockToken == loginLockToken);
        public void Remove(long playerId) => _nodes.RemoveAll(x => x.PlayerId == playerId);

        public NotificationConnectionNode GetNode(string loginLockToken)
            => _nodes.FirstOrDefault(x => x.LoginLockToken == loginLockToken, null)!;

        public NotificationConnectionNode GetNode(long playerId)
            => _nodes.FirstOrDefault(x => x.PlayerId == playerId, null)!;

        public IReadOnlyList<NotificationConnectionNode> AllNodes => _nodes;
        private List<NotificationConnectionNode> _nodes;
    }

    public class NotificationConnectionNode
    {
        public NotificationConnectionNode(string loginLockToken, long playerId, NotificationConnectionHandler handler)
        {
            _loginLockToken = loginLockToken;
            _playerId = playerId;
            _handler = handler;
        }

        public string LoginLockToken => _loginLockToken;
        public long PlayerId => _playerId;
        public NotificationConnectionHandler Handler => _handler;

        private string _loginLockToken;
        private long _playerId;
        private NotificationConnectionHandler _handler;
    }

    public class NotificationConnectionHandler : MgcxmSocketConnectionHandler
    {
        private bool UpdateAccessToken(MgcxmHttpRequest request, out AccessToken token)
        {
            token = null;

            if (!request.Headers.ContainsKey("Authorization"))
            {
                Constants.NotifySink.Error("Failed to UpdateAccessToken(): auth header is not present.");
                return false;
            }

            try
            {
                var tokenString = request.Headers["Authorization"].Substring("Bearer ".Length);
                token = AccessToken.GetCached(tokenString);
            }
            catch (Exception ex)
            {
                Constants.NotifySink.Exception("Failed to UpdateAccessToken()", ex);
                return false;
            }

            return true;
        }

        public override bool NegotiateUpgrade(MgcxmHttpRequest request)
        {
            bool success = UpdateAccessToken(request, out var accessToken);
            if (success) AccessToken = accessToken;

            return success;
        }

        public override void OnConnection(MgcxmSocket socket)
        {
            presence = BackendService.GetBackend<Presence>();
            playerSubscriptions = BackendService.GetBackend<PlayerSubscriptions>();
        }

        public override void OnMessage(byte[] data)
        {
            var messageString = Encoding.UTF8.GetString(data);
            Constants.NotifySink.Warning(messageString);
            var apiData = JsonConvert.DeserializeObject<Dictionary<string, object>>(messageString);

            if (!Handshaked)
            {
                Handshaked = true;

                HandshakeRequest request = JsonConvert.DeserializeObject<HandshakeRequest>(messageString)!;
                if (!Guid.TryParse(request.LoginLockToken, out _))
                {
                    Socket.GetRawWebSocket().CloseAsync(WebSocketCloseStatus.InvalidPayloadData, "", CancellationToken.None);
                    return;
                }

                LoginLockToken = LoginLockTokens.CreateToken(AccessToken, request.LoginLockToken);
                Singleton<NotificationsServer>.Instance.NotificationConnectionTree.Add(request.LoginLockToken, AccessToken.PlayerId, this);

                playerSubscriptions.InitializeSubscriptions(AccessToken);
                presence.NonBackend_SetPlayerPresenseOnline(AccessToken, true);
                presence.NonBackend_SetPlayerPresenseGameSession(AccessToken, null);

                SendNotificationBulk(new LoginLockTokenPushNotification
                {
                    SessionId = Openlabs.Mgcxm.Common.Random.Range(100000, 100000000),
                    LoginLockToken = request.LoginLockToken,
                });
            }
            else
            {
                NotificationProcessor.OnMessageEmitted(AccessToken, apiData, this);
            }
        }

        public override void OnDisconnection(WebSocketCloseStatus? status)
        {
            Singleton<NotificationsServer>.Instance.NotificationConnectionTree.Remove(LoginLockToken);
        }

        internal void SendNotificationBulk(params PushNotificationBase[] notifications)
        {
            foreach (var notification in notifications)
            {
                Logger.Warning("Sending " + notification.GetType().GetSafeName() + " to " + AccessToken.PlayerId);
                base.Socket.SendMessage(notification);
            }
        }

        internal bool Handshaked { get; private set; }
        internal string LoginLockToken { get; private set; }
        internal AccessToken AccessToken { get; private set; }

        private IPresenceBackend presence;
        private IPlayerSubscriptionsBackend playerSubscriptions;

        public class HandshakeRequest : ObjectDTO
        {
            public string LoginLockToken { get; set; }
        }
    }
}
