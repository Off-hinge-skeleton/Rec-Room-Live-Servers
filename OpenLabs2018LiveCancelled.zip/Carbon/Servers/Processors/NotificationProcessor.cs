﻿using Carbon.Backend;
using Carbon.Backend.AccessTokens;
using Carbon.Json;
using Carbon.Json.Notifications;
using Carbon.Utilities;
using Newtonsoft.Json;
using Openlabs.Mgcxm.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Servers.Processors
{
    internal static class NotificationProcessor
    {
        public static void OnMessageEmitted(AccessToken accessToken, Dictionary<string, object> apiData, NotificationConnectionHandler connectionHandler)
        {
            Constants.NotifySink.Warning("[{0}] ---> API: {1}", accessToken.PlayerId, apiData["api"]);
            Dictionary<string, object> parameters = JsonConvert.DeserializeObject<Dictionary<string, object>>(JsonConvert.SerializeObject(apiData["param"]))!;

            switch (apiData["api"])
            {
                case "playerSubscriptions/v1/update":
                    List<long> playerIds = JsonConvert.DeserializeObject<List<long>>(JsonConvert.SerializeObject(parameters["PlayerIds"]))!;
                    foreach (var playerId in playerIds) Singleton<PlayerSubscriptions>.Instance.NonBackend_SubscribeToPlayer(accessToken, playerId);
                    break;

                case "heartbeat2":
                    connectionHandler.SendNotificationBulk(new PushNotificationDto<PlayerPresence>
                    {
                        Id = PushNotificationId.PresenceHeartbeatResponse,
                        Msg = Singleton<Presence>.Instance.NonBackend_GetPlayerPresence(accessToken)
                    });
                    break;
            }
        }
    }
}
