﻿using OpenlabsSDKV1.Core;
using OpenlabsSDKV1.Core.Async;
using Steamworks;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Steam
{
    public class CSteamVerificationResult
    {
        public int state;
        public string content;
    }

    internal static class SecureVerify
    {
        static IHttpClient _steampoweredApi 
            = new OpenlabsSDKV1.Core.HttpClient("https://api.steampowered.com");

        public static IPromise<CSteamVerificationResult> TryVerification(string ticket) => new Promise<CSteamVerificationResult>(action =>
        {
            if (!string.IsNullOrEmpty(ticket))
            {
                _steampoweredApi.Get(
                    string.Format("/ISteamUserAuth/AuthenticateUserTicket/v0001/?key={0}&appid=480&ticket={1}",
                    SteamConstants.WEB_API_KEY, ticket), (response) =>
                    {
                        action.Resolve(new CSteamVerificationResult
                        {
                            state = response.IsSuccessStatusCode ? 0 : 1,
                            content = response.Content!
                        });
                    });
            }
            else
                action.Reject(Error.Create(5, "Ticket is empty"));
        });
    }
}
