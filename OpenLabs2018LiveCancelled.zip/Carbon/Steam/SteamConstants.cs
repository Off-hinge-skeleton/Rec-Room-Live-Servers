﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Steam
{
    internal static class SteamConstants
    {
        public static readonly string WEB_API_KEY = "9362460E899CE2ABBE52EE533D07A851";
    }
}
