﻿using Newtonsoft.Json;
using Openlabs.Mgcxm.Internal;
using OpenlabsSDKV1.Core;
using OpenlabsSDKV1.Core.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Steam
{
    internal static class SteamUser
    {
        static IHttpClient _steampoweredApi
            = new OpenlabsSDKV1.Core.HttpClient("https://api.steampowered.com");

        public static IPromise<SteamPlayer> Get(string steamId) => new Promise<SteamPlayer>(action =>
        {
            var client = new System.Net.Http.HttpClient();
            var responseMessage = client.Send(new HttpRequestMessage(HttpMethod.Get, string.Format("https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key={0}&steamIds={1}", SteamConstants.WEB_API_KEY, steamId)));

            if (!responseMessage.IsSuccessStatusCode)
            {
                action.Reject(Error.Create(16, "Failed to get steam user"));
                return;
            }

            var root = JsonConvert.DeserializeObject<SteamPlayerLookupRoot>(responseMessage.Content.ReadAsStringAsync().Result);
            action.Resolve(root!.Response.Players[0]);
        });
    }

    public class SteamPlayer
    {
        [JsonProperty("steamid")]
        public string SteamId { get; set; }

        [JsonProperty("communityvisibilitystate")]
        public int CommunityVisibilityState { get; set; }

        [JsonProperty("profilestate")]
        public int ProfileState { get; set; }

        [JsonProperty("personaname")]
        public string DisplayName { get; set; }

        [JsonProperty("profileurl")]
        public string ProfileUrl { get; set; }

        [JsonProperty("avatar")]
        public string AvatarUrl { get; set; }

        [JsonProperty("avatarmedium")]
        public string AvatarMediumUrl { get; set; }

        [JsonProperty("avatarfull")]
        public string AvatarFullUrl { get; set; }

        [JsonProperty("avatarhash")]
        public string AvatarHash { get; set; }

        [JsonProperty("lastlogoff")]
        public int LastLogoffTime { get; set; }

        [JsonProperty("personastate")]
        public int PersonaState { get; set; }

        [JsonProperty("primaryclanid")]
        public string PrimaryClanId { get; set; }

        [JsonProperty("timecreated")]
        public int TimeCreated { get; set; }

        [JsonProperty("personastateflags")]
        public int PersonaStateFlags { get; set; }

        [JsonProperty("gameextrainfo")]
        public string GameInfo { get; set; }

        [JsonProperty("gameid")]
        public string GameId { get; set; }
    }

    public class SteamPlayerLookupResponse
    {
        [JsonProperty("players")]
        public List<SteamPlayer> Players { get; set; }
    }

    public class SteamPlayerLookupRoot
    {
        [JsonProperty("response")]
        public SteamPlayerLookupResponse Response { get; set; }
    }

}
