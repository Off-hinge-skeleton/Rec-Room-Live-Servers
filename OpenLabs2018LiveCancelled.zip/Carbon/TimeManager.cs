﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon
{
    public delegate void TimePassedDelegate(DateTime dateTime);

    public static class TimeManager
    {
        public static event TimePassedDelegate OnDayPassed;
        public static event TimePassedDelegate OnHourPassed;
        public static event TimePassedDelegate OnMinutePassed;
        public static event TimePassedDelegate OnSecondPassed;

        private static bool _initialized;
        private static Timer _timer;

        public static void Initialize()
        {
            if (_initialized) return;
            _initialized = true;

            // Set up the timer to trigger events
            _timer = new Timer(TimerCallback, null, TimeSpan.Zero, TimeSpan.FromSeconds(1)); // Adjust the interval as needed
        }

        private static void TimerCallback(object state)
        {
            DateTime now = DateTime.Now;

            if (now.Second == 0 && OnMinutePassed != null)
                OnMinutePassed(now);
            if (now.Minute == 0 && OnHourPassed != null)
                OnHourPassed(now);
            if (now.Hour == 0 && OnDayPassed != null)
                OnDayPassed(now);
            if (OnSecondPassed != null)
                OnSecondPassed(now);
        }
    }
}
