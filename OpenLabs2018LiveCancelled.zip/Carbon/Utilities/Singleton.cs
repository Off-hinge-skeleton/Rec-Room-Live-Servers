﻿using Openlabs.Mgcxm.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carbon.Utilities
{
    internal static class Singleton
    {
        public static void Allocate<T>(T instance)
        {
            Singleton<T>.Allocate(instance);
        }

        public static void Free<T>()
        {
            Singleton<T>.Free();
        }
    }

    internal static class Singleton<T>
    {
        public static void Allocate(T instance)
        {
            if (Instance == null)
            {
                Instance = instance;
                // Logger.Warning(string.Format("[{0}] Singleton allocated", typeof(T).GetSafeName()));
            }
        }

        public static void Free()
        {
            if (Instance != null)
            {
                Instance = (T)(object)null;
                // Logger.Warning(string.Format("[{0}] Singleton freed", typeof(T).GetSafeName()));
            }
        }
        
        public static T Instance { get; private set; }
    }
}
