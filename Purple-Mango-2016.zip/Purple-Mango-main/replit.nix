{ pkgs }: {
  deps = [];
}